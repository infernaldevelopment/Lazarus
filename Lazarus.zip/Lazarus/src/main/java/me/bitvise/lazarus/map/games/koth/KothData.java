package me.bitvise.lazarus.map.games.koth;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import me.bitvise.lazarus.map.games.Cuboid;
import me.bitvise.lazarus.factions.Faction;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.type.SystemFaction;
import me.bitvise.lazarus.map.games.loot.LootData;

import java.util.UUID;

@Getter
@Setter
@AllArgsConstructor
public class KothData {

    private String name;
    private UUID factionId;
    private int captime;
    private Cuboid cuboid;

    private transient String color;
    private transient LootData loot;

    public Faction getFaction() {
        return FactionsManager.getInstance().getFactionByUuid(this.factionId);
    }

    public String getColoredName() {
        return this.color + this.name;
    }

    public void setupKothColor() {
        this.color =  ((SystemFaction) this.getFaction()).getColor();
    }
}
