package me.bitvise.lazarus.abilities.type;

import me.bitvise.lazarus.abilities.AbilityItem;
import me.bitvise.lazarus.abilities.AbilityType;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.timer.cooldown.CooldownTimer;
import me.bitvise.lazarus.utils.creator.ConfigCreator;
import me.bitvise.lazarus.utils.provider.Lang;
import org.apache.commons.lang.time.DurationFormatUtils;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;

public class GuardianAngelAbility extends AbilityItem implements Listener {

    private int healthThreshold;
    private int duration;

    private final String cooldownName;

    public GuardianAngelAbility(ConfigCreator config) {
        super(AbilityType.GUARDIAN_ANGEL, "GUARDIAN_ANGEL", config);

        this.cooldownName = "GuardianAngel";
        this.overrideActivationMessage();
    }

    @Override
    protected void loadAdditionalData(ConfigurationSection abilitySection) {
        this.healthThreshold = abilitySection.getInt("HEALTH");
        this.duration = abilitySection.getInt("DURATION");
    }

    public void sendActivationMessage(Player player, int health) {
        this.activationMessage.forEach(line -> player.sendMessage(line
            .replace("<abilityName>", this.displayName)
            .replace("<amount>", String.valueOf(health / 2.0))
            .replace("<cooldown>", DurationFormatUtils.formatDurationWords(this.cooldown * 1000, true, true))));
    }

    @Override
    protected boolean onItemClick(Player player, PlayerInteractEvent event) {
        TimerManager.getInstance().getCooldownTimer().activate(player, this.cooldownName, this.duration,
            Lang.ABILITIES_PREFIX + Lang.ABILITIES_GUARDIAN_ANGEL_EXPIRED);

        this.sendActivationMessage(player, this.healthThreshold);
        return true;
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityDamage(EntityDamageEvent event) {
        if(!(event.getEntity() instanceof Player)) return;

        Player player = (Player) event.getEntity();

        CooldownTimer cooldownTimer = TimerManager.getInstance().getCooldownTimer();
        if(!cooldownTimer.isActive(player, this.cooldownName)) return;

        if(player.getHealth() > this.healthThreshold) return;

        player.setHealth(player.getMaxHealth());
        cooldownTimer.cancel(player, this.cooldownName);

        player.sendMessage(Lang.ABILITIES_PREFIX + Lang.ABILITIES_GUARDIAN_ANGEL_HEALED);
    }
}
