package me.bitvise.lazarus.factions.commands.admin;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.factions.FactionsManager;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ForceJoinCommand extends SubCommand {

    public ForceJoinCommand() {
        super("forcejoin", "lazarus.factions.forcejoin", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FORCE_JOIN_USAGE);
            return;
        }

        Player player = (Player) sender;

        if(FactionsManager.getInstance().getPlayerFaction(player) != null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_ALREADY_IN_FACTION_SELF);
            return;
        }

        PlayerFaction faction = FactionsManager.getInstance().searchForFaction(args[0]);

        if(faction == null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FACTION_DOESNT_EXIST.replace("<argument>", args[0]));
            return;
        }

        if(!FactionsManager.getInstance().joinFaction(player, faction)) return;

        faction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FORCE_JOINED.replace("<player>", player.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(player))));
    }
}
