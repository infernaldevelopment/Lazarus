package me.bitvise.lazarus.map.games.mountain.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.commands.manager.SubCommand;

import org.bukkit.command.CommandSender;

public class MountainTimeCommand extends SubCommand {

    MountainTimeCommand() {
        super("time", "lazarus.mountain.time");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        sender.sendMessage(Lazarus.getInstance().getMountainManager().nextRespawnString());
    }
}
