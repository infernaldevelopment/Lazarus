package me.bitvise.lazarus.factions.type;

import lombok.NoArgsConstructor;
import me.bitvise.lazarus.utils.Color;

@NoArgsConstructor
public class MountainFaction extends SystemFaction {

    public MountainFaction(String name) {
        super(name);

        this.setColor(name.equals("Ore") ? Color.translate("&b") : Color.translate("&b"));
    }
}
