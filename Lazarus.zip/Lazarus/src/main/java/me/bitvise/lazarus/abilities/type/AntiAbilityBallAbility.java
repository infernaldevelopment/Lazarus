package me.bitvise.lazarus.abilities.type;

import me.bitvise.lazarus.abilities.AbilityItem;
import me.bitvise.lazarus.abilities.AbilityType;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.creator.ConfigCreator;
import me.bitvise.lazarus.utils.provider.Lang;
import org.apache.commons.lang.time.DurationFormatUtils;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

public class AntiAbilityBallAbility extends AbilityItem {

    private int radius;
    private int duration;

    public AntiAbilityBallAbility(ConfigCreator config) {
        super(AbilityType.ANTI_ABILITY_BALL, "ANTI_ABILITY_BALL", config);

        this.overrideActivationMessage();
    }

    @Override
    protected void loadAdditionalData(ConfigurationSection abilitySection) {
        this.radius = abilitySection.getInt("RADIUS");
        this.duration = abilitySection.getInt("DURATION");
    }

    public void sendActivationMessage(Player player, int radius, int duration) {
        this.activationMessage.forEach(line -> player.sendMessage(line
            .replace("<abilityName>", this.displayName)
            .replace("<radius>", String.valueOf(radius))
            .replace("<duration>", DurationFormatUtils.formatDurationWords(duration * 1000, true, true))
            .replace("<cooldown>", DurationFormatUtils.formatDurationWords(this.cooldown * 1000, true, true))));
    }

    @Override
    protected boolean onItemClick(Player player, PlayerInteractEvent event) {
        player.getNearbyEntities(this.radius, this.radius, this.radius).forEach(entity -> {
            if(!(entity instanceof Player) || entity == player) return;

            this.activateAbilityOnTarget(player, (Player) entity);
        });

        this.sendActivationMessage(player, this.radius, this.duration);

        event.setCancelled(true);
        return true;
    }

    private void activateAbilityOnTarget(Player damager, Player target) {
        TimerManager.getInstance().getGlobalAbilitiesTimer().activate(target, this.duration);

        target.sendMessage(Lang.ABILITIES_PREFIX + Lang.ABILITIES_ANTI_ABILITY_BALL_TARGET_ACTIVATED
            .replace("<player>", damager.getName())
            .replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(damager)))
            .replace("<abilityName>", this.displayName)
            .replace("<duration>", DurationFormatUtils.formatDurationWords(this.duration * 1000, true, true)));
    }
}
