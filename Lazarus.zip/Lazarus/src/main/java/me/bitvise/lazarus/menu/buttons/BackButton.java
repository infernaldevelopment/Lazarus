package me.bitvise.lazarus.menu.buttons;

import com.google.common.collect.Lists;
import lombok.AllArgsConstructor;
import me.bitvise.lazarus.menu.Button;
import me.bitvise.lazarus.menu.Menu;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.item.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.ItemStack;

import java.util.List;

@AllArgsConstructor
public class BackButton extends Button {

    private final Menu back;

    @Override
    public ItemStack getButtonItem(Player player) {
        List<String> lore = Lists.newArrayList();

        lore.add(Color.translate("&cClick here to return"));
        lore.add(Color.translate("&cto the previous menu."));

        return new ItemBuilder(Material.REDSTONE).setName("&c&lBack").setLore(lore).build();
    }

    @Override
    public void clicked(Player player, int i, ClickType clickType, int hb) {
        Button.playNeutral(player);
        this.back.openMenu(player);
    }
}
