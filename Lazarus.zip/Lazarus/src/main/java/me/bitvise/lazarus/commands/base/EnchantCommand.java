package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.item.ItemUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class EnchantCommand extends BaseCommand {

    public EnchantCommand() {
        super("enchant", "lazarus.enchant", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length < 2) {
            sender.sendMessage(Lang.PREFIX + Lang.ENCHANT_USAGE);
            return;
        }

        Player player = (Player) sender;
        ItemStack item = player.getItemInHand();

        if(item == null || item.getType() == Material.AIR) {
            player.sendMessage(Lang.PREFIX + Lang.ITEMS_NOT_HOLDING);
            return;
        }

        if(!this.checkNumber(player, args[1])) return;

        int level = Math.abs(Integer.parseInt(args[1]));

        if (level > 7 && !player.isOp()) {
            player.sendMessage(Lang.PREFIX + Lang.ENCHANT_NON_OP_LIMIT);
            return;
        }

        Enchantment enchantment = Enchantment.getByName(StringUtils.getEnchantName(args[0].toUpperCase()));

        if(enchantment == null) {
            player.sendMessage(Lang.PREFIX + Lang.ENCHANT_DOESNT_EXIST.replace("<name>", args[0]));
            return;
        }

        if(level == 0) {
            item.removeEnchantment(enchantment);
            player.sendMessage(Lang.PREFIX + Lang.ENCHANT_ENCHANT_REMOVED.replace("<item>", ItemUtils
            .getItemName(item)).replace("<enchantment>", StringUtils.getEnchantName(enchantment)));
            return;
        }

        item.addUnsafeEnchantment(enchantment, level);
        player.sendMessage(Lang.PREFIX + Lang.ENCHANT_ENCHANTED.replace("<item>", ItemUtils.getItemName(item)).replace("<enchantment>", StringUtils.getEnchantName(enchantment)));
    }

    @Override
    public List<String> tabComplete(CommandSender sender, String label, String[] args) {
        if(args.length != 1 || !sender.hasPermission("lazarus.enchant")) return null;

        List<String> completions = new ArrayList<>();

        for(String enchantmentName : StringUtils.ENCHANTMENT_NAMES) {
            if(!enchantmentName.startsWith(args[0].toUpperCase())) continue;

            completions.add(enchantmentName);
        }

        return completions;
    }
}
