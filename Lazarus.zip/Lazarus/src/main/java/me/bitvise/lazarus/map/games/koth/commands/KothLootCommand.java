package me.bitvise.lazarus.map.games.koth.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.map.games.koth.KothData;
import me.bitvise.lazarus.utils.provider.Lang;

import me.bitvise.lazarus.commands.manager.SubCommand;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class KothLootCommand extends SubCommand {

    public KothLootCommand() {
        super("loot", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.KOTH_LOOT_USAGE);
            return;
        }

        KothData koth = Lazarus.getInstance().getKothManager().getKoth(args[0]);

        if(koth == null) {
            sender.sendMessage(Lang.KOTH_EXCEPTION_DOESNT_EXIST
            .replace("<koth>", args[0]));
            return;
        }

        ((Player) sender).openInventory(koth.getLoot().getInventory());
    }
}
