package me.bitvise.lazarus.map.lunarclient.cooldown;

public enum CooldownType {

    APPLE, COMBAT_TAG, ENDERPEARL, HOME, LOGOUT, STUCK
}
