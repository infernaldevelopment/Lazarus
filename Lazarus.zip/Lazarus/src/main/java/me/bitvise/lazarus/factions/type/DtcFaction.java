package me.bitvise.lazarus.factions.type;

import me.bitvise.lazarus.utils.Color;

public class DtcFaction extends SystemFaction {

    public DtcFaction() {
        super("DTC");

        this.setColor(Color.translate("&c"));
    }
}
