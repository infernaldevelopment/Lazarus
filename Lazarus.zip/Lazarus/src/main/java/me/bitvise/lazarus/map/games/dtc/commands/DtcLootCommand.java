package me.bitvise.lazarus.map.games.dtc.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.map.games.loot.LootData;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DtcLootCommand extends SubCommand {

    DtcLootCommand() {
        super("loot", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        LootData loot = Lazarus.getInstance().getLootManager().getLootByName("DTC");
        ((Player) sender).openInventory(loot.getInventory());
    }
}
