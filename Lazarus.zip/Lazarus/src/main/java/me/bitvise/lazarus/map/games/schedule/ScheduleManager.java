package me.bitvise.lazarus.map.games.schedule;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.*;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.command.CommandSender;

import java.io.File;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.Year;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

public class ScheduleManager implements ManagerEnabler {

    private final File scheduleFile;

    private List<ScheduleData> schedules;
    private final Set<DayOfWeek> days;

    private final DateTimeFormatter timeFormatter;
    private ScheduleTask scheduleTask;

    public ScheduleManager() {
        this.scheduleFile = FileUtils.getOrCreateFile(Config.GAMES_DIR, "schedule.json");

        this.schedules = new ArrayList<>();
        this.days = EnumSet.allOf(DayOfWeek.class);

        this.timeFormatter = DateTimeFormatter.ofPattern("EEEE, " + Config.DATE_FORMAT, Locale.ENGLISH);

        this.loadSchedules();
        if(!this.schedules.isEmpty()) this.startScheduleTask();
    }

    public void disable() {
        this.saveSchedules();

        this.schedules.clear();
        this.days.clear();

        if(this.scheduleTask != null) this.cancelScheduleTask();
    }

    private void loadSchedules() {
        String content = FileUtils.readWholeFile(this.scheduleFile);

        if(content == null) {
            this.schedules = new ArrayList<>();
            return;
        }

        this.schedules = Lazarus.getInstance().getGson().fromJson(content, GsonUtils.SCHEDULE_TYPE);
    }

    private void saveSchedules() {
        if(this.schedules == null) return;

        FileUtils.writeString(this.scheduleFile, Lazarus.getInstance().getGson()
            .toJson(this.schedules, GsonUtils.SCHEDULE_TYPE));
    }

    private void startScheduleTask() {
        this.scheduleTask = new ScheduleTask(this);
    }

    private void cancelScheduleTask() {
        this.scheduleTask.cancel();
        this.scheduleTask = null;
    }

    public int createSchedule(String name, DayOfWeek day, String time) {
        int id = this.schedules.size() + 1;

        ScheduleData schedule = new ScheduleData();
        schedule.setId(id);
        schedule.setName(name);
        schedule.setTimeString(time);

        LocalDateTime current = LocalDateTime.now(Config.TIMEZONE.toZoneId());

        String[] timeArray = time.split(":");

        int dayOfMonth = current.getDayOfMonth() + (day.getValue() - current.getDayOfWeek().getValue());

        dayOfMonth = dayOfMonth < 1 ? dayOfMonth + 7 : dayOfMonth > current.getMonth()
        .length(Year.isLeap(current.getYear())) ? dayOfMonth - 7 : dayOfMonth;

        int hours = Integer.parseInt(timeArray[0]);
        int minutes = Integer.parseInt(timeArray[1]);

        schedule.setTime(LocalDateTime.of(current.getYear(), current.getMonth(), dayOfMonth, hours, minutes));

        if(this.scheduleTask == null) this.startScheduleTask();

        this.schedules.add(schedule);
        this.schedules.sort(Comparator.comparing(ScheduleData::getTime));

        if(this.scheduleTask.getDay() == day) {
            this.scheduleTask.getDaySchedules().add(schedule);
        }

        return id;
    }

    public void removeSchedule(ScheduleData schedule, boolean save) {
        this.schedules.remove(schedule);
        this.schedules.stream().filter(s -> s.getId() > schedule.getId()).forEach(s -> s.setId(s.getId() - 1));

        if(this.scheduleTask.getDay() == schedule.getTime().getDayOfWeek()) {
            this.scheduleTask.getDaySchedules().remove(schedule);
        }

        if(save) {
            this.saveSchedules();
        }

        if(this.schedules.isEmpty()) {
            this.cancelScheduleTask();
        }
    }

    public void removeScheduleByName(String name) {
        List<ScheduleData> temp = new ArrayList<>(this.schedules);

        for(ScheduleData schedule : temp) {
            if(schedule.getName().equals(name)) {
                this.removeSchedule(schedule, false);
            }
        }

        this.saveSchedules();
    }

    public ScheduleData getScheduleById(int id) {
        return this.schedules.stream().filter(schedule -> schedule.getId() == id).findFirst().orElse(null);
    }

    List<ScheduleData> getSchedulesByDay(DayOfWeek day) {
        return this.schedules.stream().filter(schedule -> schedule.getTime().getDayOfWeek() == day).collect(Collectors.toList());
    }

    private LocalDateTime calculateScheduleOffsets() {
        LocalDateTime current = LocalDateTime.now(Config.TIMEZONE.toZoneId());

        for(ScheduleData schedule : this.schedules) {
            while(schedule.getTime().isBefore(current)) {
                schedule.setTime(schedule.getTime().plusDays(7));
            }
        }

        this.schedules.sort(Comparator.comparing(ScheduleData::getTime));
        return current;
    }

    public void clearSchedule(CommandSender sender) {
        if(this.schedules.isEmpty()) {
            sender.sendMessage(Lang.SCHEDULE_PREFIX + Lang.SCHEDULE_CLEAR_NO_SCHEDULES);
            return;
        }

        this.schedules.clear();
        this.saveSchedules();

        this.scheduleTask.cancel();
        this.scheduleTask = null;

        Messages.sendMessage(Lang.SCHEDULE_PREFIX + Lang.SCHEDULE_CLEAR_CLEARED
        .replace("<player>", sender.getName()), "lazarus.staff");
    }

    public void listNextSchedules(CommandSender sender) {
        if(this.schedules.isEmpty()) {
            sender.sendMessage(Lang.SCHEDULE_PREFIX + Lang.SCHEDULE_LIST_NO_SCHEDULES);
            return;
        }

        LocalDateTime current = this.calculateScheduleOffsets();

        sender.sendMessage(Lang.SCHEDULE_COMMAND_HEADER);

        for(int i = 0; i < Math.min(3, this.schedules.size()); i++) {
            ScheduleData schedule = this.schedules.get(i);

            sender.sendMessage(Lang.SCHEDULE_UPCOMING_EVENTS_FORMAT.replace("<id>", String
            .valueOf(i+1)).replace("<event>", schedule.getName()).replace("<time>", StringUtils
            .formatMillis(current.until(schedule.getTime(), ChronoUnit.MILLIS))));
        }

        sender.sendMessage(Lang.SCHEDULE_COMMAND_FOOTER);
    }

    public void listAllSchedules(CommandSender sender) {
        if(this.schedules.isEmpty()) {
            sender.sendMessage(Lang.SCHEDULE_PREFIX + Lang.SCHEDULE_LIST_NO_SCHEDULES);
            return;
        }

        sender.sendMessage(Lang.SCHEDULE_COMMAND_HEADER);
        sender.sendMessage(Lang.SCHEDULE_LIST_TITLE);

        sender.sendMessage("");

        sender.sendMessage(Lang.SCHEDULE_LIST_CURRENT_TIME + LocalDateTime
        .now(Config.TIMEZONE.toZoneId()).format(this.timeFormatter));

        sender.sendMessage("");

        String message = sender.hasPermission("lazarus.schedule.admin") ? Lang
        .SCHEDULE_LIST_ADMIN_FORMAT : Lang.SCHEDULE_LIST_PLAYER_FORMAT;

        this.days.forEach(day -> {
            List<ScheduleData> schedules = this.schedules.stream().filter(schedule -> schedule
            .getTime().getDayOfWeek() == day).collect(Collectors.toList());

            if(schedules.isEmpty()) return;

            sender.sendMessage(Lang.SCHEDULE_LIST_DAY_FORMAT.replace("<day>",
            day.getDisplayName(TextStyle.FULL, Locale.ENGLISH)));

            schedules.forEach(schedule -> sender.sendMessage(message.replace("<id>", String.valueOf(schedule
            .getId())).replace("<event>", schedule.getName()).replace("<time>", schedule.getTimeString())));
            sender.sendMessage("");
        });

        sender.sendMessage(Lang.SCHEDULE_COMMAND_FOOTER);
    }
}
