package me.bitvise.lazarus.factions.commands.player;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.enums.Role;
import me.bitvise.lazarus.factions.type.PlayerFaction;

import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class WithdrawCommand extends SubCommand {

    public WithdrawCommand() {
        super("withdraw", Collections.singletonList("w"), true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_WITHDRAW_USAGE);
            return;
        }

        Player player = (Player) sender;

        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);

        if(faction == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
            return;
        }

        if(!faction.getMember(player).getRole().isAtLeast(Role.CAPTAIN)) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NO_PERMISSION.replace("<role>", Role.getName(Role.CAPTAIN)));
            return;
        }

        int amount;

        if(args[0].equalsIgnoreCase("all")) {
            amount = faction.getBalance();
        } else {
            if(!this.checkNumber(sender, args[0])) return;
            amount = Math.abs(Integer.parseInt(args[0]));
        }

        if(amount > faction.getBalance()) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_WITHDRAW_NOT_ENOUGH_MONEY
            .replace("<amount>", String.valueOf(faction.getBalance())));
            return;
        }

        Lazarus.getInstance().getEconomyManager().addBalance(player, amount);
        faction.setBalance(faction.getBalance() - amount);

        faction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_WITHDRAW_WITHDRAWN.replace("<player>",
        player.getName()).replace("<amount>", String.valueOf(amount)));
    }
}
