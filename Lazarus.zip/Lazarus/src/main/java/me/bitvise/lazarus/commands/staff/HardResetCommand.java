package me.bitvise.lazarus.commands.staff;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.claim.ClaimManager;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;

import java.util.ArrayList;
import java.util.List;

public class HardResetCommand extends BaseCommand {

    private final String[] TAB_COMPLETIONS = new String[] {
        "playerfactions", "factionpoints", "userdata", "timers", "deathbans", "all"
    };

    public HardResetCommand() {
        super("hardreset", "lazarus.hardreset");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(!(sender instanceof ConsoleCommandSender)) {
            sender.sendMessage(Lang.PREFIX + Lang.COMMANDS_FOR_CONSOLE_ONLY);
            return;
        }

        if(args.length == 0) {
            Lang.HARD_RESET_COMMAND_USAGE.forEach(sender::sendMessage);
            return;
        }

        switch(args[0].toLowerCase()) {
            case "playerfactions": {
                Lazarus.getInstance().log("&4===&c=============================================&4===");
                ClaimManager.getInstance().deleteAllPlayerFactionClaims();
                FactionsManager.getInstance().deleteAllPlayerFactions();
                Lazarus.getInstance().log("&4===&c=============================================&4===");
                return;
            }
            case "factionpoints": {
                Lazarus.getInstance().log("&4===&c=============================================&4===");
                FactionsManager.getInstance().resetPlayerFactionPoints();
                Lazarus.getInstance().log("&4===&c=============================================&4===");
                return;
            }
            case "userdata": {
                Lazarus.getInstance().log("&4===&c=============================================&4===");
                Lazarus.getInstance().getProfileManager().deleteAllUserdata();
                Lazarus.getInstance().log("&4===&c=============================================&4===");
                return;
            }
            case "timers": {
                Lazarus.getInstance().log("&4===&c=============================================&4===");
                TimerManager.getInstance().deleteAllTimers();
                Lazarus.getInstance().log("&4===&c=============================================&4===");
                return;
            }
            case "deathbans": {
                Lazarus.getInstance().log("&4===&c=============================================&4===");
                Lazarus.getInstance().getDeathbanManager().deleteAllDeathbans(true);
                Lazarus.getInstance().log("&4===&c=============================================&4===");
                return;
            }
            case "all": {
                Lazarus.getInstance().log("&4===&c=============================================&4===");
                ClaimManager.getInstance().deleteAllPlayerFactionClaims();
                FactionsManager.getInstance().deleteAllPlayerFactions();
                Lazarus.getInstance().getProfileManager().deleteAllUserdata();
                Lazarus.getInstance().getDeathbanManager().deleteAllDeathbans(true);
                TimerManager.getInstance().deleteAllTimers();
                Lazarus.getInstance().log("&4===&c=============================================&4===");
                return;
            }
            default: {
                Lang.HARD_RESET_COMMAND_USAGE.forEach(sender::sendMessage);
            }
        }
    }

    @Override
    public List<String> tabComplete(CommandSender sender, String label, String[] args) {
        if(args.length != 1 || !(sender instanceof ConsoleCommandSender)) return null;

        List<String> completions = new ArrayList<>();

        for(String resetType : TAB_COMPLETIONS) {
            if(!resetType.startsWith(args[0].toLowerCase())) continue;

            completions.add(resetType);
        }

        return completions;
    }
}
