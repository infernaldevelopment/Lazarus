package me.bitvise.lazarus.factions.commands.admin;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.command.CommandSender;

public class ForceRenameCommand extends SubCommand {

    public ForceRenameCommand() {
        super("forcerename", "lazarus.factions.forcerename");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length < 2) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FORCE_RENAME_USAGE);
            return;
        }

        PlayerFaction faction = FactionsManager.getInstance().searchForFaction(args[0]);

        if(faction == null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FACTION_DOESNT_EXIST.replace("<argument>", args[0]));
            return;
        }

        if(faction.getName().equalsIgnoreCase(args[1])) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FORCE_RENAME_SAME_NAME.replace("<name>", args[1]));
            return;
        }

        if(Config.FACTION_NAME_DISALLOWED_NAMES.contains(args[1].toLowerCase())) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_BLOCKED_FACTION_NAME);
            return;
        }

        if(args[1].length() < Config.FACTION_NAME_MINIMUM_LENGTH) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NAME_TOO_SHORT);
            return;
        }

        if(args[1].length() > Config.FACTION_NAME_MAXIMUM_LENGTH) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NAME_TOO_BIG);
            return;
        }

        if(!StringUtils.isAlphaNumeric(args[1])) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NAME_NOT_ALPHANUMERIC);
            return;
        }

        if(FactionsManager.getInstance().getFactionByName(args[1]) != null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FACTION_ALREADY_EXISTS.replace("<name>", args[1]));
            return;
        }

        String oldName = faction.getName();
        if(!faction.setName(sender, args[1], true)) return;


        Messages.sendMessage(Lang.FACTIONS_FORCE_RENAMED.replace("<name>", oldName).replace("<newName>", args[1]));
    }
}
