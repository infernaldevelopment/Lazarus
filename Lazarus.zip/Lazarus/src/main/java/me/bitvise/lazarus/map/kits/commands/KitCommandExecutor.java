package me.bitvise.lazarus.map.kits.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.map.kits.kit.KitData;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.commands.manager.SubCommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.Collections;

public class KitCommandExecutor extends SubCommandExecutor {

    public KitCommandExecutor() {
        super("kit", Collections.singletonList("kits"), Lang.KITS_COMMAND_USAGE_ADMIN);

        this.setPrefix(Lang.KIT_PREFIX);

        this.addSubCommand(new KitCreateCommand());
        this.addSubCommand(new KitDelayCommand());
        this.addSubCommand(new KitEditCommand());
        this.addSubCommand(new KitGiveCommand());
        this.addSubCommand(new KitListCommand());
        this.addSubCommand(new KitRemoveCommand());
    }

    @Override
    public boolean execute(CommandSender sender, String label, String[] args) {
        if(args.length == 0) {
            if(sender.hasPermission("lazarus.kits.admin")) {
                this.getUsageMessage(sender).forEach(sender::sendMessage);
                return true;
            }

            Lang.KITS_COMMAND_USAGE_PLAYER.forEach(sender::sendMessage);
            return true;
        }

        SubCommand sub = this.getSubCommand(args[0]);

        if(sub == null) {
            KitData kit = Lazarus.getInstance().getKitsManager().getKit(args[0]);

            if(kit != null && sender instanceof Player) {
                Player player = (Player) sender;
                Lazarus.getInstance().getKitsManager().giveKit(player, kit, false);
                return true;
            }

            if(kit != null && sender instanceof ConsoleCommandSender) {
                sender.sendMessage(Lang.KIT_PREFIX + Lang.COMMANDS_FOR_PLAYERS_ONLY);
                return true;
            }

            sender.sendMessage(Lang.KIT_PREFIX + Lang.KITS_EXCEPTION_DOESNT_EXISTS.replace("<kit>", args[0]));
            return true;
        }

        if(sub.isForPlayersOnly() && sender instanceof ConsoleCommandSender) {
            sender.sendMessage(Lang.KIT_PREFIX + Lang.COMMANDS_FOR_PLAYERS_ONLY);
            return true;
        }

        if(sub.getPermission() != null && !sender.hasPermission(sub.getPermission())) {
            sender.sendMessage(Lang.KIT_PREFIX + Lang.COMMANDS_NO_PERMISSION);
            return true;
        }

        sub.execute(sender, Arrays.copyOfRange(args, 1, args.length));
        return true;
    }
}
