package me.bitvise.lazarus.menu.type;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import me.bitvise.lazarus.menu.Button;
import me.bitvise.lazarus.menu.Menu;
import me.bitvise.lazarus.menu.buttons.CloseButton;
import me.bitvise.lazarus.profile.Profile;
import me.bitvise.lazarus.profile.ProfileManager;
import me.bitvise.lazarus.utils.item.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

public class LeaderboardsMenu extends Menu {


    @Override
    public String getTitle(Player player) {
        return "&8Leaderboards";
    }

    @Override
    public int getSize() {
        return 9*3;
    }

    @Override
    public Map<Integer, Button> getButtons(Player player) {
        Map<Integer, Button> buttons = Maps.newHashMap();

        buttons.put(0, new CloseButton());
        buttons.put(12, new TopKillsButton());
        return buttons;
    }

    private static class TopKillsButton extends Button {


        @Override
        public ItemStack getButtonItem(Player player) {
            List<String> lore = Lists.newArrayList();
            //List<Profile> profiles = new Profile().getUsers().values().stream().sorted(Comparator.comparing(pr -> ((Profile) pr).getKills()).reversed()).limit(10).collect(Collectors.toList());

            /*if (profiles.isEmpty()) {
                lore.add(ChatColor.RED + "There are no players in this top!");
            } else {
                for(int i = 0; i < profiles.size(); i++) {
                    lore.add(ChatColor.DARK_GRAY + "Displaying 10 players with most");
                    lore.add(ChatColor.DARK_GRAY + "kills in this map.");
                    lore.add(ChatColor.GRAY + "");
                    Profile profile = (Profile) profiles.get(i);
                    lore.add(new StringBuilder().append(ChatColor.GRAY + ChatColor.BOLD.toString()).append(i + 1).append(". ").append(profile.getName()).append(ChatColor.WHITE).append(" ").append(profile.getKills()).append(" kills").toString());
                    lore.add(ChatColor.GRAY + "");

                }
            }*/

            return new ItemBuilder(Material.DIAMOND_SWORD).setName("&aKills Leaderboard").setLore(lore).build();
        }
    }
}
