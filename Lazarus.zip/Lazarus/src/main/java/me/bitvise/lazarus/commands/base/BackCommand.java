package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.profile.Profile;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BackCommand extends BaseCommand {

    public BackCommand() {
        super("back", "lazarus.back", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        Profile data = Lazarus.getInstance().getProfileManager().getUserdata(player);

        if(data.getLastLocation() == null) {
            player.sendMessage(Lang.PREFIX + Lang.BACK_NO_LOCATION);
            return;
        }

        if(!player.teleport(data.getLastLocation())) return;
        player.sendMessage(Lang.PREFIX + Lang.BACK_TELEPORTED);
    }
}
