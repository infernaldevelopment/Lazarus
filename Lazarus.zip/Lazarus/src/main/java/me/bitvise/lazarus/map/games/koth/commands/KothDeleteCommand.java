package me.bitvise.lazarus.map.games.koth.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.map.games.koth.KothData;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.SubCommand;
import org.bukkit.command.CommandSender;

import java.util.Collections;

public class KothDeleteCommand extends SubCommand {

    public KothDeleteCommand() {
        super("delete", Collections.singletonList("remove"), "lazarus.koth.delete");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.KOTH_REMOVE_USAGE);
            return;
        }

        KothData koth = Lazarus.getInstance().getKothManager().getKoth(args[0]);

        if(koth == null) {
            sender.sendMessage(Lang.KOTH_EXCEPTION_DOESNT_EXIST.replace("<koth>", args[0]));
            return;
        }

        Lazarus.getInstance().getKothManager().deleteKoth(sender, koth);
        sender.sendMessage(Lang.KOTH_REMOVE_REMOVED.replace("<koth>", koth.getName()));
    }
}
