package me.bitvise.lazarus.menu.type;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.factions.Faction;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.menu.Button;
import me.bitvise.lazarus.menu.Menu;
import me.bitvise.lazarus.menu.buttons.BackButton;
import me.bitvise.lazarus.menu.buttons.CloseButton;
import me.bitvise.lazarus.menu.buttons.PageInfoButton;
import me.bitvise.lazarus.menu.pagination.PageButton;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.item.ItemBuilder;
import me.bitvise.lazarus.utils.item.ItemUtils;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class FactionTopMenu extends Menu {

    @Override
    public String getTitle(Player player) {
        return "&8Faction Top";
    }

    @Override
    public int getSize() {
        return 9*3;
    }

    @Override
    public Map<Integer, Button> getButtons(Player player) {
        Map<Integer, Button> buttons = Maps.newHashMap();

        buttons.put(0, new CloseButton());

        buttons.put(11, new FactionTopPointsButton());
        buttons.put(12, new FactionTopLivesButton());
        buttons.put(13, new FactionTopBalanceButton());
        buttons.put(14, new FactionTopCappedKothsButton());
        buttons.put(15, new FactionInformationButton());

        return buttons;
    }

    private static class FactionTopPointsButton extends Button {

        @Override
        public ItemStack getButtonItem(Player player) {
            List<String> lore = Lists.newArrayList();
            List<Faction> factions = FactionsManager.getInstance().getFactions().values().stream().filter(faction -> faction instanceof PlayerFaction).sorted(Comparator.comparing(faction -> ((PlayerFaction) faction).getPoints()).reversed()).limit(10).collect(Collectors.toList());

            if (factions.isEmpty()) {
                lore.add(ChatColor.GRAY + "There are no factions in this top!");
                lore.add(ChatColor.GRAY + "be the first by typing " + ChatColor.WHITE + "/f create <name>");
            } else {
                lore.add(ChatColor.GRAY + "If you want to see more information");
                lore.add(ChatColor.GRAY + "about this faction type " + ChatColor.WHITE + " /f show <name>");
                lore.add(ChatColor.GRAY + "");
                for(int i = 0; i < factions.size(); i++) {
                    PlayerFaction faction = (PlayerFaction) factions.get(i);
                    lore.add(new StringBuilder().append(ChatColor.GRAY).append(i + 1).append(". ").append(faction.getName(player)).append(ChatColor.GRAY + " - ").append(ChatColor.WHITE).append(faction.getPoints()).append(" points").toString());
                }
            }

            lore.add(ChatColor.GRAY + "");
            lore.add(ChatColor.YELLOW + "infernalmc.cc/faction-top/points");

            return new ItemBuilder(Material.ENDER_PEARL).setName("&aFaction Top Points").setLore(lore).build();
        }
    }

    private static class FactionTopLivesButton extends Button {

        @Override
        public ItemStack getButtonItem(Player player) {
            List<String> lore = Lists.newArrayList();
            List<Faction> factions = FactionsManager.getInstance().getFactions().values().stream().filter(faction -> faction instanceof PlayerFaction).sorted(Comparator.comparing(faction -> ((PlayerFaction) faction).getLives()).reversed()).limit(10).collect(Collectors.toList());


            if (factions.isEmpty()) {
                lore.add(ChatColor.GRAY + "There are no factions in this top!");
                lore.add(ChatColor.GRAY + "be the first by typing " + ChatColor.WHITE + "/f create <name>");
            } else {
                lore.add(ChatColor.GRAY + "If you want to see more information");
                lore.add(ChatColor.GRAY + "about this faction type " + ChatColor.WHITE + " /f show <name>");
                lore.add(ChatColor.GRAY + "");
                for(int i = 0; i < factions.size(); i++) {
                    PlayerFaction faction = (PlayerFaction) factions.get(i);
                    lore.add(new StringBuilder().append(ChatColor.GRAY).append(i + 1).append(". ").append(faction.getName(player)).append(ChatColor.GRAY + " - ").append(ChatColor.WHITE).append(faction.getLives()).append(" lives").toString());
                }
            }

            lore.add(ChatColor.GRAY + "");
            lore.add(ChatColor.YELLOW + "infernalmc.cc/faction-top/lives");

            return new ItemBuilder(Material.DIAMOND_SWORD).setName("&aFaction Top Lives").setLore(lore).build();
        }
    }

    private static class FactionTopBalanceButton extends Button {

        @Override
        public ItemStack getButtonItem(Player player) {
            List<String> lore = Lists.newArrayList();
            List<Faction> factions = FactionsManager.getInstance().getFactions().values().stream().filter(faction -> faction instanceof PlayerFaction).sorted(Comparator.comparing(faction -> ((PlayerFaction) faction).getBalance()).reversed()).limit(10).collect(Collectors.toList());


            if (factions.isEmpty()) {
                lore.add(ChatColor.GRAY + "There are no factions in this top!");
                lore.add(ChatColor.GRAY + "be the first by typing " + ChatColor.WHITE + "/f create <name>");
            } else {
                lore.add(ChatColor.GRAY + "If you want to see more information");
                lore.add(ChatColor.GRAY + "about this faction type " + ChatColor.WHITE + " /f show <name>");
                lore.add(ChatColor.GRAY + "");
                for(int i = 0; i < factions.size(); i++) {
                    PlayerFaction faction = (PlayerFaction) factions.get(i);
                    lore.add(new StringBuilder().append(ChatColor.GRAY).append(i + 1).append(". ").append(faction.getName(player)).append(ChatColor.GREEN + " $").append(faction.getBalance()).toString());
                }
            }

            lore.add(ChatColor.GRAY + "");
            lore.add(ChatColor.YELLOW + "infernalmc.cc/faction-top/balance");

            return new ItemBuilder(Material.NAME_TAG).setName("&aFaction Top Balance").setLore(lore).build();
        }
    }

    private static class FactionTopCappedKothsButton extends Button {

        @Override
        public ItemStack getButtonItem(Player player) {
            List<String> lore = Lists.newArrayList();
            List<Faction> factions = FactionsManager.getInstance().getFactions().values().stream().filter(faction -> faction instanceof PlayerFaction).sorted(Comparator.comparing(faction -> ((PlayerFaction) faction).getCappedKoths()).reversed()).limit(10).collect(Collectors.toList());

            if (factions.isEmpty()) {
                lore.add(ChatColor.GRAY + "There are no factions in this top!");
                lore.add(ChatColor.GRAY + "be the first by typing " + ChatColor.WHITE + "/f create <name>");
            } else {
                lore.add(ChatColor.GRAY + "If you want to see more information");
                lore.add(ChatColor.GRAY + "about this faction type " + ChatColor.WHITE + " /f show <name>");
                lore.add(ChatColor.GRAY + "");
                for(int i = 0; i < factions.size(); i++) {
                    PlayerFaction faction = (PlayerFaction) factions.get(i);
                    lore.add(new StringBuilder().append(ChatColor.GRAY).append(i + 1).append(". ").append(faction.getName(player)).append(ChatColor.GRAY).append(" - ").append(ChatColor.WHITE).append(faction.getCappedKoths()).append(" capped koths").toString());
                }
            }

            lore.add(ChatColor.GRAY + "");
            lore.add(ChatColor.YELLOW + "infernalmc.cc/faction-top/cappedkoths");

            return new ItemBuilder(Material.GOLDEN_APPLE).setName("&aFaction Top Capped Koths").setLore(lore).build();
        }
    }

    private static class FactionInformationButton extends Button {

        @Override
        public ItemStack getButtonItem(Player player) {
            List<String> lore = Lists.newArrayList();
            PlayerFaction playerFaction = FactionsManager.getInstance().getPlayerFaction(player);
            //String rankPrefix = Color.translate(ChatHandler.getInstance().getPrefix(playerFaction.getLeader().getPlayer()));

            if (playerFaction == null) {
                lore.add(ChatColor.RED + "You are not in");
                lore.add(ChatColor.RED + "a faction! " + StringUtils.WARNING);
                lore.add(ChatColor.GRAY + "");
                lore.add(ChatColor.GRAY + "You can create a");
                lore.add(ChatColor.GRAY + "faction using");
                lore.add(ChatColor.WHITE + "/f create <name>" + ChatColor.GRAY + ".");
            } else {
                lore.add(ChatColor.LIGHT_PURPLE + playerFaction.getName());
                lore.add(ChatColor.GRAY + "Balance: " + ChatColor.GREEN + "$" + playerFaction.getBalance());
                lore.add(ChatColor.GRAY + "Total Points: " + ChatColor.WHITE + playerFaction.getPoints());
            }

            lore.add(ChatColor.GRAY + "");
            lore.add(ChatColor.YELLOW + "infernalmc.cc/faction-guide/");

            return new ItemBuilder(Material.SIGN).setSkullOwner(player.getName()).setName("&aYour Faction").setLore(lore).build();
        }

    }
}
