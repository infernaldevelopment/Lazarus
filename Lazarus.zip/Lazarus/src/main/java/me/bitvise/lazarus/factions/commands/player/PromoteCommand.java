package me.bitvise.lazarus.factions.commands.player;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionPlayer;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.enums.Role;
import me.bitvise.lazarus.factions.type.PlayerFaction;;
import me.bitvise.lazarus.utils.provider.Config;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PromoteCommand extends SubCommand {

    public PromoteCommand() {
        super("promote", true);

        this.setExecuteAsync(true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_PROMOTE_USAGE);
            return;
        }

        Player player = (Player) sender;

        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);

        if(faction == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
            return;
        }

        if(faction.getMember(player).getRole() != Role.LEADER) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_MUST_BE_LEADER);
            return;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        if(!this.checkOfflinePlayer(sender, target, args[0])) return;

        if(player == target) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CANNOT_PROMOTE_SELF);
            return;
        }

        FactionPlayer targetPlayer = faction.getMember(target);

        if(targetPlayer == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_OTHERS.replace("<player>", target.getName()));
            return;
        }

        if(targetPlayer.getRole().getPromote() == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_PROMOTE_MAX_PROMOTE);
            return;
        }

        targetPlayer.setRole(targetPlayer.getRole().getPromote());

        if(Config.TAB_ENABLED) {
            Lazarus.getInstance().getTabManager().updateFactionPlayerList(faction);
        }

        faction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_PROMOTE_PROMOTED.replace("<player>",
        target.getName()).replace("<role>", targetPlayer.getRole().getName()));
    }
}
