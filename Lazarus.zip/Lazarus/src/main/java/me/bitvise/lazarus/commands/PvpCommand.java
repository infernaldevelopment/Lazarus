package me.bitvise.lazarus.commands;

import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.timer.scoreboard.PvpProtTimer;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PvpCommand extends BaseCommand {

    public PvpCommand() {
        super("pvp", "lazarus.pvp", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            Lang.PVP_COMMAND_USAGE.forEach(sender::sendMessage);
            return;
        }

        Player player = (Player) sender;

        switch(args[0].toLowerCase()) {
            case "enable": {
                PvpProtTimer timer = TimerManager.getInstance().getPvpProtTimer();

                if(!timer.isActive(player)) {
                    player.sendMessage(Lang.PREFIX + Lang.PVP_COMMAND_NOT_ACTIVE);
                    return;
                }

                timer.cancel(player);
                player.sendMessage(Lang.PREFIX + Lang.PVP_COMMAND_PROTECTION_DISABLED);
                return;
            }
            case "time": {
                PvpProtTimer timer = TimerManager.getInstance().getPvpProtTimer();

                if(!timer.isActive(player)) {
                    player.sendMessage(Lang.PREFIX + Lang.PVP_COMMAND_NOT_ACTIVE);
                    return;
                }

                player.sendMessage(Lang.PREFIX + Lang.PVP_COMMAND_TIME_STATUS
                .replace("<time>", timer.getDynamicTimeLeft(player)));
                return;
            }
            default: Lang.PVP_COMMAND_USAGE.forEach(player::sendMessage);
        }
    }
}
