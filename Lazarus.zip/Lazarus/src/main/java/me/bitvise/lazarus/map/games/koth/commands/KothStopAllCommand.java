package me.bitvise.lazarus.map.games.koth.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.provider.Lang;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class KothStopAllCommand extends SubCommand {

    public KothStopAllCommand() {
        super("stopall", "lazarus.koth.stopall");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(Lazarus.getInstance().getKothManager().getRunningKoths().isEmpty()) {
            sender.sendMessage(Lang.KOTH_STOP_ALL_NO_RUNNING_KOTHS);
            return;
        }

        String prefix;
        if (sender instanceof Player) {
            Player p = (Player) sender;
            prefix = Color.translate(ChatHandler.getInstance().getPrefix(p));
        } else {
            prefix = Color.translate("&4");
        }

        Lazarus.getInstance().getKothManager().stopAllKoths();

        Messages.sendMessage(Lang.KOTH_STOP_ALL_STOPPED_ALL
        .replace("<player>", sender.getName()).replace("<prefix>", prefix));
    }
}
