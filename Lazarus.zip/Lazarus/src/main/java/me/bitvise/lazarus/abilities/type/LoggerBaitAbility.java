package me.bitvise.lazarus.abilities.type;

import me.bitvise.lazarus.abilities.AbilitiesManager;
import me.bitvise.lazarus.abilities.AbilityItem;
import me.bitvise.lazarus.abilities.AbilityType;
import me.bitvise.lazarus.utils.creator.ConfigCreator;
import me.bitvise.lazarus.utils.PlayerUtils;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Skeleton;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;

public class LoggerBaitAbility extends AbilityItem implements Listener {

    private int duration;

    public LoggerBaitAbility(ConfigCreator config) {
        super(AbilityType.LOGGER_BAIT, "LOGGER_BAIT", config);
    }

    @Override
    protected void loadAdditionalData(ConfigurationSection abilitySection) {
        this.duration = abilitySection.getInt("DURATION") * 20;
    }

    @Override
    protected boolean onItemClick(Player player, PlayerInteractEvent event) {
        Skeleton skeleton = (Skeleton) player.getWorld().spawnEntity(player.getLocation(), EntityType.SKELETON);

        skeleton.setCustomName(Config.COMBAT_LOGGER_NAME_FORMAT.replace("<player>", player.getName()));
        skeleton.setCustomNameVisible(true);
        skeleton.setMetadata("loggerBait", PlayerUtils.TRUE_METADATA_VALUE);

        InvisibilityAbility ability = (InvisibilityAbility) AbilitiesManager
            .getInstance().getAbilityItemByType(AbilityType.INVISIBILITY);

        if(ability != null) {
            ability.hidePlayer(player, this.duration);
        }

        event.setCancelled(true);
        return true;
    }
}
