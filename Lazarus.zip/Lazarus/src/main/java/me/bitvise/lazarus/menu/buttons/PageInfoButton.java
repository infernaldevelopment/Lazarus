package me.bitvise.lazarus.menu.buttons;

import lombok.AllArgsConstructor;
import me.bitvise.lazarus.menu.Button;
import me.bitvise.lazarus.menu.pagination.PaginatedMenu;
import me.bitvise.lazarus.utils.item.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.ItemStack;

import java.util.Collections;

@AllArgsConstructor
public class PageInfoButton extends Button {

    private final PaginatedMenu paginatedMenu;

    @Override
    public ItemStack getButtonItem(Player player) {
        return new ItemBuilder(Material.NETHER_STAR)
                .setName("&ePage Info")
                .setLore(Collections.singletonList("&a" + paginatedMenu.getPage() + "&e/&a" + paginatedMenu.getPages(player)))
                .build();
    }

    @Override
    public boolean shouldCancel(Player player, int slot, ClickType clickType) {
        return true;
    }
}
