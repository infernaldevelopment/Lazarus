package me.bitvise.lazarus.map.games.dtc.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.map.games.dtc.DtcData;
import me.bitvise.lazarus.utils.StringUtils;

import me.bitvise.lazarus.utils.provider.Config;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.command.CommandSender;

public class DtcInfoCommand extends SubCommand {

    public DtcInfoCommand() {
        super("info");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        DtcData dtcData = Lazarus.getInstance().getDtcManager().getDtcData();

        if(dtcData.getLocation() == null) {
            sender.sendMessage(Lang.DTC_PREFIX + Lang.DTC_INFO_NOT_SETUP);
            return;
        }

        Lang.DTC_INFO_MESSAGE.forEach(line -> sender.sendMessage(line
        .replace("<location>", StringUtils.getLocationNameWithWorld(dtcData.getLocation()))
        .replace("<amount>", String.valueOf(Config.DTC_CORE_BREAKS))));
    }
}
