package me.bitvise.lazarus.classes;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.timer.cooldown.CooldownTimer;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.item.ItemUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.classes.items.ClickableItem;
import me.bitvise.lazarus.classes.manager.PvpClass;
import me.bitvise.lazarus.classes.manager.PvpClassManager;
import me.bitvise.lazarus.classes.utils.PvpClassUtils;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.Event.Result;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageModifier;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;

public class Rogue extends PvpClass implements Listener {

    private final List<ClickableItem> clickables;
    private final List<PotionEffect> backstabEffects;

    public Rogue(PvpClassManager manager) {
        super(manager, "Rogue",
            Material.CHAINMAIL_HELMET,
            Material.CHAINMAIL_CHESTPLATE,
            Material.CHAINMAIL_LEGGINGS,
            Material.CHAINMAIL_BOOTS
        );

        this.clickables = PvpClassUtils.loadClickableItems(this);
        this.backstabEffects = this.loadBackstabEffects();

        if(Config.ROGUE_CHAIN_ARMOR_RECIPE_ENABLED) this.createArmorRecipe();
    }

    @Override
    public void disable() {
        super.disable();

        this.clickables.clear();
        this.backstabEffects.clear();
    }

    private List<PotionEffect> loadBackstabEffects() {
        List<PotionEffect> effects = new ArrayList<>();

        ConfigurationSection section = Lazarus.getInstance().getClassesFile()
        .getConfigurationSection("ROGUE_CLASS.BACKSTAB.EFFECTS");

        section.getKeys(false).forEach(effectName -> {
            PotionEffectType type = PotionEffectType.getByName(effectName);
            int duration = section.getInt(effectName + ".DURATION");
            int level = section.getInt(effectName + ".LEVEL");

            effects.add(new PotionEffect(type, duration * 20, level - 1));
        });

        return effects;
    }

    private void createArmorRecipe() {
        ShapedRecipe helmet = new ShapedRecipe(new ItemStack(Material.CHAINMAIL_HELMET, 1));
        helmet.shape("AAA", "A A", "   ");
        helmet.setIngredient('A', Config.ROGUE_CHAIN_ARMOR_RECIPE_MATERIAL);
        Bukkit.addRecipe(helmet);

        ShapedRecipe chestplate = new ShapedRecipe(new ItemStack(Material.CHAINMAIL_CHESTPLATE, 1));
        chestplate.shape("A A", "AAA", "AAA");
        chestplate.setIngredient('A', Config.ROGUE_CHAIN_ARMOR_RECIPE_MATERIAL);
        Bukkit.addRecipe(chestplate);

        ShapedRecipe leggings = new ShapedRecipe(new ItemStack(Material.CHAINMAIL_LEGGINGS, 1));
        leggings.shape("AAA", "A A", "A A");
        leggings.setIngredient('A', Config.ROGUE_CHAIN_ARMOR_RECIPE_MATERIAL);
        Bukkit.addRecipe(leggings);

        ShapedRecipe boots = new ShapedRecipe(new ItemStack(Material.CHAINMAIL_BOOTS, 1));
        boots.shape("   ", "A A", "A A");
        boots.setIngredient('A', Config.ROGUE_CHAIN_ARMOR_RECIPE_MATERIAL);
        Bukkit.addRecipe(boots);
    }

    private ClickableItem getClickableItem(ItemStack item) {
        return this.clickables.stream().filter(clickable -> clickable.getItem().getType() == item.getType()
            && clickable.getItem().getDurability() == item.getDurability()).findFirst().orElse(null);
    }

    @EventHandler(ignoreCancelled = true)
    public void onCraftItem(CraftItemEvent event) {
        Player player = (Player) event.getWhoClicked();
        Material type = event.getRecipe().getResult().getType();

        if(type.name().startsWith("CHAINMAIL_")) ItemUtils.updateInventory(player);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerInteract(PlayerInteractEvent event) {
        if(event.useInteractedBlock() == Result.DENY && event.useItemInHand() == Result.DENY) return;

        if(!this.isActive(event.getPlayer()) || !event.hasItem()) return;
        if(event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        ClickableItem clickable = this.getClickableItem(event.getItem());
        if(clickable == null) return;

        CooldownTimer timer = TimerManager.getInstance().getCooldownTimer();

        String cooldown = clickable.getItem().getType().name();
        String potionName = StringUtils.getPotionEffectName(clickable.getPotionEffect());

        Player player = event.getPlayer();

        if(timer.isActive(player, cooldown)) {
            player.sendMessage(Lang.PREFIX + Lang.ROGUE_CLICKABLE_COOLDOWN
                .replace("<effect>", potionName)
                .replace("<seconds>", timer.getTimeLeft(player, cooldown)));
            return;
        }

        this.applyClickableEffect(player, clickable, false);

        timer.activate(player, cooldown, clickable.getCooldown(), Lang.PREFIX
            + Lang.ROGUE_COOLDOWN_EXPIRED.replace("<effect>", potionName));
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if(!(event.getEntity() instanceof Player) || !(event.getDamager() instanceof Player)) return;

        Player damager = (Player) event.getDamager();
        if(!this.isActive(damager)) return;
        if(damager.getItemInHand().getType() != Config.ROGUE_BACKSTAB_ITEM) return;

        Vector playerDirection = event.getEntity().getLocation().getDirection();
        Vector damagerDirection = damager.getLocation().getDirection();

        if(Math.abs(playerDirection.angle(damagerDirection)) < 1.4) {
            CooldownTimer timer = TimerManager.getInstance().getCooldownTimer();

            if(timer.isActive(damager, "BACKSTAB")) {
                damager.sendMessage(Lang.PREFIX + Lang.ROGUE_BACKSTAB_COOLDOWN
                .replace("<seconds>", timer.getTimeLeft(damager, "BACKSTAB")));
                return;
            }

            event.setDamage(Config.ROGUE_BACKSTAB_DAMAGE * 2);
            event.setDamage(DamageModifier.ARMOR, 0);

            damager.playSound(damager.getLocation(), Sound.ITEM_BREAK, 10, 10);
            ItemUtils.removeOneItem(damager);

            timer.activate(damager, "BACKSTAB", Config.ROGUE_BACKSTAB_COOLDOWN,
                Lang.PREFIX + Lang.ROGUE_BACKSTAB_COOLDOWN_EXPIRED);

            if(Config.ROGUE_BACKSTAB_EFFECTS_ENABLED) this.backstabEffects.forEach(damager::addPotionEffect);
        }
    }
}
