package me.bitvise.lazarus.commands;

import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.command.CommandSender;

public class SubclaimCommand extends BaseCommand {

    public SubclaimCommand() {
        super("subclaim", "lazarus.subclaim");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Lang.SUBCLAIM_MESSAGE.forEach(sender::sendMessage);
    }
}
