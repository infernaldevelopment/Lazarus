package me.bitvise.lazarus.map.games.conquest.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.SubCommand;
import org.bukkit.command.CommandSender;

public class ConquestStartCommand extends SubCommand {

    ConquestStartCommand() {
        super("start", "lazarus.conquest.start");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(Lazarus.getInstance().getConquestManager().isActive()) {
            sender.sendMessage(Lang.CONQUEST_PREFIX + Lang.CONQUEST_START_ALREADY_RUNNING);
            return;
        }

        Lazarus.getInstance().getConquestManager().startConquest(sender);
    }
}
