package me.bitvise.lazarus.commands.staff;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.command.CommandSender;

public class RebootCommand extends BaseCommand {

    public RebootCommand() {
        super("reboot", "lazarus.reboot");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            Lang.REBOOT_USAGE.forEach(sender::sendMessage);
            return;
        }

        switch(args[0].toLowerCase()) {
            case "stop":
            case "cancel": {
                if(!Lazarus.getInstance().getRebootHandler().isRebooting()) {
                    sender.sendMessage(Lang.PREFIX + Lang.REBOOT_NOT_RUNNING);
                    return;
                }

                Lazarus.getInstance().getRebootHandler().cancelReboot();
                return;
            } case "start": {
                if(args.length < 2) {
                    Lang.REBOOT_USAGE.forEach(sender::sendMessage);
                    return;
                }

                if(Lazarus.getInstance().getRebootHandler().isRebooting()) {
                    sender.sendMessage(Lang.PREFIX + Lang.REBOOT_ALREADY_RUNNING);
                    return;
                }

                int duration = StringUtils.parseSeconds(args[1]);

                if(duration == -1) {
                    sender.sendMessage(Lang.PREFIX + Lang.COMMANDS_INVALID_DURATION);
                    return;
                }

                Lazarus.getInstance().getRebootHandler().startReboot(duration);
                return;
            } default: {
                Lang.REBOOT_USAGE.forEach(sender::sendMessage);
            }
        }
    }
}
