package me.bitvise.lazarus.map.games.koth.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.map.games.koth.KothData;
import me.bitvise.lazarus.map.games.koth.RunningKoth;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.utils.StringUtils;
import org.bukkit.command.CommandSender;

public class KothStartCommand extends SubCommand {

    KothStartCommand() {
        super("start", "lazarus.koth.start");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.KOTH_START_USAGE);
            return;
        }

        if(Lazarus.getInstance().getKothManager().isMaxRunningKothsReached()) {
            sender.sendMessage(Lang.KOTH_EXCEPTION_MAX_RUNNING_KOTHS_AMOUNT_REACHED);
            return;
        }

        KothData koth = Lazarus.getInstance().getKothManager().getKoth(args[0]);

        if(koth == null) {
            sender.sendMessage(Lang.KOTH_EXCEPTION_DOESNT_EXIST.replace("<koth>", args[0]));
            return;
        }

        RunningKoth runningKoth = Lazarus.getInstance().getKothManager().getRunningKoth(args[0]);

        if(runningKoth != null) {
            sender.sendMessage(Lang.KOTH_START_ALREADY_RUNNING.replace("<koth>", koth.getName()));
            return;
        }

        int time = args.length == 1 ? koth.getCaptime() : StringUtils.parseSeconds(args[1]);

        if(time == -1) {
            sender.sendMessage(Lang.COMMANDS_INVALID_DURATION);
            return;
        }

        Lazarus.getInstance().getKothManager().startKoth(koth, time);
    }
}
