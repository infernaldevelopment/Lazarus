package me.bitvise.lazarus.map.kits.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.map.kits.kit.KitData;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.SubCommand;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class KitEditCommand extends SubCommand {

	KitEditCommand() {
		super("edit", "lazarus.kits.edit", true);
	}

	@Override
	public void execute(CommandSender sender, String[] args) {
		Player player = (Player) sender;
		
		if(args.length == 0) {
            player.sendMessage(Lang.KIT_PREFIX + Lang.KITS_EDIT_USAGE);
            return;
		}
			
		KitData kit = Lazarus.getInstance().getKitsManager().getKit(args[0]);
			
		if(kit == null) {
		    sender.sendMessage(Lang.KIT_PREFIX + Lang.KITS_EXCEPTION_DOESNT_EXISTS.replace("<kit>", args[0]));
		    return;
		}
				
		Lazarus.getInstance().getKitsManager().editKit(player, kit);
	}
}
