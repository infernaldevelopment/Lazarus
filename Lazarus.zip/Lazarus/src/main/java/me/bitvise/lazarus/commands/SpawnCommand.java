package me.bitvise.lazarus.commands;

import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.timer.scoreboard.TeleportTimer;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.Location;
import org.bukkit.World.Environment;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SpawnCommand extends BaseCommand {

    public SpawnCommand() {
        super("spawn", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        if(!player.hasPermission("lazarus.spawn")) {
            if(!Config.KITMAP_MODE_ENABLED) {
                player.sendMessage(Lang.PREFIX + Lang.COMMANDS_NO_PERMISSION);
                return;
            }

            Location spawn = Config.WORLD_SPAWNS.get(Environment.NORMAL);

            if(spawn == null) {
                player.sendMessage(Lang.PREFIX + Lang.SPAWN_DOESNT_EXIST
                .replace("<world>", player.getWorld().getName()));
                return;
            }

            TeleportTimer timer = TimerManager.getInstance().getTeleportTimer();

            if(timer.isActive(player)) {
                player.sendMessage(Lang.PREFIX + Lang.SPAWN_ALREADY_TELEPORTING);
                return;
            }

            timer.activate(player, spawn);

            player.sendMessage(Lang.PREFIX + Lang.SPAWN_TELEPORT_STARTED
            .replace("<time>", String.valueOf(Config.KITMAP_SPAWN_TELEPORT_DELAY)));
            return;
        }

        if(args.length == 0) {
            this.teleportToSpawn(player, Environment.NORMAL, "World");
            return;
        }

        switch(args[0].toLowerCase()) {
            case "nether": {
                this.teleportToSpawn(player, Environment.NETHER, "Nether");
                return;
            }
            case "end": {
                this.teleportToSpawn(player, Environment.THE_END, "End");
                return;
            }
            default: this.teleportToSpawn(player, Environment.NORMAL, "World");
        }
    }

    private void teleportToSpawn(Player player, Environment environment, String world) {
        Location spawn = Config.WORLD_SPAWNS.get(environment);

        if(spawn == null) {
            player.sendMessage(Lang.PREFIX + Lang.SPAWN_DOESNT_EXIST.replace("<world>", world));
            return;
        }

        if(!player.teleport(spawn)) return;
        player.sendMessage(Lang.PREFIX + Lang.SPAWN_TELEPORTED.replace("<world>", world));
    }
}
