package me.bitvise.lazarus.abilities.type;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.abilities.AbilityItem;
import me.bitvise.lazarus.abilities.AbilityType;
import me.bitvise.lazarus.claim.ClaimManager;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.utils.creator.ConfigCreator;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.abilities.utils.AbilityUtils;
import me.bitvise.lazarus.factions.FactionsManager;
import org.apache.commons.lang.time.DurationFormatUtils;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.potion.PotionEffect;

import java.util.ArrayList;
import java.util.List;

public class TankIngotAbility extends AbilityItem {

    private int distance;
    private int duration;
    private int maximum;

    private List<PotionEffect> effects;

    public TankIngotAbility(ConfigCreator config) {
        super(AbilityType.TANK_INGOT, "TANK_INGOT", config);

        this.overrideActivationMessage();
    }

    @Override
    protected void disable() {
        this.effects.clear();
    }

    @Override
    protected void loadAdditionalData(ConfigurationSection abilitySection) {
        this.distance = abilitySection.getInt("DISTANCE");
        this.duration = abilitySection.getInt("PER_PLAYER");
        this.maximum = abilitySection.getInt("MAXIMUM_DURATION");

        this.effects = AbilityUtils.loadEffects(abilitySection);
    }

    public void sendActivationMessage(Player player, int enemies, List<PotionEffect> effects) {
        this.activationMessage.forEach(line -> player.sendMessage(line
            .replace("<abilityName>", this.displayName)
            .replace("<amount>", String.valueOf(enemies))
            .replace("<effects>", AbilityUtils.getEffectList(effects, Lang.ABILITIES_TANK_INGOT_EFFECT_FORMAT))
            .replace("<cooldown>", DurationFormatUtils.formatDurationWords(this.cooldown * 1000, true, true))));
    }

    @Override
    protected boolean onItemClick(Player player, PlayerInteractEvent event) {
        PlayerFaction playerFaction = FactionsManager.getInstance().getPlayerFaction(player);

        int amountOfEnemies = 0;

        for(Entity nearby : player.getNearbyEntities(this.distance, this.distance, this.distance)) {
            if(!(nearby instanceof Player) || player == nearby) continue;

            Player enemy = (Player) nearby;
            if(Lazarus.getInstance().getStaffModeManager().isInStaffModeOrVanished(enemy)) continue;
            if(ClaimManager.getInstance().getFactionAt(enemy).isSafezone()) continue;
            if(TimerManager.getInstance().getPvpProtTimer().isActive(enemy)) continue;

            PlayerFaction enemyFaction = FactionsManager.getInstance().getPlayerFaction(enemy);
            if(playerFaction != null && (playerFaction == enemyFaction || playerFaction.isAlly(enemyFaction))) continue;

            amountOfEnemies++;
        }

        List<PotionEffect> finalEffects;

        if(amountOfEnemies > 0) {
            finalEffects = new ArrayList<>();

            for(PotionEffect effect : this.effects) {
                int duration = Math.min(this.maximum * 20, effect.getDuration() + (this.duration * amountOfEnemies * 20));
                finalEffects.add(new PotionEffect(effect.getType(), duration, effect.getAmplifier()));
            }
        } else {
            finalEffects = this.effects;
        }

        this.addEffects(player, finalEffects);
        this.sendActivationMessage(player, amountOfEnemies, finalEffects);

        event.setCancelled(true);
        return true;
    }
}
