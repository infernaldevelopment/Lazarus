package me.bitvise.lazarus.factions.commands.player;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.enums.Role;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class AutoReviveCommand extends SubCommand {

    public AutoReviveCommand() {
        super("autorevive", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;
        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);

        if(faction == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
            return;
        }

        if(!faction.getMember(player).getRole().isAtLeast(Role.CO_LEADER)) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NO_PERMISSION.replace("<role>", Role.getName(Role.CO_LEADER)));
            return;
        }

        faction.setAutoRevive(!faction.isAutoRevive());

        faction.sendMessage(Lang.FACTION_PREFIX + (faction.isAutoRevive() ? Lang.FACTIONS_AUTO_REVIVE_ENABLED
        : Lang.FACTIONS_AUTO_REVIVE_DISABLED).replace("<player>", player.getName()));
    }
}
