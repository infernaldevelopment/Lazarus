package me.bitvise.lazarus.factions.commands.player;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.type.PlayerFaction;

import me.bitvise.lazarus.utils.provider.Config;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class JoinCommand extends SubCommand {

    public JoinCommand() {
        super("join", Collections.singletonList("accept"), true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_JOIN_USAGE);
            return;
        }

        Player player = (Player) sender;

        if(FactionsManager.getInstance().getPlayerFaction(player) != null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_ALREADY_IN_FACTION_SELF);
            return;
        }

        PlayerFaction faction = FactionsManager.getInstance().searchForFaction(args[0]);

        if(faction == null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FACTION_DOESNT_EXIST.replace("<argument>", args[0]));
            return;
        }

        if(!faction.getPlayerInvitations().contains(player.getName()) && !faction.isOpen()) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_INVITED.replace("<name>", faction.getName()));
            return;
        }

        if(faction.getMembers().size() >= Config.FACTION_PLAYER_LIMIT) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_JOIN_FACTION_FULL.replace("<faction>", faction.getName()));
            return;
        }

        if(!Config.FACTION_JOIN_WHILE_FROZEN && faction.isRegenerating()) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CANNOT_JOIN_WHILE_REGENERATING.replace("<faction>", faction.getName()));
            return;
        }

        if(!FactionsManager.getInstance().joinFaction(player, faction)) return;

        faction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_JOINED.replace("<player>", player.getName()));
    }
}
