package me.bitvise.lazarus.abilities.type;

import lombok.Getter;
import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.abilities.AbilityItem;
import me.bitvise.lazarus.abilities.AbilityType;
import me.bitvise.lazarus.utils.creator.ConfigCreator;
import me.bitvise.lazarus.utils.nms.NmsUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.utils.ServerUtils;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.PotionEffectExpireEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class InvisibilityAbility extends AbilityItem implements Listener {

    @Getter private final Set<UUID> players;
    private final Set<UUID> offline;

    private int duration;

    public InvisibilityAbility(ConfigCreator config) {
        super(AbilityType.INVISIBILITY, "INVISIBILITY", config);

        this.players = new HashSet<>();
        this.offline = new HashSet<>();
    }

    @Override
    protected void disable() {
        this.players.clear();
        this.offline.clear();
    }

    @Override
    protected void loadAdditionalData(ConfigurationSection abilitySection) {
        this.duration = abilitySection.getInt("DURATION") * 20;
    }

    @Override
    protected boolean onItemClick(Player player, PlayerInteractEvent event) {
        this.hidePlayer(player, this.duration);

        event.setCancelled(true);
        return true;
    }

    public void hidePlayer(Player player, int duration) {
        PotionEffect effect = new PotionEffect(PotionEffectType.INVISIBILITY, duration, 1);
        Lazarus.getInstance().getPvpClassManager().addPotionEffect(player, effect);

        NmsUtils.getInstance().updateArmor(player, true);

        this.players.add(player.getUniqueId());
    }

    public void hidePlayers(Player player) {
        for(UUID uuid : this.players) {
            Player online = Bukkit.getPlayer(uuid);
            if(!player.getWorld().getPlayers().contains(online)) continue;

            NmsUtils.getInstance().updateArmorFor(player, online, true);
        }
    }

    private void showPlayer(Player player, boolean forced) {
        this.players.remove(player.getUniqueId());

        if(forced) {
            PotionEffect effect = Lazarus.getInstance().getPvpClassManager()
                .getPotionEffect(player, PotionEffectType.INVISIBILITY);

            if(effect == null) {
                player.removePotionEffect(PotionEffectType.INVISIBILITY);
            } else {
                player.addPotionEffect(effect, true);
            }
        }

        NmsUtils.getInstance().updateArmor(player, false);
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityDamageByEntityEvent(EntityDamageByEntityEvent event) {
        if(!(event.getEntity() instanceof Player)) return;
        Player target = (Player) event.getEntity();

        if(this.players.contains(target.getUniqueId())) {
            this.showPlayer(target, true);
            target.sendMessage(Lang.ABILITIES_PREFIX + Lang.ABILITIES_INVISIBILITY_BECOME_VISIBLE_ON_DAMAGE);
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();

        if(this.players.contains(player.getUniqueId())) {
            this.showPlayer(player, true);
            this.offline.add(player.getUniqueId());
        }
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        if(this.offline.remove(player.getUniqueId())) {
            this.hidePlayer(player, this.duration);
        }
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();

        if(this.players.contains(player.getUniqueId())) {
            this.showPlayer(player, true);
        }
    }

    @EventHandler
    public void onPotionEffectExpire(PotionEffectExpireEvent event) {
        if(!(event.getEntity() instanceof Player)) return;
        if(ServerUtils.getEffect(event).getType().getId() != 14) return;

        Player player = (Player) event.getEntity();

        if(this.players.contains(player.getUniqueId())) {
            this.showPlayer(player, false);
        }
    }
}
