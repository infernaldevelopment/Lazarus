package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class AdventureCommand extends BaseCommand {

    public AdventureCommand() {
        super("adventure", Collections.singletonList("gma"), "lazarus.gamemode");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            if(!this.checkConsoleSender(sender)) return;

            Player player = (Player) sender;
            player.setGameMode(GameMode.ADVENTURE);
            player.sendMessage(Lang.PREFIX + Lang.GAMEMODE_MESSAGE_SELF.replace("<gamemode>", "adventure"));
            return;
        }

        if(!this.checkPermission(sender, "lazarus.gamemode.others")) return;

        Player target = Bukkit.getPlayer(args[0]);
        if(!this.checkPlayer(sender, target, args[0])) return;

        target.setGameMode(GameMode.ADVENTURE);

        target.sendMessage(Lang.PREFIX + Lang.GAMEMODE_MESSAGE_SELF.replace("<gamemode>", "adventure"));
        sender.sendMessage(Lang.PREFIX + Lang.GAMEMODE_MESSAGE_OTHERS
        .replace("<player>", target.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target))).replace("<gamemode>", "adventure"));
    }
}
