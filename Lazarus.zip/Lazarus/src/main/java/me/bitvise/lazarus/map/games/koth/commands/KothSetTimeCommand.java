package me.bitvise.lazarus.map.games.koth.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.map.games.koth.KothData;
import me.bitvise.lazarus.map.games.koth.RunningKoth;
import me.bitvise.lazarus.utils.provider.Lang;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.StringUtils.FormatType;
import org.bukkit.command.CommandSender;

public class KothSetTimeCommand extends SubCommand {

    public KothSetTimeCommand() {
        super("settime", "lazarus.koth.settime");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length < 2) {
            sender.sendMessage(Lang.KOTH_SET_TIME_USAGE);
            return;
        }

        KothData koth = Lazarus.getInstance().getKothManager().getKoth(args[0]);

        if(koth == null) {
            sender.sendMessage(Lang.KOTH_EXCEPTION_DOESNT_EXIST.replace("<koth>", args[0]));
            return;
        }

        RunningKoth runningKoth = Lazarus.getInstance().getKothManager().getRunningKoth(args[0]);

        if(runningKoth == null) {
            sender.sendMessage(Lang.KOTH_EXCEPTION_NOT_RUNNING.replace("<koth>", koth.getName()));
            return;
        }

        int duration = StringUtils.parseSeconds(args[1]);

        if(duration == -1) {
            sender.sendMessage(Lang.COMMANDS_INVALID_DURATION);
            return;
        }

        runningKoth.changeCapTime(duration);

        Messages.sendMessage(Lang.KOTH_SET_TIME_CHANGED.replace("<koth>", koth.getName()).replace("<time>", StringUtils.formatTime(duration, FormatType.SECONDS_TO_MINUTES)));
    }
}
