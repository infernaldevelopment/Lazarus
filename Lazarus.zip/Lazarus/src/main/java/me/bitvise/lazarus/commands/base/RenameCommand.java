package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.item.ItemBuilder;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class RenameCommand extends BaseCommand {

    public RenameCommand() {
        super("rename", "lazarus.rename", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        if(args.length == 0) {
            player.sendMessage(Lang.PREFIX + Lang.RENAME_USAGE);
            return;
        }

        ItemStack item = player.getItemInHand();

        if(item == null || item.getType() == Material.AIR) {
            player.sendMessage(Lang.PREFIX + Lang.ITEMS_NOT_HOLDING);
            return;
        }

        String newName = Color.translate(StringUtils.joinArray(args, " ", 1));

        if(newName.length() > Config.RENAME_MAX_LENGTH) {
            player.sendMessage(Lang.PREFIX + Lang.RENAME_MAX_LENGTH_EXCEEDED
                .replace("<length>", String.valueOf(Config.RENAME_MAX_LENGTH)));
            return;
        }

        boolean newNameValid = true;

        for(int i = 1; i < args.length; i++) {
            if(Config.RENAME_BLACKLISTED_WORDS.contains(args[i].toLowerCase())) {
                newNameValid = false;
                break;
            }
        }

        if(!newNameValid) {
            player.sendMessage(Lang.PREFIX + Lang.RENAME_BLACKLISTED_WORD);
            return;
        }

        item.setItemMeta(new ItemBuilder(item).setName(newName).getItemMeta());

        player.sendMessage(Lang.PREFIX + Lang.RENAME_RENAMED.replace("<name>", newName));
    }
}
