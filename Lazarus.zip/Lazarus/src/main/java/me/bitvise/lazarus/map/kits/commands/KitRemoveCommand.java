package me.bitvise.lazarus.map.kits.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.map.kits.kit.KingKitData;
import me.bitvise.lazarus.map.kits.kit.KitData;
import me.bitvise.lazarus.map.kits.kit.KitmapKitData;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.SubCommand;
import org.bukkit.command.CommandSender;

public class KitRemoveCommand extends SubCommand {

	KitRemoveCommand() {
		super("remove", "lazarus.kits.remove");
	}

	@Override
	public void execute(CommandSender sender, String[] args) {
		if(args.length == 0) {
            sender.sendMessage(Lang.KIT_PREFIX + Lang.KITS_REMOVE_USAGE);
			return;
		}
			
		KitData kit = Lazarus.getInstance().getKitsManager().getKit(args[0]);
			
		if(kit == null) {
		    sender.sendMessage(Lang.KIT_PREFIX + Lang.KITS_EXCEPTION_DOESNT_EXISTS.replace("<kit>", args[0]));
		    return;
		}

		if(kit instanceof KingKitData) {
			sender.sendMessage(Lang.KIT_PREFIX + Lang.KITS_REMOVE_CANNOT_REMOVE_SPECIAL_EVENT_KIT);
			return;
		}

		if(kit instanceof KitmapKitData) {
			sender.sendMessage(Lang.KIT_PREFIX + Lang.KITS_REMOVE_CANNOT_REMOVE_KITMAP_KIT);
			return;
		}
				
		Lazarus.getInstance().getKitsManager().removeKit(kit);
		sender.sendMessage(Lang.KIT_PREFIX + Lang.KITS_REMOVE_REMOVED.replace("<kit>", kit.getName()));
	}
}
