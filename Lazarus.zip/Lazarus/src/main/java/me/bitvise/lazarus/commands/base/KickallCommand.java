package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.handlers.event.PluginKickEvent;
import me.bitvise.lazarus.handlers.event.PluginKickEvent.KickType;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class KickallCommand extends BaseCommand {

    public KickallCommand() {
        super("kickall", "lazarus.kickall");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.PREFIX + Lang.KICKALL_USAGE);
            return;
        }

        String reason = Color.translate("&c" + StringUtils.joinArray(args, " ", 1));
        Lazarus.getInstance().getCombatLoggerHandler().setKickAll(true);

        Bukkit.getOnlinePlayers().stream().filter(player -> !player.hasPermission("lazarus.staff")).forEach(player -> {
            PluginKickEvent event = new PluginKickEvent(player, KickType.KICKALL, reason);

            if(!event.isCancelled()) {
                player.kickPlayer(reason);
            }
        });

        String prefix;
        if (sender instanceof Player) {
            Player p = (Player) sender;
            prefix = Color.translate(ChatHandler.getInstance().getPrefix(p));
        } else {
            prefix = "&4";
        }

        Lazarus.getInstance().getCombatLoggerHandler().setKickAll(false);

        Messages.sendMessage(Lang.PREFIX + Lang.KICKALL_STAFF_MESSAGE
        .replace("<prefix>", Color.translate(prefix)).replace("<player>", sender.getName()).replace("<reason>", reason));
    }
}
