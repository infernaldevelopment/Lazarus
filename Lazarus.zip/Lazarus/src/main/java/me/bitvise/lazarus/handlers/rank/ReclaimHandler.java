package me.bitvise.lazarus.handlers.rank;

import com.lunarclient.bukkitapi.LunarClientAPI;
import com.lunarclient.bukkitapi.nethandler.client.LCPacketTitle;
import lombok.Getter;
import lombok.Setter;
import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.handlers.manager.Handler;
import me.bitvise.lazarus.profile.Profile;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ReclaimHandler extends Handler {

    private final List<ReclaimData> reclaims;

    public ReclaimHandler() {
        this.reclaims = new ArrayList<>();

        this.loadReclaimData();
    }

    @Override
    public void disable() {
        this.reclaims.clear();
    }

    private void loadReclaimData() {
        ConfigurationSection section = Lazarus.getInstance().getConfig()
            .getConfigurationSection("RECLAIM_COMMAND");

        section.getKeys(false).forEach(key -> {
            ReclaimData reclaim = new ReclaimData();

            reclaim.setRankName(Color.translate(section.getString(key + ".RANK_NAME", "")));
            reclaim.setPermission(section.getString(key + ".PERMISSION"));
            reclaim.setCommands(section.getStringList(key + ".COMMANDS"));

            this.reclaims.add(reclaim);
        });
    }

    private boolean hasReclaimPermission(Player player) {
        return this.reclaims.stream().anyMatch(reclaim -> player.hasPermission(reclaim.getPermission()));
    }

    private ReclaimData getReclaim(Player player) {
        return this.reclaims.stream().filter(reclaim -> player.hasPermission(reclaim.getPermission()))
        .findFirst().orElse(null);
    }

    public void performCommand(Player player) {
        if(!this.hasReclaimPermission(player)) {
            player.sendMessage(Lang.PREFIX + Lang.RECLAIM_NO_PERMISSION);
            return;
        }

        Profile profile = Lazarus.getInstance().getProfileManager().getUserdata(player);

        if(profile.isReclaimUsed()) {
            player.sendMessage(Lang.PREFIX + Lang.RECLAIM_ALREADY_USED);
            return;
        }

        profile.setReclaimUsed(true);

        LunarClientAPI.getInstance().sendPacket(player, new LCPacketTitle("TITLE", Lang.RECLAIM_TITLE, TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5)));
        LunarClientAPI.getInstance().sendPacket(player, new LCPacketTitle("SUBTITLE", Lang.RECLAIM_SUBTITLE.replace("<rank>", Color.translate(ChatHandler.getInstance().getSuffix(player) + ChatHandler.getInstance().getRankName(player))), TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5)));

        ReclaimData reclaim = this.getReclaim(player);

        reclaim.getCommands().forEach(command -> Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command.replace("<player>", player.getName())));

        String rankPrefix = Color.translate(ChatHandler.getInstance().getPrefix(player));
        String rankColor = Color.translate(ChatHandler.getInstance().getSuffix(player));


        player.sendMessage(Lang.RECLAIM_PLAYER_MESSAGE.replace("<color>", rankColor).replace("<rank>", rankPrefix));

        Lang.RECLAIM_BROADCAST_MESSAGE.stream().forEach(message -> {

            message = message.replace("<rank>", reclaim.getRankName());
            message = message.replace("<prefix>", rankPrefix);
            message = message.replace("<player>", player.getName());

            Messages.sendMessageWithoutPlayer(player, Color.translate(message));
        });
    }

    @Getter
    @Setter
    private static class ReclaimData {

        private String rankName;
        private String permission;
        private List<String> commands;
    }
}
