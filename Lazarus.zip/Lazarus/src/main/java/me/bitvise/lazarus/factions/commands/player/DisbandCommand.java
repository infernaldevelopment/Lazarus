package me.bitvise.lazarus.factions.commands.player;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.enums.Role;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;

import me.bitvise.lazarus.utils.provider.Config;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DisbandCommand extends SubCommand {

    public DisbandCommand() {
        super("disband", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;
        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);

        if(faction == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
            return;
        }

        if(faction.getMember(player).getRole() != Role.LEADER) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_MUST_BE_LEADER);
            return;
        }

        if(!Config.FACTION_DISBAND_WHILE_FROZEN && faction.isRegenerating()) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CANNOT_DISBAND_WHILE_REGENERATING);
            return;
        }

        if(faction.isRaidable() && !Lazarus.getInstance().getEotwHandler().isActive()) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_DISBAND_RAIDABLE_DENY);
            return;
        }

        if(!FactionsManager.getInstance().disbandFaction(faction.getId(), player)) return;

        faction.sendMessage(Lang.FACTIONS_PLAYER_DISBANDED.replace("<player>", player.getName()));
        if (!Lazarus.getInstance().getSotwHandler().isActive()) {
            Messages.sendMessageWithoutFaction(faction, Lang.FACTIONS_DISBANDED.replace("<player>", player.getName()).replace("<name>", faction.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(player))));
            //Messages.sendMessage(Lang.FACTIONS_DISBANDED.replace("<player>", player.getName()).replace("<name>", faction.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(player))));
        }
    }
}
