package me.bitvise.lazarus.map.games.koth.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.map.games.koth.KothData;
import me.bitvise.lazarus.map.games.koth.RunningKoth;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.utils.Messages;

import org.bukkit.command.CommandSender;

public class KothEndCommand extends SubCommand {

   public KothEndCommand() {
        super("end", "lazarus.koth.end");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.KOTH_END_USAGE);
            return;
        }

        KothData koth = Lazarus.getInstance().getKothManager().getKoth(args[0]);

        if(koth == null) {
            sender.sendMessage(Lang.KOTH_EXCEPTION_DOESNT_EXIST.replace("<koth>", args[0]));
            return;
        }

        RunningKoth runningKoth = Lazarus.getInstance().getKothManager().getRunningKoth(args[0]);

        if(runningKoth == null) {
            sender.sendMessage(Lang.KOTH_EXCEPTION_NOT_RUNNING.replace("<koth>", koth.getName()));
            return;
        }

        runningKoth.getCapzone().setTime(0);
        Messages.sendMessage(Lang.KOTH_END_ENDED.replace("<koth>", koth.getName()));
    }
}
