package me.bitvise.lazarus.factions.commands.player;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.event.FactionRallyEvent;
import me.bitvise.lazarus.factions.type.PlayerFaction;

import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class RemoveRallyCommand extends SubCommand {

    public RemoveRallyCommand() {
        super("removerally", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);

        if(faction == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
            return;
        }

        if(faction.getRallyLocation() == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_REMOVE_RALLY_NOT_SET);
            return;
        }

        faction.setRallyLocation(null);

        faction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_REMOVE_RALLY_REMOVED
            .replace("<player>", player.getName()));

        new FactionRallyEvent(player.getUniqueId(), null, faction, FactionRallyEvent.RallyEventType.REMOVE);
    }
}
