package me.bitvise.lazarus.commands.staff;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class FreezeCommand extends BaseCommand {

    public FreezeCommand() {
        super("freeze", Collections.singletonList("ss"), "lazarus.freeze");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.PREFIX + Lang.FREEZE_USAGE);
            return;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if(!this.checkPlayer(sender, target, args[0])) return;

        if(sender != target && target.hasPermission("lazarus.freeze.bypass")) {
            sender.sendMessage(Lang.PREFIX + Lang.FREEZE_CAN_NOT_FREEZE_PLAYER
            .replace("<player>", target.getName()));
            return;
        }

        Lazarus.getInstance().getFreezeHandler().toggleFreeze(sender, target);
    }
}
