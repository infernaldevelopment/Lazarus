package me.bitvise.lazarus.factions.commands.player;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.claim.selection.SelectionType;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.enums.Role;
import me.bitvise.lazarus.factions.type.PlayerFaction;

import me.bitvise.lazarus.utils.provider.Config;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.Location;
import org.bukkit.World.Environment;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ClaimCommand extends SubCommand {

    public ClaimCommand() {
        super("claim", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);

        if(faction == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
            return;
        }

        if(!faction.getMember(player).getRole().isAtLeast(Role.CO_LEADER)) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NO_PERMISSION.replace("<role>", Role.getName(Role.CO_LEADER)));
            return;
        }

        int claimCount = faction.getClaims().size();

        if(claimCount >= Config.FACTION_MAX_CLAIMS) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_MAX_CLAIMS_EXCEEDED);
            return;
        }

        if(claimCount >= faction.getMembers().size() * Config.FACTION_CLAIMS_PER_PLAYER) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_MAX_CLAIMS_EXCEEDED);
            return;
        }

        if(player.getWorld().getEnvironment() != Environment.NORMAL) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_CAN_CLAIM_ONLY_IN_OVERWORLD);
            return;
        }

        if(player.getInventory().firstEmpty() == -1) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_INVENTORY_FULL);
            return;
        }

        Location location = player.getLocation();
        int warzone = Config.WARZONE_RADIUS.get(Environment.NORMAL);

        if(Math.abs(location.getBlockX()) <= warzone && Math.abs(location.getBlockZ()) <= warzone) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_SPAWN_TOO_CLOSE
            .replace("<amount>", String.valueOf(warzone)));
            return;
        }

        Lazarus.getInstance().getSelectionManager().toggleSelectionProcess(player, SelectionType.CLAIM, null);
        player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_CLAIMING_WAND_RECEIVED);
    }

    public static class Claim2Command extends BaseCommand {

        public Claim2Command() {
            super("claim", true);
        }

        @Override
        public void execute(CommandSender sender, String[] args) {
            Player player = (Player) sender;

            PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);

            if(faction == null) {
                player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
                return;
            }

            if(!faction.getMember(player).getRole().isAtLeast(Role.CO_LEADER)) {
                player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NO_PERMISSION.replace("<role>", Role.getName(Role.CO_LEADER)));
                return;
            }

            int claimCount = faction.getClaims().size();

            if(claimCount >= Config.FACTION_MAX_CLAIMS) {
                player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_MAX_CLAIMS_EXCEEDED);
                return;
            }

            if(claimCount >= faction.getMembers().size() * Config.FACTION_CLAIMS_PER_PLAYER) {
                player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_MAX_CLAIMS_EXCEEDED);
                return;
            }

            if(player.getWorld().getEnvironment() != Environment.NORMAL) {
                player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_CAN_CLAIM_ONLY_IN_OVERWORLD);
                return;
            }

            if(player.getInventory().firstEmpty() == -1) {
                player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_INVENTORY_FULL);
                return;
            }

            Location location = player.getLocation();
            int warzone = Config.WARZONE_RADIUS.get(Environment.NORMAL);

            if(Math.abs(location.getBlockX()) <= warzone && Math.abs(location.getBlockZ()) <= warzone) {
                player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_SPAWN_TOO_CLOSE
                        .replace("<amount>", String.valueOf(warzone)));
                return;
            }

            Lazarus.getInstance().getSelectionManager().toggleSelectionProcess(player, SelectionType.CLAIM, null);
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_CLAIMING_WAND_RECEIVED);
        }
    }
}
