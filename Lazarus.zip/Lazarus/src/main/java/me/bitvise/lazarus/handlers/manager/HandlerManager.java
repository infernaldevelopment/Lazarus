package me.bitvise.lazarus.handlers.manager;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.menu.ButtonHandler;
import me.bitvise.lazarus.reboot.RebootHandler;
import me.bitvise.lazarus.handlers.*;
import me.bitvise.lazarus.handlers.block.*;
import me.bitvise.lazarus.handlers.chat.*;
import me.bitvise.lazarus.handlers.death.DeathMessageHandler;
import me.bitvise.lazarus.handlers.death.DeathSignHandler;
import me.bitvise.lazarus.handlers.death.HeadDropHandler;
import me.bitvise.lazarus.handlers.death.StattrakHandler;
import me.bitvise.lazarus.handlers.kitmap.KillstreakHandler;
import me.bitvise.lazarus.handlers.kitmap.KitmapHandler;
import me.bitvise.lazarus.handlers.limiter.EnchantLimiterHandler;
import me.bitvise.lazarus.handlers.limiter.PotionLimiterHandler;
import me.bitvise.lazarus.handlers.logger.CombatLoggerHandler;
import me.bitvise.lazarus.handlers.portal.EndPortalHandler;
import me.bitvise.lazarus.handlers.portal.NetherPortalTrapHandler;
import me.bitvise.lazarus.handlers.portal.PortalHandler;
import me.bitvise.lazarus.handlers.rank.RankAnnouncerHandler;
import me.bitvise.lazarus.handlers.rank.RankReviveHandler;
import me.bitvise.lazarus.handlers.rank.ReclaimHandler;
import me.bitvise.lazarus.handlers.staff.*;
import me.bitvise.lazarus.handlers.timer.*;
import me.bitvise.lazarus.map.MapKitHandler;
import me.bitvise.lazarus.settings.Settings;
import me.bitvise.lazarus.utils.ManagerEnabler;
import me.bitvise.lazarus.handlers.elevator.MinecartElevatorHandler;
import me.bitvise.lazarus.handlers.elevator.SignElevatorHandler;
import me.bitvise.lazarus.handlers.kitmap.LaunchpadHandler;
import me.bitvise.lazarus.handlers.limiter.EntityLimiterHandler;
import me.bitvise.lazarus.handlers.salvage.SalvageHandler;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.Bukkit;
import org.bukkit.event.Listener;

import java.util.ArrayList;
import java.util.List;

public class HandlerManager implements ManagerEnabler {

    private final List<Handler> handlers;

    public HandlerManager() {
        this.handlers = new ArrayList<>();

        this.handlers.add(new ButtonHandler());
        this.handlers.add(new LaunchpadHandler());
        this.handlers.add(new AutoSmeltHandler());
        this.handlers.add(new BlockedCommandsHandler());
        this.handlers.add(new BorderHandler());
        this.handlers.add(new BottleHandler());
        this.handlers.add(new ChatControlHandler());
        this.handlers.add(new ChatHandler());
        this.handlers.add(new CombatLoggerHandler());
        this.handlers.add(new CombatTagHandler());
        this.handlers.add(new CrowbarHandler());
        this.handlers.add(new DeathMessageHandler());
        this.handlers.add(new DeathSignHandler());
        this.handlers.add(new DisabledBlocksHandler());
        this.handlers.add(new DisenchantHandler());
        this.handlers.add(new DynamicEventHandler());
        this.handlers.add(new EnchantLimiterHandler());
        this.handlers.add(new EnderPearlHandler());
        this.handlers.add(new EndPortalHandler());
        this.handlers.add(new EntityLimiterHandler());
        this.handlers.add(new EotwHandler());
        this.handlers.add(new ExpAmplifierHandler());
        this.handlers.add(new FilterHandler());
        this.handlers.add(new FoundOreHandler());
        this.handlers.add(new FreezeHandler());
        this.handlers.add(new GlisteringMelonHandler());
        this.handlers.add(new GoldenAppleHandler());
        this.handlers.add(new HeadDropHandler());
        this.handlers.add(new InventoryHandler());
        this.handlers.add(new KillstreakHandler());
        this.handlers.add(new LogoutHandler());
        this.handlers.add(new MapKitHandler());
        this.handlers.add(new MessagingHandler());
        this.handlers.add(new MinecartElevatorHandler());
        this.handlers.add(new NetherPortalTrapHandler());
        this.handlers.add(new NotesHandler());
        this.handlers.add(new PortalHandler());
        this.handlers.add(new PotionLimiterHandler());
        this.handlers.add(new PvpProtHandler());
        this.handlers.add(new RankReviveHandler());
        this.handlers.add(new RebootHandler());
        this.handlers.add(new ReclaimHandler());
        this.handlers.add(new SalvageHandler());
        this.handlers.add(new Settings());
        this.handlers.add(new SignElevatorHandler());
        this.handlers.add(new ByrdeHandler());
        this.handlers.add(new SotwHandler());
        this.handlers.add(new StaffChatHandler());
        this.handlers.add(new StatsHandler());
        this.handlers.add(new StattrakHandler());
        this.handlers.add(new SubclaimHandler());
        this.handlers.add(new WarpsHandler());

        if(Config.KITMAP_MODE_ENABLED) this.handlers.add(new KitmapHandler());
        if(Config.MOB_STACK_ENABLED) this.handlers.add(new MobStackHandler());
        if(Config.ONLINE_RANK_ANNOUNCER_ENABLED) this.handlers.add(new RankAnnouncerHandler());

        this.handlers.stream().filter(handler -> handler instanceof Listener).forEach(handler ->
            Bukkit.getPluginManager().registerEvents((Listener) handler, Lazarus.getInstance()));

    }

    public int getHandlerList() {
        return this.handlers.size();
    }

    public void disable() {
        try {
            this.handlers.forEach(Handler::disable);
        } catch(Exception e) {
            e.printStackTrace();
        }

        this.handlers.clear();
    }

    public Handler getHandler(Class<?> clazz) {
        return this.handlers.stream().filter(handler -> handler.getClass() == clazz).findFirst().orElse(null);
    }
}
