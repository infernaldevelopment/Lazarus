package me.bitvise.lazarus.map.games.dragon.commands;

import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.SubCommandExecutor;

import org.bukkit.command.CommandSender;

import java.util.Collections;
import java.util.List;

public class EnderDragonCommandExecutor extends SubCommandExecutor {

    public EnderDragonCommandExecutor() {
        super("enderdragon", Collections.singletonList("dragon"), null);

        this.setPrefix(Lang.ENDER_DRAGON_PREFIX);

        this.addSubCommand(new EnderDragonInfoCommand());
        this.addSubCommand(new EnderDragonLootCommand());
        this.addSubCommand(new EnderDragonSetHealthCommand());
        this.addSubCommand(new EnderDragonSetSpawnCommand());
        this.addSubCommand(new EnderDragonStartCommand());
        this.addSubCommand(new EnderDragonStopCommand());
        this.addSubCommand(new EnderDragonTeleportCommand());
    }

    @Override
    public List<String> getUsageMessage(CommandSender sender) {
        return sender.hasPermission("lazarus.enderdragon.admin") ? Lang.ENDER_DRAGON_COMMAND_USAGE_ADMIN : Lang.ENDER_DRAGON_COMMAND_USAGE_PLAYER;
    }
}
