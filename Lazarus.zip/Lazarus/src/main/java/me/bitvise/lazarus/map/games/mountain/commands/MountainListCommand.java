package me.bitvise.lazarus.map.games.mountain.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.commands.manager.SubCommand;
import org.bukkit.command.CommandSender;

public class MountainListCommand extends SubCommand {

    MountainListCommand() {
        super("list");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Lazarus.getInstance().getMountainManager().listMountains(sender);
    }
}
