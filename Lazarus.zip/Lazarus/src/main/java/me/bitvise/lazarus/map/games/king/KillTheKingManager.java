package me.bitvise.lazarus.map.games.king;

import lombok.Getter;
import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.map.games.king.event.KingKilledEvent;
import me.bitvise.lazarus.map.kits.kit.KitData;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.ManagerEnabler;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerDropItemEvent;

import java.text.DecimalFormat;

public class KillTheKingManager implements Listener, ManagerEnabler {

    @Getter private boolean active;

    private long startTime;
    private Player kingPlayer;

    public KillTheKingManager() {
        Bukkit.getPluginManager().registerEvents(this, Lazarus.getInstance());
    }

    public void disable() {
        this.active = false;
        this.kingPlayer = null;
    }

    public void startKillTheKing(Player kingPlayer) {
        this.active = true;

        this.startTime = System.currentTimeMillis();
        this.kingPlayer = kingPlayer;

        KitData kingKit = Lazarus.getInstance().getKitsManager().getKit("King");
        kingKit.applyKit(kingPlayer);

        Messages.sendMessage(Lang.KING_START_STARTED.replace("<location>", StringUtils.getLocationNameWithWorld(kingPlayer.getLocation())));
    }

    public void stopKillTheKing(boolean death) {
        this.active = false;

        if(!death) {
            this.kingPlayer.getInventory().clear();
            this.kingPlayer.getInventory().setArmorContents(null);
        }

        this.kingPlayer = null;
    }

    public String getKingHealth() {
        int health = ((int) this.kingPlayer.getHealth() / 2);
        DecimalFormat format = new DecimalFormat("#");

        if (health >= 8) {
            return ChatColor.GREEN + ChatColor.BOLD.toString() + format.format(health) + " ❤";
        } else if (health >= 6) {
            return ChatColor.YELLOW + ChatColor.BOLD.toString() +  format.format(health) + " ❤";
        } else if (health >= 4) {
            return ChatColor.RED + ChatColor.BOLD.toString() +  format.format(health) + " ❤";
        } else {
            return ChatColor.DARK_RED + ChatColor.BOLD.toString() +  format.format(health) + " ❤";
        }
    }

    public String getKingName() {
        return this.kingPlayer.getName();
    }

    public String getKingWorld() {
        return StringUtils.getWorldName(this.kingPlayer.getLocation());
    }

    public String getKingLocation() {
        return StringUtils.getLocationNameWithoutY(this.kingPlayer.getLocation());
    }

    public String getKingLocationString() {
        if(!this.isActive()) {
            return Lang.KING_EXCEPTION_NOT_RUNNING;
        }

        return Lang.KING_KINGS_LOCATION.replace("<location>",
        StringUtils.getLocationNameWithWorld(this.kingPlayer.getLocation()));
    }

    public String getTimeLasted() {
        long diff = System.currentTimeMillis() - this.startTime;

        if(diff < 60000L) {
            return StringUtils.formatTime(diff, StringUtils.FormatType.MILLIS_TO_SECONDS) + "s";
        } else if(diff < 3600000L) {
            return StringUtils.formatTime(diff, StringUtils.FormatType.MILLIS_TO_MINUTES);
        } else {
            return StringUtils.formatTime(diff, StringUtils.FormatType.MILLIS_TO_HOURS);
        }
    }

    private void handleReward(Player killer) {
        if(!Config.KILL_THE_KING_AUTO_REWARD_ENABLED) return;

        Config.KILL_THE_KING_REWARD.forEach(command -> Bukkit.dispatchCommand(Bukkit
        .getConsoleSender(), command.replace("<player>", killer.getName())));
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlayerDropItem(PlayerDropItemEvent event) {
        if(!this.isActive() || !event.getPlayer().getUniqueId().equals(this.kingPlayer.getUniqueId())) return;
        if(!Config.KILL_THE_KING_DENY_ITEM_DROP) return;

        event.setCancelled(true);

        event.getPlayer().updateInventory();
        event.getPlayer().sendMessage(Lang.KING_EXCEPTION_ITEM_DROP_DENY);
    }

    @EventHandler(ignoreCancelled = true)
    public void onFoodLevelChange(FoodLevelChangeEvent event) {
        if(!(event.getEntity() instanceof Player)) return;

        Player player = (Player) event.getEntity();
        if(!this.isActive() || !player.getUniqueId().equals(this.kingPlayer.getUniqueId())) return;

        event.setCancelled(true);
    }

    @EventHandler
    public void onKingKilled(KingKilledEvent event) {
        this.handleReward(event.getKiller());

        Lang.KING_KING_SLAIN.forEach(line -> Messages.sendMessage(line.replace("<king>", event.getKing().getName()).replace("<kingPrefix>", Color.translate(ChatHandler.getInstance().getPrefix(event.getKing()).replace("<killer>", event.getKiller().getName()).replace("<killerPrefix>", Color.translate(ChatHandler.getInstance().getPrefix(event.getKiller()).replace("<placeholder:separator>", StringUtils.SEPARATOR)).replace("<placeholder:point>", StringUtils.POINT))))));

        StringUtils.playSound(event.getKiller(), Sound.LEVEL_UP);
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        if(!this.isActive() || !event.getEntity().getUniqueId().equals(this.kingPlayer.getUniqueId())) return;

        event.getDrops().clear();
        this.stopKillTheKing(true);

        if(event.getEntity().getKiller() != null) {
            new KingKilledEvent(event.getEntity(), event.getEntity().getKiller());
        }
    }
}
