package me.bitvise.lazarus.map.games.dtc.commands;

import me.bitvise.lazarus.commands.manager.SubCommandExecutor;

import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.command.CommandSender;

import java.util.Collections;
import java.util.List;

public class DtcCommandExecutor extends SubCommandExecutor {

    public DtcCommandExecutor() {
        super("dtc", Collections.singletonList("destroythecore"), null);

        this.setPrefix(Lang.DTC_PREFIX);

        this.addSubCommand(new DtcAreaCommand());
        this.addSubCommand(new DtcInfoCommand());
        this.addSubCommand(new DtcLootCommand());
        this.addSubCommand(new DtcSetCommand());
        this.addSubCommand(new DtcStartCommand());
        this.addSubCommand(new DtcStopCommand());
        this.addSubCommand(new DtcTeleportCommand());
    }

    @Override
    protected List<String> getUsageMessage(CommandSender sender) {
        return sender.hasPermission("lazarus.dtc.admin") ? Lang
        .DTC_COMMAND_USAGE_ADMIN : Lang.DTC_COMMAND_USAGE_PLAYER;
    }
}
