package me.bitvise.lazarus.handlers.kitmap;

import com.lunarclient.bukkitapi.LunarClientAPI;
import com.lunarclient.bukkitapi.nethandler.client.LCPacketTitle;
import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.handlers.manager.Handler;
import me.bitvise.lazarus.profile.Profile;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class KillstreakHandler extends Handler implements Listener {

    private final Map<Integer, List<String>> killstreakRewards;

    public KillstreakHandler() {
        this.killstreakRewards = new HashMap<>();
        this.loadKillstreakRewards();
    }

    @Override
    public void disable() {
        this.killstreakRewards.clear();
    }

    private void loadKillstreakRewards() {
        ConfigurationSection section = Lazarus.getInstance().getConfig()
        .getConfigurationSection("KITMAP_KILLSTREAK.KILLS");

        section.getKeys(false).forEach(killCount -> {
            if(!StringUtils.isInteger(killCount)) return;

            this.killstreakRewards.put(Integer.parseInt(killCount), section.getStringList(killCount));
        });
    }

    public void checkKillerKillstreak(Player killer) {
        if(!Config.KITMAP_MODE_ENABLED || !Config.KITMAP_KILLSTREAK_ENABLED) return;

        Profile killerProfile = Lazarus.getInstance().getProfileManager().getUserdata(killer);
        killerProfile.addKillstreak();

        List<String> commands = this.killstreakRewards.get(killerProfile.getKillstreak());
        if(commands == null) return;

        commands.forEach(command -> Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
        command.replace("<player>", killer.getName())));

        Messages.sendMessage(Lang.KITMAP_KILLSTREAK_MESSAGE.replace("<player>", killer
        .getName()).replace("<amount>", String.valueOf(killerProfile.getKillstreak())).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(killer))));
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        if(!Config.KITMAP_MODE_ENABLED || !Config.KITMAP_KILLSTREAK_ENABLED) return;
        Player victim = event.getEntity();

        int killstreak = Lazarus.getInstance().getProfileManager().getUserdata(victim).resetKillstreak();

        if(killstreak > 0) {
            victim.sendMessage(Lang.PREFIX + Lang.KITMAP_KILLSTREAK_ON_DEATH.replace("<amount>", String.valueOf(killstreak)));

            if (Config.LUNAR_CLIENT_API_ENABLED && Bukkit.getPluginManager().isPluginEnabled("LunarClient-API")) {
                LunarClientAPI.getInstance().sendPacket(victim, new LCPacketTitle("TITLE", Lang.KITMAP_KILLSTREAK_ON_DEATH_TITLE, TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5)));
                LunarClientAPI.getInstance().sendPacket(victim, new LCPacketTitle("SUBTITLE", Lang.KITMAP_KILLSTREAK_ON_DEATH_SUBTITLE.replace("<kills>", String.valueOf(killstreak)), TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5)));
            }

        }

        if(event.getEntity().getKiller() != null) {
            this.checkKillerKillstreak(event.getEntity().getKiller());
        }
    }
}
