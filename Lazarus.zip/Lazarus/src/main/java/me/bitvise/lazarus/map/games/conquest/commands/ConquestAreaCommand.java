package me.bitvise.lazarus.map.games.conquest.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.provider.Lang;

import me.bitvise.lazarus.claim.ClaimManager;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.Faction;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.claim.selection.Selection;
import me.bitvise.lazarus.claim.selection.SelectionType;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ConquestAreaCommand extends SubCommand {

    ConquestAreaCommand() {
        super("area", "lazarus.conquest.area", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;
        Selection selection = Lazarus.getInstance().getSelectionManager().getSelection(player);

        if(selection == null || selection.getType() != SelectionType.SYSTEM_CLAIM) {
            Lazarus.getInstance().getSelectionManager().toggleSelectionProcess(player, SelectionType.SYSTEM_CLAIM, null);
            player.sendMessage(Lang.CONQUEST_PREFIX + Lang.CONQUEST_AREA_MAKE_A_SELECTION);
            return;
        }

        if(!selection.areBothPositionsSet()) {
            player.sendMessage(Lang.CONQUEST_PREFIX + Lang.CONQUEST_AREA_SET_BOTH_POSITIONS);
            return;
        }

        if(!ClaimManager.getInstance().getClaimsInSelection(selection.getPosOne(), selection.getPosTwo()).isEmpty()) {
            player.sendMessage(Lang.CONQUEST_PREFIX + Lang.CONQUEST_AREA_CLAIM_OVERLAPPING);
            return;
        }

        Faction faction = FactionsManager.getInstance().getFactionByName("Conquest");

        if(!ClaimManager.getInstance().addClaim(selection.toClaim(faction))) return;
        Lazarus.getInstance().getSelectionManager().removeSelectionProcess(player);

        Messages.sendMessage(Lang.CONQUEST_PREFIX + Lang.CONQUEST_AREA_CREATED
            .replace("<player>", player.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(player))), "lazarus.staff");
    }
}
