package me.bitvise.lazarus.map.games.king.stages;

public class KingStageTwo {
}
