package me.bitvise.lazarus.level;

public class LevelData {
}
