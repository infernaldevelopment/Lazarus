package me.bitvise.lazarus.commands.staff;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;

public class InventoryInspectCommand extends BaseCommand {

    public InventoryInspectCommand() {
        super("inventoryinspect", Arrays.asList("invinspect", "invi", "ii"), "lazarus.invinspect", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.PREFIX + Lang.INVENTORY_INSPECT_USAGE);
            return;
        }

        Player player = (Player) sender;
        Player target = Bukkit.getPlayer(args[0]);

        if(!this.checkPlayer(player, target, args[0])) return;

        Lazarus.getInstance().getStaffModeManager().inventoryInspect(player, target);
    }
}
