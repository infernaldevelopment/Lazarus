package me.bitvise.lazarus.map.games.mountain.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.claim.ClaimManager;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.Faction;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.map.games.mountain.MountainType;
import me.bitvise.lazarus.claim.selection.Selection;
import me.bitvise.lazarus.claim.selection.SelectionType;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class MountainCreateCommand extends SubCommand {

    MountainCreateCommand() {
        super("create", Collections.singletonList("new"), "lazarus.mountain.create", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.MOUNTAIN_PREFIX + Lang.MOUNTAIN_CREATE_USAGE);
            return;
        }

        MountainType type;
        try {
            type = MountainType.valueOf(args[0].toUpperCase());
        } catch(IllegalArgumentException e) {
            sender.sendMessage(Lang.MOUNTAIN_PREFIX + Lang.MOUNTAIN_EXCEPTION_INCORRECT_TYPE);
            return;
        }

        Player player = (Player) sender;
        Selection selection = Lazarus.getInstance().getSelectionManager().getSelection(player);

        if(selection == null || selection.getType() != SelectionType.SYSTEM_CLAIM) {
            Lazarus.getInstance().getSelectionManager().toggleSelectionProcess(player, SelectionType.SYSTEM_CLAIM, null);
            player.sendMessage(Lang.MOUNTAIN_PREFIX + Lang.MOUNTAIN_CREATE_MAKE_A_SELECTION);
            return;
        }

        if(!selection.areBothPositionsSet()) {
            player.sendMessage(Lang.MOUNTAIN_PREFIX + Lang.MOUNTAIN_CREATE_SET_BOTH_POSITIONS);
            return;
        }

        if(!ClaimManager.getInstance().getClaimsInSelection(selection.getPosOne(), selection.getPosTwo()).isEmpty()) {
            player.sendMessage(Lang.MOUNTAIN_PREFIX + Lang.MOUNTAIN_CREATE_CLAIM_OVERLAPPING);
            return;
        }

        Faction faction = type == MountainType.GLOWSTONE ? FactionsManager.getInstance()
        .getFactionByName("Glowstone") : FactionsManager.getInstance().getFactionByName("Ore");

        if(!ClaimManager.getInstance().addClaim(selection.toClaim(faction))) return;

        int id = Lazarus.getInstance().getMountainManager().createMountain(type, faction.getId(), selection.toCuboid());

        Lazarus.getInstance().getSelectionManager().removeSelectionProcess(player);

        sender.sendMessage(Lang.MOUNTAIN_PREFIX + Lang.MOUNTAIN_CREATE_CREATED
            .replace("<id>", String.valueOf(id)));
    }
}
