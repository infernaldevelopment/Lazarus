package me.bitvise.lazarus.map.games.dragon.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.SubCommand;

import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class EnderDragonTeleportCommand extends SubCommand {

    public EnderDragonTeleportCommand() {
        super("teleport", Collections.singletonList("tp"), "lazarus.enderdragon.tp", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(!Lazarus.getInstance().getEnderDragonManager().isActive()) {
            sender.sendMessage(Lang.ENDER_DRAGON_PREFIX + Lang.ENDER_DRAGON_EXCEPTION_NOT_RUNNING);
            return;
        }

        Player player = (Player) sender;
        Lazarus.getInstance().getEnderDragonManager().teleportToDragon(player);
    }
}
