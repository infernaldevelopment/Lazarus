package me.bitvise.lazarus.map.kits.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.map.kits.kit.KitData;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.SubCommand;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class KitGiveCommand extends SubCommand {

	KitGiveCommand() {
		super("give", "lazarus.kits.give");
	}

	@Override
	public void execute(CommandSender sender, String[] args) {
		if(args.length < 2) {
            sender.sendMessage(Lang.KIT_PREFIX + Lang.KITS_GIVE_USAGE);
            return;
		}

		Player target = Bukkit.getPlayer(args[0]);
		if(!this.checkPlayer(sender, target, args[0])) return;
				
		KitData kit = Lazarus.getInstance().getKitsManager().getKit(args[1]);
				
		if(kit == null) {
		    sender.sendMessage(Lang.KIT_PREFIX + Lang.KITS_EXCEPTION_DOESNT_EXISTS.replace("<kit>", args[1]));
		    return;
		}

		Lazarus.getInstance().getKitsManager().giveKitWithCommand(sender, target, kit);
	}
}
