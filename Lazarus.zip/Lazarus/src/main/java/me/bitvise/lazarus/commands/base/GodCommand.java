package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.nms.NmsUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class GodCommand extends BaseCommand {

    public GodCommand() {
        super("god", "lazarus.god");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            if(!this.checkConsoleSender(sender)) return;

            Player player = (Player) sender;
            NmsUtils.getInstance().toggleInvulnerable(player);

            player.sendMessage(Lang.PREFIX + (NmsUtils.getInstance().isInvulnerable(player)
            ? Lang.GOD_SELF_ENABLED : Lang.GOD_SELF_DISABLED));
            return;
        }

        if(!this.checkPermission(sender, "lazarus.god.others")) return;

        Player target = Bukkit.getPlayer(args[0]);
        if(!this.checkPlayer(sender, target, args[0])) return;

        NmsUtils.getInstance().toggleInvulnerable(target);

        target.sendMessage(Lang.PREFIX + (NmsUtils.getInstance().isInvulnerable(target)
        ? Lang.GOD_SELF_ENABLED : Lang.GOD_SELF_DISABLED));

        sender.sendMessage(Lang.PREFIX + (NmsUtils.getInstance().isInvulnerable(target)
        ? Lang.GOD_OTHERS_ENABLED : Lang.GOD_OTHERS_DISABLED).replace("<player>", target.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target))));
    }
}
