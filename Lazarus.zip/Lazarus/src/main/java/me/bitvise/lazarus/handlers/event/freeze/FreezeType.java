package me.bitvise.lazarus.handlers.event.freeze;

public enum FreezeType {

    SERVER, PLAYER
}
