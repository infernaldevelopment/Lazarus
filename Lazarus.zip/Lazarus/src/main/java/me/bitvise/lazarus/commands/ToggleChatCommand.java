package me.bitvise.lazarus.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.profile.Profile;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class ToggleChatCommand extends BaseCommand {

    public ToggleChatCommand() {
        super("togglechat", Collections.singletonList("tchat"), true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        Profile data = Lazarus.getInstance().getProfileManager().getUserdata(player);
        data.getSettings().setPublicChat(!data.getSettings().isPublicChat());

        player.sendMessage(Lang.PREFIX + (data.getSettings().isPublicChat() ?
        Lang.TOGGLE_PUBLIC_CHAT_TOGGLED_ON : Lang.TOGGLE_PUBLIC_CHAT_TOGGLED_OFF));
    }
}
