package me.bitvise.lazarus.commands.staff;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class VanishCommand extends BaseCommand {

    public VanishCommand() {
        super("vanish", Collections.singletonList("v"), "lazarus.vanish");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            if(!this.checkConsoleSender(sender)) return;
            Lazarus.getInstance().getVanishManager().toggleVanish((Player) sender);
            return;
        }

        if(args[0].equalsIgnoreCase("build")) {
            if(!this.checkConsoleSender(sender)) return;
            Lazarus.getInstance().getVanishManager().toggleVanishBuild((Player) sender);
            return;
        }

        if(!this.checkPermission(sender, "lazarus.vanish.others")) return;

        Player target = Bukkit.getPlayer(args[0]);
        if(!this.checkPlayer(sender, target, args[0])) return;

        Lazarus.getInstance().getVanishManager().toggleVanish(target);

        this.sendChangedMessage(sender, target, Lazarus.getInstance().getVanishManager().isVanished(target)
        ? Lang.VANISH_ENABLED_OTHERS : Lang.VANISH_DISABLED_OTHERS);
    }

    private void sendChangedMessage(CommandSender sender, Player target, String message) {

        String prefix;
        if (sender instanceof Player) {
            Player p = (Player) sender;
            prefix = Color.translate(ChatHandler.getInstance().getPrefix(p));
        } else {
            prefix = "&4";
        }

        Messages.sendMessage(Lang.PREFIX + message
            .replace("<player>", sender.getName())
            .replace("<targetPrefix>", Color.translate(ChatHandler.getInstance().getPrefix(target)))
            .replace("<playerPrefix>", Color.translate(prefix))
            .replace("<target>", target.getName()), "lazarus.staff");
    }
}
