package me.bitvise.lazarus.map.kits.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.commands.manager.SubCommand;
import org.bukkit.command.CommandSender;

public class KitListCommand extends SubCommand {

	KitListCommand() {
		super("list", "lazarus.kits.list");
	}

	@Override
	public void execute(CommandSender sender, String[] args) {
		Lazarus.getInstance().getKitsManager().listKits(sender);
	}
}
