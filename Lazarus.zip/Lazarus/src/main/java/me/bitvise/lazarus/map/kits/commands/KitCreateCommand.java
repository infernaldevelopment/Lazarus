package me.bitvise.lazarus.map.kits.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.map.kits.kit.KitData;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.utils.StringUtils;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class KitCreateCommand extends SubCommand {

	KitCreateCommand() {
		super("create", "lazarus.kits.create", true);
	}

	@Override
	public void execute(CommandSender sender, String[] args) {
		Player player = (Player) sender;
		
		if(args.length < 2) {
            player.sendMessage(Lang.KIT_PREFIX + Lang.KITS_CREATE_USAGE);
		    return;
		}
			
		KitData kit = Lazarus.getInstance().getKitsManager().getKit(args[1]);

		if(kit != null) {
            player.sendMessage(Lang.KIT_PREFIX + Lang.KITS_EXCEPTION_ALREADY_EXISTS.replace("<kit>", kit.getName()));
            return;
		}

		int delay = StringUtils.parseSeconds(args[1]);

		if(delay == -1) {
			sender.sendMessage(Lang.KIT_PREFIX + Lang.COMMANDS_INVALID_DURATION);
			return;
		}

		Lazarus.getInstance().getKitsManager().createKit(args[0], delay);

		player.sendMessage(Lang.KIT_PREFIX + Lang.KITS_CREATE_CREATED.replace("<kit>", args[0]));
	}
}
