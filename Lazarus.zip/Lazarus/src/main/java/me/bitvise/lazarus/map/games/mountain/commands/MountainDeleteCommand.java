package me.bitvise.lazarus.map.games.mountain.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.provider.Lang;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.map.games.mountain.MountainData;
import org.bukkit.command.CommandSender;

import java.util.Collections;

public class MountainDeleteCommand extends SubCommand {

    MountainDeleteCommand() {
        super("delete", Collections.singletonList("remove"), "lazarus.mountain.delete");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.MOUNTAIN_PREFIX + Lang.MOUNTAIN_REMOVE_USAGE);
            return;
        }

        if(!this.checkNumber(sender, args[0])) return;

        MountainData mountain = Lazarus.getInstance().getMountainManager().getMountain(Integer.parseInt(args[0]));

        if(mountain == null) {
            sender.sendMessage(Lang.MOUNTAIN_PREFIX + Lang.MOUNTAIN_EXCEPTION_DOESNT_EXISTS.replace("<id>", args[0]));
            return;
        }

        Lazarus.getInstance().getMountainManager().deleteMountain(mountain);

        sender.sendMessage(Lang.MOUNTAIN_PREFIX + Lang.MOUNTAIN_REMOVE_REMOVED
        .replace("<id>", String.valueOf(mountain.getId())));
    }
}
