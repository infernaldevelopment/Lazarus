package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class MoreCommand extends BaseCommand {

    public MoreCommand() {
        super("more", "lazarus.more", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        ItemStack item = player.getItemInHand();

        if(item == null || item.getType() == Material.AIR) {
            player.sendMessage(Lang.PREFIX + Lang.ITEMS_NOT_HOLDING);
            return;
        }

        player.getItemInHand().setAmount(64);
        player.sendMessage(Lang.PREFIX + Lang.MORE_COMMAND_MESSAGE);
    }
}
