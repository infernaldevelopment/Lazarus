package me.bitvise.lazarus.abilities.commands;

import me.bitvise.lazarus.abilities.AbilitiesManager;
import me.bitvise.lazarus.abilities.AbilityItem;
import me.bitvise.lazarus.abilities.AbilityType;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.timer.type.abilities.AbilitiesTimer;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AbilityTimerCommand extends BaseCommand {

    public AbilityTimerCommand() {
        super("abilitytimer", Collections.singletonList("abilitiestimer"), "lazarus.abilitytimer");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length < 3) {
            sender.sendMessage(Lang.PREFIX + Lang.ABILITIES_ABILITY_TIMER_COMMAND_USAGE);
            return;
        }

        String prefix;
        if (sender instanceof Player) {
            Player p = (Player) sender;
            prefix = Color.translate(ChatHandler.getInstance().getPrefix(p));
        } else {
            prefix = "&4";
        }

        Player target = Bukkit.getPlayer(args[0]);
        if(!this.checkPlayer(sender, target, args[0])) return;

        AbilityType type = AbilityType.getByName(args[1]);
        if(type == null) {
            sender.sendMessage(Lang.PREFIX + Lang.ABILITIES_ABILITY_TIMER_COMMAND_NOT_FOUND.replace("<name>", args[1]));
            return;
        }

        AbilityItem ability = AbilitiesManager.getInstance().getEnabledAbilities().get(type);
        if(ability == null) {
            sender.sendMessage(Lang.PREFIX + Lang.ABILITIES_ABILITY_TIMER_COMMAND_NOT_ENABLED.replace("<name>", type.getName()));
            return;
        }

        int duration = StringUtils.parseSeconds(args[2]);

        if(duration == -1) {
            sender.sendMessage(Lang.PREFIX + Lang.COMMANDS_INVALID_DURATION);
            return;
        }

        AbilitiesTimer abilitiesTimer = TimerManager.getInstance().getAbilitiesTimer();
        if(abilitiesTimer.isActive(target, type)) abilitiesTimer.cancel(target, type);

        if(duration > 0) {
            abilitiesTimer.activate(target, ability.getType(), duration, Lang.ABILITIES_PREFIX
                + Lang.ABILITIES_ABILITY_COOLDOWN_EXPIRED.replace("<ability>", ability.getDisplayName()));
        }

        sender.sendMessage(Lang.PREFIX + Lang.ABILITIES_ABILITY_TIMER_COMMAND_CHANGED_SENDER
            .replace("<player>", target.getName())
            .replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target)))
            .replace("<abilityName>", ability.getDisplayName())
            .replace("<time>", args[2].toLowerCase()));

        if(!Lang.ABILITIES_ABILITY_TIMER_COMMAND_CHANGED.isEmpty()) {
            target.sendMessage(Lang.PREFIX + Lang.ABILITIES_ABILITY_TIMER_COMMAND_CHANGED
                .replace("<abilityName>", ability.getDisplayName())
                .replace("<time>", args[2].toLowerCase())
                .replace("<prefix>", prefix)
                .replace("<player>", sender.getName()));
        }
    }

    @Override
    public List<String> tabComplete(CommandSender sender, String alias, String[] args) {
        if(args.length != 2 || !sender.hasPermission("lazarus.abilitytimer")) {
            return super.tabComplete(sender, alias, args);
        }

        List<String> completions = new ArrayList<>();

        for(AbilityType timer : AbilitiesManager.getInstance().getEnabledAbilities().keySet()) {
            String name = timer.getName().toUpperCase();

            if(!name.startsWith(args[1].toUpperCase())) continue;

            completions.add(name);
        }

        return completions;
    }
}
