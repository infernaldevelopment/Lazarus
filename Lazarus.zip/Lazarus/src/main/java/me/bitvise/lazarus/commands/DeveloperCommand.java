package me.bitvise.lazarus.commands;

import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.menu.type.DeveloperMenu;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DeveloperCommand extends BaseCommand {

    public DeveloperCommand() {
        super("developer", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        new DeveloperMenu().openMenu(player);

    }
}
