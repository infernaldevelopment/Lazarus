package me.bitvise.lazarus.menu.type;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.map.games.Placeholder;
import me.bitvise.lazarus.map.games.koth.KothData;
import me.bitvise.lazarus.map.games.koth.RunningKoth;
import me.bitvise.lazarus.menu.Button;
import me.bitvise.lazarus.menu.Menu;
import me.bitvise.lazarus.menu.buttons.CloseButton;
import me.bitvise.lazarus.utils.item.ItemBuilder;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Comparator;
import java.util.List;
import java.util.Map;

public class KothsMenu extends Menu {

    @Override
    public String getTitle(Player player) {
        return "&8Available Koths";
    }

    @Override
    public int getSize() {
        return 9*3;
    }

    @Override
    public Map<Integer, Button> getButtons(Player player) {
        Map<Integer, Button> buttons = Maps.newHashMap();

        buttons.put(0, new CloseButton());
        buttons.put(12, new KothRunningListButton());
        buttons.put(14, new KothListButton());

        return buttons;
    }

    private static class KothListButton extends Button {

        @Override
        public ItemStack getButtonItem(Player player) {
            List<String> lore = Lists.newArrayList();

            if (Lazarus.getInstance().getKothManager().getKoths().isEmpty()) {
                lore.add(ChatColor.RED + "There are no koths defined yet!");
            } else {
                Lazarus.getInstance().getKothManager().getKoths().stream().sorted(Comparator.comparing(KothData::getName)).forEach(koth -> lore.add(Placeholder.KothReplacer.parse(koth, Lang.KOTH_LIST_COMMAND_FORMAT)));
            }

            return new ItemBuilder(Material.STORAGE_MINECART).setAmount(Lazarus.getInstance().getKothManager().getKoths().size()).setName("&aKoth List").setLore(lore).build();
        }
    }

    private static class KothRunningListButton extends Button {

        @Override
        public ItemStack getButtonItem(Player player) {
            List<String> lore = Lists.newArrayList();
            List<RunningKoth> koths = Lazarus.getInstance().getKothManager().getRunningKoths();

            if (koths.isEmpty()) {
                lore.add(ChatColor.RED + "There are no koths running yet!");
            } else {
                for (RunningKoth koth : koths) {
                    lore.add(ChatColor.GRAY + "Name: " + koth.getKothData().getColoredName());
                    lore.add(ChatColor.GRAY + " - Time: " + ChatColor.GREEN + koth.getScoreboardEntry());
                    lore.add(ChatColor.GRAY + " - Capzone: " + ChatColor.YELLOW + koth.getCapzone().getCuboid().getCenter().getBlockX() + ", " + koth.getCapzone().getCuboid().getCenter().getBlockY() + ", " + koth.getCapzone().getCuboid().getCenter().getBlockZ());
                }
            }

            return new ItemBuilder(Material.STORAGE_MINECART).setName("&aKoth Running List").setLore(lore).setAmount(Lazarus.getInstance().getKothManager().getRunningKoths().size()).addFakeGlow().build();
        }
    }
}
