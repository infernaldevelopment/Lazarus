package me.bitvise.lazarus.factions.commands.player;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.type.PlayerFaction;

import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class LivesCommand extends SubCommand {

    public LivesCommand() {
        super("lives");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            if(!this.checkConsoleSender(sender)) return;

            Player player = (Player) sender;

            PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);

            if(faction == null) {
                player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
                return;
            }

            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_LIVES_SELF
            .replace("<amount>", String.valueOf(faction.getLives())));
            return;
        }

        PlayerFaction faction = FactionsManager.getInstance().searchForFaction(args[0]);

        if(faction == null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FACTION_DOESNT_EXIST.replace("<argument>", args[0]));
            return;
        }

        sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_LIVES_OTHERS.replace("<faction>",
        faction.getName(sender)).replace("<amount>", String.valueOf(faction.getLives())));
    }
}
