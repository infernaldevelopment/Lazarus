package me.bitvise.lazarus.map.games.conquest.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ConquestStopCommand extends SubCommand {

    ConquestStopCommand() {
        super("stop", "lazarus.conquest.stop");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(!Lazarus.getInstance().getConquestManager().isActive()) {
            sender.sendMessage(Lang.CONQUEST_PREFIX + Lang.CONQUEST_EXCEPTION_NOT_RUNNING);
            return;
        }

        Lazarus.getInstance().getConquestManager().stopConquest(false);

        String prefix;
        if (sender instanceof Player) {
            Player p = (Player) sender;
            prefix = Color.translate(ChatHandler.getInstance().getPrefix(p));
        } else {
            prefix = Color.translate("&4");
        }

        Messages.sendMessage(Lang.CONQUEST_PREFIX + Lang.CONQUEST_STOP_STOPPED.replace("<player>", sender.getName()).replace("<prefix>", prefix));
    }
}
