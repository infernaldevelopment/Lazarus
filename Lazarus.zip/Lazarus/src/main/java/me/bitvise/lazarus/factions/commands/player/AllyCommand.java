package me.bitvise.lazarus.factions.commands.player;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.enums.Role;
import me.bitvise.lazarus.factions.type.PlayerFaction;

import me.bitvise.lazarus.utils.provider.Config;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class AllyCommand extends SubCommand {

    public AllyCommand() {
        super("ally", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(Config.FACTION_MAX_ALLIES <= 0) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_ALLIES_DISABLED);
            return;
        }

        if(args.length == 0) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_ALLY_USAGE);
            return;
        }

        Player player = (Player) sender;

        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);

        if(faction == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
            return;
        }

        if(!faction.getMember(player).getRole().isAtLeast(Role.CAPTAIN)) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NO_PERMISSION.replace("<role>", Role.getName(Role.CAPTAIN)));
            return;
        }

        PlayerFaction targetFaction = FactionsManager.getInstance().searchForFaction(args[0]);

        if(targetFaction == null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FACTION_DOESNT_EXIST.replace("<argument>", args[0]));
            return;
        }

        if(faction == targetFaction) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_ALLY_CANNOT_ALLY_SELF);
            return;
        }

        if(faction.getAllies().size() >= Config.FACTION_MAX_ALLIES) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_ALLY_MAX_ALLIES_SELF);
            return;
        }

        if(targetFaction.getAllies().size() >= Config.FACTION_MAX_ALLIES) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_ALLY_MAX_ALLIES_OTHERS.replace("<faction>", targetFaction.getName()));
            return;
        }

        if(faction.isAlly(targetFaction)) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_ALLY_ALREADY_ALLIES.replace("<faction>", targetFaction.getName()));
            return;
        }

        if(targetFaction.getAllyInvitations().contains(faction.getId())) {
            if(!FactionsManager.getInstance().acceptAllyRequest(faction, targetFaction)) return;

            faction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_ALLY_ACCEPTED.replace("<faction>", targetFaction.getName()));
            targetFaction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_ALLY_ACCEPTED.replace("<faction>", faction.getName()));
            return;
        }

        if(faction.getAllyInvitations().contains(targetFaction.getId())) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_ALLY_REQUEST_ALREADY_SENT.replace("<faction>", targetFaction.getName()));
            return;
        }

        faction.getAllyInvitations().add(targetFaction.getId());

        faction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_ALLY_REQUESTED_SELF.replace("<faction>", targetFaction.getName()));
        targetFaction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_ALLY_REQUESTED_OTHERS.replace("<faction>", faction.getName()));
    }
}
