package me.bitvise.lazarus.handlers.staff;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.handlers.manager.Handler;
import me.bitvise.lazarus.profile.Profile;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.util.stream.IntStream;

public class NotesHandler extends Handler implements Listener {

    public void addNote(CommandSender sender, Player target, String[] args) {
        String note = StringUtils.joinArray(args, " ", 3);

        Profile data = Lazarus.getInstance().getProfileManager().getUserdata(target);
        data.getNotes().add(note);

        sender.sendMessage(Lang.PREFIX + Lang.NOTES_COMMAND_NOTE_ADDED
        .replace("<player>", target.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target))));
    }

    public void removeNote(CommandSender sender, Player target, String id) {
        if(!StringUtils.isInteger(id)) {
            sender.sendMessage(Lang.PREFIX + Lang.COMMANDS_INVALID_NUMBER);
            return;
        }

        Profile data = Lazarus.getInstance().getProfileManager().getUserdata(target);

        if(data.getNotes().isEmpty()) {
            sender.sendMessage(Lang.PREFIX + Lang.NOTES_COMMAND_NO_NOTES
            .replace("<player>", target.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target))));
            return;
        }

        int noteId = Math.abs(Integer.parseInt(id));

        if((data.getNotes().size() < noteId) || (noteId == 0)) {
            sender.sendMessage(Lang.PREFIX + Lang.NOTES_COMMAND_NOTE_DOESNT_EXIST
            .replace("<id>", String.valueOf(noteId)));
            return;
        }

        data.getNotes().remove(noteId - 1);
        sender.sendMessage(Lang.PREFIX + Lang.NOTES_COMMAND_NOTE_REMOVED
        .replace("<id>", String.valueOf(noteId)));
    }

    public void listNotes(CommandSender sender, Player target) {
        Profile data = Lazarus.getInstance().getProfileManager().getUserdata(target);

        if(data.getNotes().isEmpty()) {
            sender.sendMessage(Lang.PREFIX + Lang.NOTES_COMMAND_NO_NOTES
            .replace("<player>", target.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target))));
            return;
        }

        sender.sendMessage("");
        sender.sendMessage(Lang.PREFIX + Lang.NOTES_COMMAND_MESSAGE.replace("<player>", target.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target))));

        IntStream.rangeClosed(1, data.getNotes().size()).forEach(i ->
            sender.sendMessage(Lang.NOTES_COMMAND_FORMAT
                .replace("<id>", String.valueOf(i))
                .replace("<note>", data.getNotes().get(i - 1))));

        sender.sendMessage("");
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Profile data = Lazarus.getInstance().getProfileManager().getUserdata(event.getPlayer());
        if(data.getNotes().isEmpty()) return;

        Messages.sendMessage("", "lazarus.staff");

        Messages.sendMessage(Lang.PREFIX + Lang.NOTES_COMMAND_MESSAGE
        .replace("<player>", event.getPlayer().getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(event.getPlayer()))), "lazarus.staff");

        IntStream.rangeClosed(1, data.getNotes().size()).forEach(i ->
            Messages.sendMessage(Lang.NOTES_COMMAND_FORMAT
                .replace("<id>", String.valueOf(i))
                .replace("<note>", data.getNotes().get(i - 1)), "lazarus.staff"));

        Messages.sendMessage("", "lazarus.staff");
    }
}
