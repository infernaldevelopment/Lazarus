package me.bitvise.lazarus.map.games.conquest.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.provider.Lang;

import me.bitvise.lazarus.claim.selection.Selection;
import me.bitvise.lazarus.claim.selection.SelectionType;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.map.games.conquest.ConquestData;
import me.bitvise.lazarus.map.games.conquest.ZoneType;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ConquestSetCapzoneCommand extends SubCommand {

    public ConquestSetCapzoneCommand() {
        super("setcapzone", "lazarus.conquest.setcapzone", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.CONQUEST_PREFIX + Lang.CONQUEST_SET_CAPZONE_USAGE);
            return;
        }

        ZoneType type;

        try {
            type = ZoneType.valueOf(args[0].toUpperCase());
        } catch(IllegalArgumentException e) {
            sender.sendMessage(Lang.CONQUEST_PREFIX + Lang.CONQUEST_EXCEPTION_INVALID_ZONE);
            return;
        }

        Player player = (Player) sender;
        Selection selection = Lazarus.getInstance().getSelectionManager().getSelection(player);

        if(selection == null || selection.getType() != SelectionType.EVENT_CLAIM) {
            Lazarus.getInstance().getSelectionManager().toggleSelectionProcess(player, SelectionType.EVENT_CLAIM, null);
            player.sendMessage(Lang.CONQUEST_PREFIX + Lang.CONQUEST_SET_CAPZONE_MAKE_A_SELECTION);
            return;
        }

        if(!selection.areBothPositionsSet()) {
            player.sendMessage(Lang.CONQUEST_PREFIX + Lang.CONQUEST_SET_CAPZONE_SET_BOTH_POSITIONS);
            return;
        }

        ConquestData conquest = Lazarus.getInstance().getConquestManager().getConquest();
        conquest.setCuboid(type, selection.toCuboid());

        Lazarus.getInstance().getSelectionManager().removeSelectionProcess(player);

        player.sendMessage(Lang.CONQUEST_PREFIX + Lang.CONQUEST_SET_CAPZONE_CREATED
        .replace("<zone>", type.getName()));
    }
}
