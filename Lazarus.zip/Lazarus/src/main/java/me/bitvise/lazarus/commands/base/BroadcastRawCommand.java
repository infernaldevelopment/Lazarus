package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.command.CommandSender;

import java.util.Collections;

public class BroadcastRawCommand extends BaseCommand {

    public BroadcastRawCommand() {
        super("broadcastraw", Collections.singletonList("bcraw"), "lazarus.broadcastraw");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.PREFIX + Lang.BROADCAST_RAW_USAGE);
            return;
        }

        Messages.sendMessage(Color.translate(StringUtils.joinArray(args, " ", 1)));
    }
}
