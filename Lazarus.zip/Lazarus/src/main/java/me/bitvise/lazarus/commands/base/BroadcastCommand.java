package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.command.CommandSender;

import java.util.Collections;

public class BroadcastCommand extends BaseCommand {

    public BroadcastCommand() {
        super("broadcast", Collections.singletonList("bc"), "lazarus.broadcast");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.PREFIX + Lang.BROADCAST_USAGE);
            return;
        }

        String message = Color.translate(StringUtils.joinArray(args, " ", 1));
        Messages.sendMessage(Lang.BROADCAST_PREFIX + message);
    }
}
