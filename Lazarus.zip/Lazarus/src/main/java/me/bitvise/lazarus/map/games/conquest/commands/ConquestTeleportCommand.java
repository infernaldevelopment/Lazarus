package me.bitvise.lazarus.map.games.conquest.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.map.games.Cuboid;
import me.bitvise.lazarus.utils.provider.Lang;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.map.games.conquest.ZoneType;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class ConquestTeleportCommand extends SubCommand {

    public ConquestTeleportCommand() {
        super("teleport", Collections.singletonList("tp"), "lazarus.conquest.teleport", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.CONQUEST_PREFIX + Lang.CONQUEST_TELEPORT_USAGE);
            return;
        }

        ZoneType type;

        try {
            type = ZoneType.valueOf(args[0].toUpperCase());
        } catch(IllegalArgumentException e) {
            sender.sendMessage(Lang.CONQUEST_PREFIX + Lang.CONQUEST_EXCEPTION_INVALID_ZONE);
            return;
        }

        Cuboid cuboid = Lazarus.getInstance().getConquestManager().getConquest().getCuboid(type);

        if(cuboid == null) {
            sender.sendMessage(Lang.CONQUEST_PREFIX + Lang.CONQUEST_TELEPORT_ZONE_NOT_SET
            .replace("<zone>", type.getName()));
            return;
        }

        Player player = (Player) sender;
        player.teleport(cuboid.getCenter());
    }
}
