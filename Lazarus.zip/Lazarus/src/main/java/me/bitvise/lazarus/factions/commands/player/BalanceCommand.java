package me.bitvise.lazarus.factions.commands.player;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.type.PlayerFaction;

import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class BalanceCommand extends SubCommand {

    public BalanceCommand() {
        super("balance", Collections.singletonList("bal"), true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;
        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);

        if(faction == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
            return;
        }

        player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_BALANCE_MESSAGE
        .replace("<amount>", String.valueOf(faction.getBalance())));
    }
}
