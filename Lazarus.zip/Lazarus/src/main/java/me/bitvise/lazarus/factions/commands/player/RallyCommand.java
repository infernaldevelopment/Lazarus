package me.bitvise.lazarus.factions.commands.player;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.event.FactionRallyEvent;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.utils.StringUtils;

import me.bitvise.lazarus.utils.provider.Config;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class RallyCommand extends SubCommand {

    public RallyCommand() {
        super("rally", Collections.singletonList("setrally"), true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);

        if(faction == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
            return;
        }

        Location playerLocation = player.getLocation();

        faction.setRallyLocation(playerLocation);

        String location = Config.FACTION_RALLY_INCLUDE_Y_COORDINATE
            ? StringUtils.getLocationNameWithWorld(playerLocation)
            : StringUtils.getLocationNameWithWorldWithoutY(playerLocation);

        faction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_RALLY_SET
            .replace("<player>", player.getName())
            .replace("<location>", location));

        new FactionRallyEvent(player.getUniqueId(), playerLocation, faction, FactionRallyEvent.RallyEventType.ADD);
    }
}
