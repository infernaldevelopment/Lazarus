package me.bitvise.lazarus.factions.commands;

import me.bitvise.lazarus.commands.manager.SubCommandExecutor;
import me.bitvise.lazarus.factions.commands.admin.*;
import me.bitvise.lazarus.factions.commands.player.*;
import me.bitvise.lazarus.utils.provider.Lang;

import java.util.Arrays;

public class FactionsCommandExecutor extends SubCommandExecutor {

    public FactionsCommandExecutor() {
        super("faction", Arrays.asList("f", "factions", "t", "team", "teams"), Lang.FACTIONS_HELP_PAGES.get(1));

        this.setPrefix(Lang.FACTION_PREFIX);

        this.addSubCommand(new AddDtrCommand());
        this.addSubCommand(new ChatSpyCommand());
        this.addSubCommand(new ClaimForCommand());
        this.addSubCommand(new ClearClaimsCommand());
        this.addSubCommand(new ColorCommand());
        this.addSubCommand(new DeathbanCommand());
        this.addSubCommand(new EnderpearlsCommand());
        this.addSubCommand(new ForceDemoteCommand());
        this.addSubCommand(new ForceJoinCommand());
        this.addSubCommand(new ForceKickCommand());
        this.addSubCommand(new ForceLeaderCommand());
        this.addSubCommand(new ForcePromoteCommand());
        this.addSubCommand(new ForceRenameCommand());
        this.addSubCommand(new RemoveClaimCommand());
        this.addSubCommand(new RemoveCommand());
        this.addSubCommand(new RemoveDtrCommand());
        this.addSubCommand(new SafezoneCommand());
        this.addSubCommand(new SaveCommand());
        this.addSubCommand(new SetBalanceCommand());
        this.addSubCommand(new SetDtrCommand());
        this.addSubCommand(new SetFreezeCommand());
        this.addSubCommand(new SetLivesCommand());
        this.addSubCommand(new SetPointsCommand());
        this.addSubCommand(new SystemCreateCommand());
        this.addSubCommand(new SystemListCommand());
        this.addSubCommand(new SystemRenameCommand());
        this.addSubCommand(new ThawCommand());
        this.addSubCommand(new TpHereCommand());

        this.addSubCommand(new AllyCommand());
        this.addSubCommand(new AnnouncementCommand());
        this.addSubCommand(new AutoReviveCommand());
        this.addSubCommand(new BalanceCommand());
        this.addSubCommand(new ChatCommand());
        this.addSubCommand(new ClaimChunkCommand());
        this.addSubCommand(new ClaimCommand());
        this.addSubCommand(new CreateCommand());
        this.addSubCommand(new DemoteCommand());
        this.addSubCommand(new DepositCommand());
        this.addSubCommand(new DisbandCommand());
        this.addSubCommand(new FriendlyFireCommand());
        this.addSubCommand(new HelpCommand());
        this.addSubCommand(new HomeCommand());
        this.addSubCommand(new InviteCommand());
        this.addSubCommand(new JoinCommand());
        this.addSubCommand(new KickCommand());
        this.addSubCommand(new LeaderCommand());
        this.addSubCommand(new LeaveCommand());
        this.addSubCommand(new ListCommand());
        this.addSubCommand(new LivesCommand());
        this.addSubCommand(new LivesDepositCommand());
        this.addSubCommand(new LivesReviveCommand());
        this.addSubCommand(new LivesWithdrawCommand());
        this.addSubCommand(new MapCommand());
        this.addSubCommand(new OpenCommand());
        this.addSubCommand(new PromoteCommand());
        this.addSubCommand(new RallyCommand());
        this.addSubCommand(new RemoveRallyCommand());
        this.addSubCommand(new RenameCommand());
        this.addSubCommand(new SetHomeCommand());
        this.addSubCommand(new ShowCommand());
        this.addSubCommand(new StuckCommand());
        this.addSubCommand(new TopCommand());
        this.addSubCommand(new UnallyCommand());
        this.addSubCommand(new UnclaimAllCommand());
        this.addSubCommand(new UnclaimCommand());
        this.addSubCommand(new UninviteCommand());
        this.addSubCommand(new WithdrawCommand());
    }
}
