package me.bitvise.lazarus.factions.commands.admin;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.type.SystemType;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.command.CommandSender;

import java.util.Collections;

public class SystemCreateCommand extends SubCommand {

    public SystemCreateCommand() {
        super("systemcreate", Collections.singletonList("createsystem"), "lazarus.factions.systemcreate");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_SYSTEM_CREATE_USAGE);
            return;
        }

        if(FactionsManager.getInstance().getFactionByName(args[0]) != null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FACTION_ALREADY_EXISTS.replace("<name>", args[0]));
            return;
        }

        if(FactionsManager.getInstance().createSystemFaction(args[0], SystemType.DEFAULT, sender) == null) return;

        sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_SYSTEM_CREATED.replace("<name>", args[0]));
    }
}
