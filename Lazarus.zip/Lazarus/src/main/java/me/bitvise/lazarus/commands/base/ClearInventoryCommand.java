package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Arrays;

public class ClearInventoryCommand extends BaseCommand {

    public ClearInventoryCommand() {
        super("clearinventory", Arrays.asList("clear", "ci", "clearinv"), "lazarus.clearinventory");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            if(!this.checkConsoleSender(sender)) return;


            Player player = (Player) sender;
            int total = getItems(player);
            player.getInventory().clear();
            player.getInventory().setArmorContents(null);
            player.sendMessage(Lang.PREFIX + Lang.CLEARINVENTORY_MESSAGE_SELF.replace("<items>", String.valueOf(total)));
            return;
        }

        if(!this.checkPermission(sender, "lazarus.clearinventory.others")) return;

        Player target = Bukkit.getPlayer(args[0]);
        if(!this.checkPlayer(sender, target, args[0])) return;

        int total = getItems(target);

        target.getInventory().clear();
        target.getInventory().setArmorContents(null);

        target.sendMessage(Lang.PREFIX + Lang.CLEARINVENTORY_MESSAGE_SELF);
        sender.sendMessage(Lang.PREFIX + Lang.CLEARINVENTORY_MESSAGE_OTHERS.replace("<player>", target.getName()).replace("<items>", String.valueOf(total)).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target))));
    }

    private int getItems(Player player) {
        int index = 0;
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null) index += item.getAmount();
        }
        for (ItemStack item : player.getInventory().getArmorContents()) {
            if (item != null) index += item.getAmount();
        }
        return index;
    }
}
