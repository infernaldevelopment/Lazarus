package me.bitvise.lazarus;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import lombok.Getter;
import lombok.Setter;
import me.bitvise.lazarus.handlers.timer.ByrdeHandler;
import me.bitvise.lazarus.reboot.RebootHandler;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.handlers.staff.*;
import me.bitvise.lazarus.map.games.dtc.commands.DtcCommandExecutor;
import me.bitvise.lazarus.map.games.king.commands.KillTheKingCommandExecutor;
import me.bitvise.lazarus.animation.AnimateString;
import me.bitvise.lazarus.settings.Settings;
import me.bitvise.lazarus.storage.json.*;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.abilities.AbilitiesManager;
import me.bitvise.lazarus.classes.manager.PvpClassManager;
import me.bitvise.lazarus.commands.manager.CommandManager;
import me.bitvise.lazarus.commands.manager.SubCommandExecutor;
import me.bitvise.lazarus.storage.mongo.MongoManager;
import me.bitvise.lazarus.storage.mongo.manager.MongoClaimManager;
import me.bitvise.lazarus.storage.mongo.manager.MongoFactionsManager;
import me.bitvise.lazarus.storage.mongo.manager.MongoProfileManager;
import me.bitvise.lazarus.map.deathban.DeathbanManager;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.claim.ClaimManager;
import me.bitvise.lazarus.factions.commands.FactionsCommandExecutor;
import me.bitvise.lazarus.glass.GlassManager;
import me.bitvise.lazarus.handlers.BottleHandler;
import me.bitvise.lazarus.handlers.InventoryHandler;
import me.bitvise.lazarus.handlers.StatsHandler;
import me.bitvise.lazarus.handlers.block.AutoSmeltHandler;
import me.bitvise.lazarus.handlers.block.CrowbarHandler;
import me.bitvise.lazarus.handlers.block.FilterHandler;
import me.bitvise.lazarus.handlers.chat.ChatControlHandler;
import me.bitvise.lazarus.handlers.chat.MessagingHandler;
import me.bitvise.lazarus.handlers.death.DeathMessageHandler;
import me.bitvise.lazarus.handlers.kitmap.KillstreakHandler;
import me.bitvise.lazarus.handlers.limiter.PotionLimiterHandler;
import me.bitvise.lazarus.handlers.logger.CombatLoggerHandler;
import me.bitvise.lazarus.handlers.manager.Handler;
import me.bitvise.lazarus.handlers.manager.HandlerManager;
import me.bitvise.lazarus.handlers.portal.EndPortalHandler;
import me.bitvise.lazarus.handlers.rank.RankReviveHandler;
import me.bitvise.lazarus.handlers.rank.ReclaimHandler;
import me.bitvise.lazarus.handlers.restore.InventoryData;
import me.bitvise.lazarus.handlers.restore.InventoryRestoreManager;
import me.bitvise.lazarus.handlers.salvage.SalvageHandler;
import me.bitvise.lazarus.handlers.timer.EotwHandler;
import me.bitvise.lazarus.handlers.timer.SotwHandler;
import me.bitvise.lazarus.map.lunarclient.LunarClientManager;
import me.bitvise.lazarus.map.economy.coco.Economy_Coco;
import me.bitvise.lazarus.map.MapKitHandler;
import me.bitvise.lazarus.map.economy.EconomyManager;
import me.bitvise.lazarus.map.economy.SignShopManager;
import me.bitvise.lazarus.map.games.conquest.ConquestManager;
import me.bitvise.lazarus.map.games.conquest.commands.ConquestCommandExecutor;
import me.bitvise.lazarus.map.games.dragon.EnderDragonManager;
import me.bitvise.lazarus.map.games.dragon.commands.EnderDragonCommandExecutor;
import me.bitvise.lazarus.map.games.dtc.DtcManager;
import me.bitvise.lazarus.map.games.king.KillTheKingManager;
import me.bitvise.lazarus.map.games.koth.KothManager;
import me.bitvise.lazarus.map.games.koth.commands.KothCommandExecutor;
import me.bitvise.lazarus.map.games.loot.LootManager;
import me.bitvise.lazarus.map.games.loot.commands.LootCommandExecutor;
import me.bitvise.lazarus.map.games.mountain.MountainManager;
import me.bitvise.lazarus.map.games.mountain.commands.MountainCommandExecutor;
import me.bitvise.lazarus.map.games.schedule.ScheduleManager;
import me.bitvise.lazarus.map.games.schedule.commands.ScheduleCommandExecutor;
import me.bitvise.lazarus.map.kits.KitsManager;
import me.bitvise.lazarus.map.kits.commands.KitCommandExecutor;
import me.bitvise.lazarus.profile.ProfileManager;
import me.bitvise.lazarus.settings.SettingsManager;
import me.bitvise.lazarus.scoreboard.ScoreboardManager;
import me.bitvise.lazarus.staffmode.StaffModeManager;
import me.bitvise.lazarus.staffmode.VanishManager;
import me.bitvise.lazarus.tab.TabManager;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.storage.Storage;
import me.bitvise.lazarus.utils.GsonUtils;
import me.bitvise.lazarus.utils.ManagerEnabler;
import me.bitvise.lazarus.utils.PlayerUtils;
import me.bitvise.lazarus.utils.provider.Config;
import me.bitvise.lazarus.utils.creator.ConfigCreator;
import me.bitvise.lazarus.utils.item.ItemUtils;
import me.bitvise.lazarus.utils.nms.NmsUtils;
import me.bitvise.lazarus.claim.selection.SelectionManager;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

@Getter
public class Lazarus extends JavaPlugin {

    @Getter private static Lazarus instance;
    @Setter private boolean fullyEnabled;

    private Gson gson;

    @Setter private ConfigCreator config;
    @Setter private ConfigCreator language;
    @Setter private ConfigCreator scoreboardFile;
    @Setter private ConfigCreator tabFile;
    @Setter private ConfigCreator classesFile;
    @Setter private ConfigCreator limitersFile;
    @Setter private ConfigCreator abilitiesFile;
    @Setter private ConfigCreator itemsFile;
    @Setter private ConfigCreator menusFile;
    @Setter private ConfigCreator staffmodeFile;

    private ConfigCreator utilitiesFile;

    @Setter private MongoManager mongoManager;
    @Setter private ProfileManager profileManager;
    @Setter private TabManager tabManager;

    private DeathbanManager deathbanManager;
    private EconomyManager economyManager;
    private GlassManager glassManager;
    private InventoryRestoreManager inventoryRestoreManager;
    private KitsManager kitsManager;
    private LunarClientManager lunarClientManager;
    private PvpClassManager pvpClassManager;
    private SelectionManager selectionManager;
    private SignShopManager signShopManager;
    private StaffModeManager staffModeManager;
    private VanishManager vanishManager;
    private AbilitiesManager abilitiesManager;
    private ScoreboardManager scoreboardManager;
    private HandlerManager handlerManager;

    private ConquestManager conquestManager;
    private EnderDragonManager enderDragonManager;
    private DtcManager dtcManager;
    private KillTheKingManager killTheKingManager;
    private KothManager kothManager;
    private MountainManager mountainManager;
    private LootManager lootManager;
    private ScheduleManager scheduleManager;

    private CommandManager commandManager;
    private ConquestCommandExecutor conquestCommandExecutor;
    private EnderDragonCommandExecutor enderDragonCommandExecutor;
    private DtcCommandExecutor dtcCommandExecutor;
    private FactionsCommandExecutor factionsCommandExecutor;
    private KitCommandExecutor kitCommandExecutor;
    private KillTheKingCommandExecutor killTheKingCommandExecutor;
    private KothCommandExecutor kothCommandExecutor;
    private MountainCommandExecutor mountainCommandExecutor;
    private LootCommandExecutor lootCommandExecutor;
    private ScheduleCommandExecutor scheduleCommandExecutor;

    private AutoSmeltHandler autoSmeltHandler;
    private BottleHandler bottleHandler;
    private ChatControlHandler chatControlHandler;
    private CombatLoggerHandler combatLoggerHandler;
    private CrowbarHandler crowbarHandler;
    private DeathMessageHandler deathMessageHandler;
    private EndPortalHandler endPortalHandler;
    private EotwHandler eotwHandler;
    private FilterHandler filterHandler;
    private FreezeHandler freezeHandler;
    private InventoryHandler inventoryHandler;
    private KillstreakHandler killstreakHandler;
    private MapKitHandler mapkitHandler;
    private MessagingHandler messagingHandler;
    private NotesHandler notesHandler;
    private PotionLimiterHandler potionLimiterHandler;
    private RankReviveHandler rankReviveHandler;
    private RebootHandler rebootHandler;
    private ReclaimHandler reclaimHandler;
    private SalvageHandler salvageHandler;
    private Settings settingsHandler;
    private SotwHandler sotwHandler;
    private ByrdeHandler byrdeHandler;
    private StaffChatHandler staffChatHandler;
    private StatsHandler statsHandler;
    private WarpsHandler warpsHandler;

    @Override
    public void onEnable() {
        instance = this;

        log("");
        log("&eLazarus &4" + StringUtils.HEART);


        Config.START_TIME = System.currentTimeMillis();
        NmsUtils.init();

        Bukkit.getMessenger().registerOutgoingPluginChannel(this, "BungeeCord");

        try {
            this.config = new ConfigCreator("config.yml");
            this.language = new ConfigCreator("server/global-lang.yml");
            this.scoreboardFile = new ConfigCreator("server/scoreboard.yml");
            this.menusFile = new ConfigCreator("server/menus.yml");
            this.tabFile = new ConfigCreator("server/tab.yml");
            this.classesFile = new ConfigCreator("server/map/classes.yml");
            this.limitersFile = new ConfigCreator("server/map/limiters.yml");
            this.abilitiesFile = new ConfigCreator("server/abilities.yml");
            this.staffmodeFile = new ConfigCreator("server/staffmode.yml");
            this.itemsFile = new ConfigCreator("server/map/items.yml");
            this.utilitiesFile = new ConfigCreator("server/map/utilities.yml");
        } catch(RuntimeException e) {
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        this.beforeInit();

        if(!this.checkLunarClient()) return;

        try {
            this.setupDatastore();
            this.setupManagers();
            this.setupHandlers();
        } catch(Exception e) {
            this.log("");
            this.log("&cError while enabling:");
            this.log("");

            e.printStackTrace();

            this.log("");
            this.log("");
            Bukkit.getPluginManager().disablePlugin(this);
        }

    }

    @Override
    public void onDisable() {
        if(!this.fullyEnabled) return;

        this.scoreboardManager.disable();
        if(Config.TAB_ENABLED) this.tabManager.disable();

        ClaimManager.getInstance().disable();
        FactionsManager.getInstance().disable();
        TimerManager.getInstance().disable();
        this.profileManager.disable();

        this.disableManagers();
        this.disableGameManagers();
        this.disableCommandManagers();

        if(Storage.Storage == Storage.MONGO) {
            this.mongoManager.disable();
        }

        NmsUtils.getInstance().disable();
        Bukkit.getServicesManager().unregisterAll(this);

    }

    private void disableManagers() {
        this.deathbanManager.disable();
        this.handlerManager.disable();
        this.glassManager.disable();
        this.inventoryRestoreManager.disable();
        this.kitsManager.disable();
        this.pvpClassManager.disable();
        this.selectionManager.disable();
        this.signShopManager.disable();
        this.staffModeManager.disable();
        this.vanishManager.disable();
        this.abilitiesManager.disable();

        if(this.lunarClientManager != null) {
            this.lunarClientManager.disable();
        }
    }

    private void disableGameManagers() {
        this.conquestManager.disable();
        this.enderDragonManager.disable();
        this.dtcManager.disable();
        this.killTheKingManager.disable();
        this.kothManager.disable();
        this.mountainManager.disable();
        this.lootManager.disable();
        this.scheduleManager.disable();
    }

    private void disableCommandManagers() {
        this.commandManager.disable();
        this.conquestCommandExecutor.disable();
        this.enderDragonCommandExecutor.disable();
        this.dtcCommandExecutor.disable();
        this.factionsCommandExecutor.disable();
        this.kitCommandExecutor.disable();
        this.killTheKingCommandExecutor.disable();
        this.kothCommandExecutor.disable();
        this.mountainCommandExecutor.disable();
        this.lootCommandExecutor.disable();
        this.scheduleCommandExecutor.disable();
    }

    private void beforeInit() {
        ChatHandler.setup();
        ItemUtils.setupItemStackMaps();
        PlayerUtils.setupMetadataValue();
        AnimateString.setup();

        this.registerGson();
        this.registerVaultSupport();

        new Config();
        new Lang();
    }
    
    private boolean checkLunarClient() {
        if(Config.LUNAR_CLIENT_API_ENABLED && !Bukkit.getPluginManager().isPluginEnabled("LunarClient-API")) {
            Bukkit.getPluginManager().disablePlugin(this);
            return false;
        }
        
        return true;
    }

    private void setupDatastore() {
        if(Storage.Storage == Storage.JSON) {
            new FactionsManager();
            new ClaimManager();
            this.profileManager = new ProfileManager();
        } else {
            this.mongoManager = new MongoManager();

            new MongoFactionsManager();
            new MongoClaimManager();
            this.profileManager = new MongoProfileManager();
        }

        new TimerManager();
    }

    private void setupManagers() throws Exception {
        for(Field field : this.getClass().getDeclaredFields()) {
            if(!ManagerEnabler.class.isAssignableFrom(field.getType()) && field.getType().getSuperclass() != SubCommandExecutor.class) continue;

            field.setAccessible(true);

            Constructor<?> constructor = field.getType().getDeclaredConstructor();
            field.set(this, constructor.newInstance());
        }

        if(Config.TAB_ENABLED) {
            this.tabManager = new TabManager();
        }

        if(Config.LUNAR_CLIENT_API_ENABLED && Bukkit.getPluginManager().isPluginEnabled("LunarClient-API")) {
            this.lunarClientManager = new LunarClientManager();
        }
    }

    private void setupHandlers() throws Exception {
        for(Field field : this.getClass().getDeclaredFields()) {
            if(field.getType().getSuperclass() != Handler.class) continue;

            field.setAccessible(true);
            field.set(this, this.handlerManager.getHandler(field.getType()));
        }
        this.fullyEnabled = true;
    }

    public void registerGson() {
        this.gson = new GsonBuilder().setPrettyPrinting().serializeNulls()
            .enableComplexMapKeySerialization().excludeFieldsWithModifiers(Modifier.TRANSIENT, Modifier.STATIC)
            .registerTypeAdapter(GsonUtils.PLAYER_TYPE, new PlayerTypeAdapter())
            .registerTypeAdapter(GsonUtils.FACTION_TYPE, new FactionTypeAdapter())
            .registerTypeAdapter(GsonUtils.LOOT_TYPE, new LootTypeAdapter())
            .registerTypeAdapter(Location.class, new LocationTypeAdapter())
            .registerTypeAdapter(InventoryData.class, new RestoreTypeAdapter())
            .registerTypeAdapter(SettingsManager.class, new SettingsTypeAdapter())
        .create();
    }

    public void registerVaultSupport() {
        Plugin vaultPlugin = Bukkit.getPluginManager().getPlugin("Vault");
        if(vaultPlugin == null || !vaultPlugin.isEnabled()) return;

        Bukkit.getServicesManager().register(Economy.class, new Economy_Coco(), this, ServicePriority.Highest);
    }

    public static String translate(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);

    }

    public void log(String text) {
        Bukkit.getConsoleSender().sendMessage(translate(text));
    }

    public ClassLoader getPluginClassLoader() {
        return this.getClassLoader();
    }
}
