package me.bitvise.lazarus.handlers.timer;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.factions.event.FactionCreateEvent;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.factions.type.SystemFaction;
import me.bitvise.lazarus.map.games.koth.KothData;
import me.bitvise.lazarus.map.games.koth.RunningKoth;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.timer.scoreboard.PvpProtTimer;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.Tasks;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.handlers.manager.Handler;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public class EotwHandler extends Handler implements Listener {

    private boolean running;

    public boolean isActive() {
        return this.running;
    }

    private boolean isPreTaskOrActive() {
        return TimerManager.getInstance().getEotwTimer().isActive() || this.running;
    }

    public void startPreEotwTask(CommandSender sender, int delay) {
        if(this.isPreTaskOrActive()) {
            sender.sendMessage(Lang.PREFIX + Lang.EOTW_ALREADY_RUNNING);
            return;
        }

        KothData koth = Lazarus.getInstance().getKothManager().getKoth("EOTW");

        if(koth == null) {
            sender.sendMessage(Lang.PREFIX + Lang.EOTW_NO_EOTW_KOTH);
            return;
        }

        TimerManager.getInstance().getEotwTimer().activate(sender, delay);
        Messages.sendMessage(Lang.EOTW_TIMER_STARTED.replace("<seconds>", String.valueOf(delay)));
    }

    public void startEotw(int delay) {
        KothData koth = Lazarus.getInstance().getKothManager().getKoth("EOTW");

        if(koth == null) {
            Messages.sendMessage(Lang.PREFIX + Lang.EOTW_NO_EOTW_KOTH, "lazarus.staff");
            return;
        }

        this.running = true;

        Lazarus.getInstance().getKothManager().startKoth(koth, Config.KOTH_DEFAULT_CAP_TIME);
        FactionsManager.getInstance().setAllRaidable(true);

        SystemFaction spawnFaction = (SystemFaction) FactionsManager.getInstance().getFactionByName("Spawn");
        spawnFaction.setSafezone(false);
        spawnFaction.setDeathban(true);

        PvpProtTimer timer = TimerManager.getInstance().getPvpProtTimer();

        Bukkit.getOnlinePlayers().forEach(player -> {
            if(!timer.isActive(player)) return;

            timer.cancel(player);
            player.sendMessage(Lang.PREFIX + Lang.EOTW_PVP_TIMER_DISABLED);
        });

        if(Config.EOTW_CLEAR_DEATHBANS_ON_START) {
            Lazarus.getInstance().getDeathbanManager().deleteAllDeathbans(false);
        }

        Messages.sendMessage(Lang.EOTW_BROADCAST_START);
    }

    public void stopEotw(CommandSender sender) {
        if(!this.isPreTaskOrActive()) {
            sender.sendMessage(Lang.PREFIX + Lang.EOTW_NOT_RUNNING);
            return;
        }

        this.running = false;

        RunningKoth koth = Lazarus.getInstance().getKothManager().getRunningKoth("EOTW");

        if(koth != null) {
            Lazarus.getInstance().getKothManager().stopKoth(koth);
        }

        SystemFaction spawnFaction = (SystemFaction) FactionsManager.getInstance().getFactionByName("Spawn");
        spawnFaction.setSafezone(true);
        spawnFaction.setDeathban(false);

        FactionsManager.getInstance().setAllRaidable(false);

        TimerManager.getInstance().getEotwTimer().cancel();
        Messages.sendMessage(Lang.EOTW_BROADCAST_STOP);
    }

    @EventHandler(ignoreCancelled = true)
    public void onFactionCreate(FactionCreateEvent event) {
        if(!this.isActive() || event.getFactionType() != FactionCreateEvent.FactionType.PLAYER_FACTION) return;

        Tasks.async(() -> {
            PlayerFaction faction = FactionsManager.getInstance().getPlayerFactionByName(event.getFactionName());
            if(faction == null) return;

            faction.setDtr(Config.FACTION_MIN_DTR);
        });
    }
}
