package me.bitvise.lazarus.commands.staff;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;

public class EotwCommand extends BaseCommand {

    public EotwCommand() {
        super("eotw", "lazarus.eotw");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 1 && "stop".equalsIgnoreCase(args[0])) {
            Lazarus.getInstance().getEotwHandler().stopEotw(sender);
            return;
        }

        if(args.length == 2 && "start".equalsIgnoreCase(args[0])) {
            if(!(sender instanceof ConsoleCommandSender)) {
                sender.sendMessage(Lang.PREFIX + Lang.COMMANDS_FOR_CONSOLE_ONLY);
                return;
            }

            int time = StringUtils.parseSeconds(args[1]);

            if(time == -1) {
                sender.sendMessage(Lang.KIT_PREFIX + Lang.COMMANDS_INVALID_DURATION);
                return;
            }

            Lazarus.getInstance().getEotwHandler().startPreEotwTask(sender, time);
            return;
        }

        Lang.EOTW_COMMAND_USAGE.forEach(sender::sendMessage);
    }
}
