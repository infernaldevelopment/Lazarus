package me.bitvise.lazarus.handlers.staff;

import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.handlers.manager.Handler;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class StaffChatHandler extends Handler implements Listener {

    private final List<UUID> staffChat;

    public StaffChatHandler() {
        this.staffChat = new ArrayList<>();
    }

    @Override
    public void disable() {
        this.staffChat.clear();
    }

    public void toggleStaffChat(Player player) {
        if(this.isStaffChatEnabled(player)) {
            this.staffChat.remove(player.getUniqueId());
            player.sendMessage(Lang.PREFIX + Lang.STAFF_CHAT_DISABLED);
        } else {
            this.staffChat.add(player.getUniqueId());
            player.sendMessage(Lang.PREFIX + Lang.STAFF_CHAT_ENABLED);
        }
    }

    public boolean isStaffChatEnabled(Player player) {
        return this.staffChat.contains(player.getUniqueId());
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOWEST)
    public void onAsyncPlayerChatEvent(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        if(!this.isStaffChatEnabled(event.getPlayer())) return;

        if(!event.getPlayer().hasPermission("lazarus.staffchat")) {
            this.staffChat.remove(event.getPlayer().getUniqueId());
            return;
        }

        event.setCancelled(true);
        String prefix = Color.translate(ChatHandler.getInstance().getPrefix(player));

        Messages.sendMessage(Lang.STAFF_CHAT_FORMAT.replace("<player>", player.getName()).replace("<message>", event.getMessage()).replace("<prefix>", prefix), "lazarus.staff");
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        this.staffChat.remove(event.getPlayer().getUniqueId());
    }
}
