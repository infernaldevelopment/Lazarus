package me.bitvise.lazarus.map.economy.coco;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.map.economy.EconomyManager;
import me.bitvise.lazarus.profile.Profile;
import me.bitvise.lazarus.utils.provider.Config;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import net.milkbowl.vault.economy.EconomyResponse.ResponseType;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

import java.util.ArrayList;
import java.util.List;

public class Economy_Coco implements Economy {

    @Override
    public boolean isEnabled() {
        return Lazarus.getInstance().isEnabled();
    }

    @Override
    public String getName() {
        return "Coco";
    }

    @Override
    public boolean hasBankSupport() {
        return false;
    }

    @Override
    public int fractionalDigits() {
        return -1;
    }

    @Override
    public String format(double balance) {
        return String.valueOf(balance);
    }

    @Override
    public String currencyNamePlural() {
        return "";
    }

    @Override
    public String currencyNameSingular() {
        return "";
    }

    @Override
    public boolean hasAccount(OfflinePlayer offlinePlayer) {
        return Lazarus.getInstance().getProfileManager().getUserdata(offlinePlayer) != null;
    }

    @Override
    public boolean hasAccount(String playerName) {
        return this.hasAccount(Bukkit.getOfflinePlayer(playerName));
    }

    @Override
    public boolean hasAccount(OfflinePlayer offlinePlayer, String worldName) {
        return this.hasAccount(offlinePlayer);
    }

    @Override
    public boolean hasAccount(String playerName, String worldName) {
        return this.hasAccount(playerName);
    }

    @Override
    public double getBalance(OfflinePlayer offlinePlayer) {
        Profile profile = Lazarus.getInstance().getProfileManager().getUserdata(offlinePlayer);
        return profile == null ? 0 : profile.getBalance();
    }

    @Override
    public double getBalance(String playerName) {
        return this.getBalance(Bukkit.getOfflinePlayer(playerName));
    }

    @Override
    public double getBalance(OfflinePlayer offlinePlayer, String worldName) {
        return this.getBalance(offlinePlayer);
    }

    @Override
    public double getBalance(String playerName, String worldName) {
        return this.getBalance(playerName);
    }

    @Override
    public boolean has(OfflinePlayer offlinePlayer, double amount) {
        return this.getBalance(offlinePlayer) >= amount;
    }

    @Override
    public boolean has(String playerName, double amount) {
        return this.getBalance(playerName) >= amount;
    }

    @Override
    public boolean has(OfflinePlayer offlinePlayer, String worldName, double amount) {
        return this.has(offlinePlayer, amount);
    }

    @Override
    public boolean has(String playerName, String worldName, double amount) {
        return this.has(playerName, amount);
    }

    @Override
    public EconomyResponse withdrawPlayer(OfflinePlayer offlinePlayer, double amount) {
        Profile profile = Lazarus.getInstance().getProfileManager().getUserdata(offlinePlayer);

        if(profile == null) {
            return new EconomyResponse(0, 0, ResponseType.FAILURE, "User " + offlinePlayer.getName() + " never played on this server!");
        }

        EconomyManager.TransactionResult result = this.withdrawBalance(profile, (int) amount);

        if(result == EconomyManager.TransactionResult.INVALID_AMOUNT) {
            return new EconomyResponse(0, profile.getBalance(), ResponseType.FAILURE, "Cannot withdraw negative funds");
        } else if(result == EconomyManager.TransactionResult.MIN_BALANCE) {
            return new EconomyResponse(0, profile.getBalance(), ResponseType.FAILURE, "Insufficient funds");
        } else {
            return new EconomyResponse(amount, profile.getBalance(), ResponseType.SUCCESS, "");
        }
    }

    @Override
    public EconomyResponse withdrawPlayer(String playerName, double amount) {
        return this.withdrawPlayer(Bukkit.getOfflinePlayer(playerName), amount);
    }

    @Override
    public EconomyResponse withdrawPlayer(OfflinePlayer offlinePlayer, String worldName, double amount) {
        return this.withdrawPlayer(offlinePlayer, amount);
    }

    @Override
    public EconomyResponse withdrawPlayer(String playerName, String worldName, double amount) {
        return this.withdrawPlayer(playerName, amount);
    }

    @Override
    public EconomyResponse depositPlayer(OfflinePlayer offlinePlayer, double amount) {
        Profile profile = Lazarus.getInstance().getProfileManager().getUserdata(offlinePlayer);

        if(profile == null) {
            return new EconomyResponse(0, 0, ResponseType.FAILURE, "User " + offlinePlayer.getName() + " never played on this server!");
        }

        EconomyManager.TransactionResult result = this.depositBalance(profile, (int) amount);

        if(result == EconomyManager.TransactionResult.INVALID_AMOUNT) {
            return new EconomyResponse(0, profile.getBalance(), ResponseType.FAILURE, "Cannot deposit negative funds");
        } else if(result == EconomyManager.TransactionResult.MAX_BALANCE) {
            return new EconomyResponse(0, profile.getBalance(), ResponseType.FAILURE, "User exceeded balance limit");
        } else {
            return new EconomyResponse(amount, profile.getBalance(), ResponseType.SUCCESS, "");
        }
    }

    @Override
    public EconomyResponse depositPlayer(String playerName, double amount) {
        return this.depositPlayer(Bukkit.getOfflinePlayer(playerName), amount);
    }

    @Override
    public EconomyResponse depositPlayer(OfflinePlayer offlinePlayer, String worldName, double amount) {
        return this.depositPlayer(offlinePlayer, amount);
    }

    @Override
    public EconomyResponse depositPlayer(String playerName, String worldName, double amount) {
        return this.depositPlayer(playerName, amount);
    }

    @Override
    public EconomyResponse createBank(String name, OfflinePlayer offlinePlayer) {
        return new EconomyResponse(0, 0, ResponseType.NOT_IMPLEMENTED, "Coco does not support bank accounts!");
    }

    @Override
    public EconomyResponse createBank(String name, String playerName) {
        return new EconomyResponse(0, 0, ResponseType.NOT_IMPLEMENTED, "Coco does not support bank accounts!");
    }

    @Override
    public EconomyResponse deleteBank(String name) {
        return new EconomyResponse(0, 0, ResponseType.NOT_IMPLEMENTED, "Coco does not support bank accounts!");
    }

    @Override
    public EconomyResponse bankBalance(String name) {
        return new EconomyResponse(0, 0, ResponseType.NOT_IMPLEMENTED, "Coco does not support bank accounts!");
    }

    @Override
    public EconomyResponse bankHas(String name, double amount) {
        return new EconomyResponse(0, 0, ResponseType.NOT_IMPLEMENTED, "Coco does not support bank accounts!");
    }

    @Override
    public EconomyResponse bankWithdraw(String name, double amount) {
        return new EconomyResponse(0, 0, ResponseType.NOT_IMPLEMENTED, "Coco does not support bank accounts!");
    }

    @Override
    public EconomyResponse bankDeposit(String name, double amount) {
        return new EconomyResponse(0, 0, ResponseType.NOT_IMPLEMENTED, "Coco does not support bank accounts!");
    }

    @Override
    public EconomyResponse isBankOwner(String name, OfflinePlayer offlinePlayer) {
        return new EconomyResponse(0, 0, ResponseType.NOT_IMPLEMENTED, "Coco does not support bank accounts!");
    }

    @Override
    public EconomyResponse isBankOwner(String name, String playerName) {
        return new EconomyResponse(0, 0, ResponseType.NOT_IMPLEMENTED, "Coco does not support bank accounts!");
    }

    @Override
    public EconomyResponse isBankMember(String name, OfflinePlayer offlinePlayer) {
        return new EconomyResponse(0, 0, ResponseType.NOT_IMPLEMENTED, "Coco does not support bank accounts!");
    }

    @Override
    public EconomyResponse isBankMember(String name, String playerName) {
        return new EconomyResponse(0, 0, ResponseType.NOT_IMPLEMENTED, "Coco does not support bank accounts!");
    }

    @Override
    public List<String> getBanks() {
        return new ArrayList<>();
    }

    @Override
    public boolean createPlayerAccount(OfflinePlayer offlinePlayer) {
        throw new UnsupportedOperationException("This function is not supported!");
    }

    @Override
    public boolean createPlayerAccount(String playerName) {
        throw new UnsupportedOperationException("This function is not supported!");
    }

    @Override
    public boolean createPlayerAccount(OfflinePlayer offlinePlayer, String worldName) {
        throw new UnsupportedOperationException("This function is not supported!");
    }

    @Override
    public boolean createPlayerAccount(String playerName, String worldName) {
        throw new UnsupportedOperationException("This function is not supported!");
    }

    private EconomyManager.TransactionResult depositBalance(Profile profile, int amount) {
        if(amount <= 0) {
            return EconomyManager.TransactionResult.INVALID_AMOUNT;
        }

        if(profile.getBalance() + amount > Config.MAX_BALANCE) {
            return EconomyManager.TransactionResult.MAX_BALANCE;
        }

        profile.setBalance(profile.getBalance() + amount);
        return EconomyManager.TransactionResult.SUCCESS;
    }

    private EconomyManager.TransactionResult withdrawBalance(Profile profile, int amount) {
        if(amount <= 0) {
            return EconomyManager.TransactionResult.INVALID_AMOUNT;
        }

        if(profile.getBalance() < amount) {
            return EconomyManager.TransactionResult.MIN_BALANCE;
        }

        profile.setBalance(profile.getBalance() - amount);
        return EconomyManager.TransactionResult.SUCCESS;
    }
}
