package me.bitvise.lazarus.map.games.schedule.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.commands.manager.SubCommand;
import org.bukkit.command.CommandSender;

public class ScheduleClearCommand extends SubCommand {

    ScheduleClearCommand() {
        super("clear", "lazarus.schedule.clear");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Lazarus.getInstance().getScheduleManager().clearSchedule(sender);
    }
}
