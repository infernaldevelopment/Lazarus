package me.bitvise.lazarus.commands.staff;

import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Config;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;

public class SuperSayCommand extends BaseCommand {

    public SuperSayCommand() {
        super("supersay", Arrays.asList("massay", "allsay"), "lazarus.command.supersay", true);
    }


    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;
        if (args.length == 0) {
            sender.sendMessage(Lang.PREFIX + Lang.SUPERSAY_COMMAND_USAGE);
            return;
        }

        Bukkit.getOnlinePlayers().forEach(online -> {
            online.chat(StringUtils.buildMessage(args, 0));
        });

        sender.sendMessage(Lang.SUPERSAY_COMMAND_SENT.toString()
                .replace("<message>", StringUtils.buildMessage(args, 0)).replace("<online>", Bukkit.getOnlinePlayers().size() + ""));

        player.playSound(player.getLocation(), Sound.valueOf(Config.SUPERSAY_SOUND), 2.5f, 2.5f);
    }
}
