package me.bitvise.lazarus.commands.staff;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;

public class StaffChatCommand extends BaseCommand {

    public StaffChatCommand() {
        super("staffchat", Arrays.asList("sc", "staffc", "schat"), "lazarus.staffchat", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        if(args.length == 0) {
            Lazarus.getInstance().getStaffChatHandler().toggleStaffChat(player);
            return;
        }

        String message = StringUtils.joinArray(args, " ", 1);
        String prefix = Color.translate(ChatHandler.getInstance().getPrefix(player));


        Messages.sendMessage(Lang.STAFF_CHAT_FORMAT.replace("<prefix>", prefix).replace("<player>", player.getName()).replace("<message>", message), "lazarus.staff");
    }
}
