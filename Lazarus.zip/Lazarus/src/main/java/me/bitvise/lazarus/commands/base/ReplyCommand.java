package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class ReplyCommand extends BaseCommand {

    public ReplyCommand() {
        super("reply", Collections.singletonList("r"), true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.PREFIX + Lang.REPLY_USAGE);
            return;
        }

        Player player = (Player) sender;

        Lazarus.getInstance().getMessagingHandler().sendReplyMessage(player, StringUtils.joinArray(args, " ", 1));
    }
}
