package me.bitvise.lazarus.map.games.loot.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.provider.Lang;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.map.games.loot.LootData;
import me.bitvise.lazarus.utils.InventoryUtils;
import org.bukkit.command.CommandSender;

public class LootClearCommand extends SubCommand {

    public LootClearCommand() {
        super("clear", "lazarus.loot.clear");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.LOOT_PREFIX + Lang.LOOT_CLEAR_USAGE);
            return;
        }

        LootData loot = Lazarus.getInstance().getLootManager().getLootByName(args[0]);

        if(loot == null) {
            sender.sendMessage(Lang.LOOT_PREFIX + Lang.LOOT_EXCEPTION_DOESNT_EXIST.replace("<loot>", args[0]));
            return;
        }

        loot.getInventory().clear();
        loot.setItems(InventoryUtils.getItemsFromInventory(loot.getInventory()));

        sender.sendMessage(Lang.LOOT_PREFIX + Lang.LOOT_CLEAR_CLEARED.replace("<loot>", loot.getName()));
    }
}
