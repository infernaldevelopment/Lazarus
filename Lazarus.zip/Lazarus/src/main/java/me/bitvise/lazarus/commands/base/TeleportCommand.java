package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class TeleportCommand extends BaseCommand {

    public TeleportCommand() {
        super("teleport", Collections.singletonList("tp"), "lazarus.teleport", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        if(args.length == 0) {
            player.sendMessage(Lang.PREFIX + Lang.TELEPORT_USAGE);
            return;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if(!this.checkPlayer(sender, target, args[0])) return;

        if(!player.teleport(target)) return;
        player.sendMessage(Lang.PREFIX + Lang.TELEPORT_MESSAGE.replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target))).replace("<player>", target.getName()));
    }
}
