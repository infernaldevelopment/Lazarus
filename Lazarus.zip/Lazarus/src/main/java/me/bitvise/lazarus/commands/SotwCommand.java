package me.bitvise.lazarus.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.timer.scoreboard.SotwTimer;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.Tasks;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SotwCommand extends BaseCommand {

	public SotwCommand() {
		super("sotw");
	}

	@Override
	public void execute(CommandSender sender, String[] args) {
		if(args.length == 0) {
			(sender.hasPermission("lazarus.sotw")
				? Lang.SOTW_ADMIN_COMMAND_USAGE
				: Lang.SOTW_PLAYER_COMMAND_USAGE).forEach(sender::sendMessage);
			return;
		}

		if(args.length == 1) {
			switch(args[0].toLowerCase()) {
				case "start": {
					if(!checkPermission(sender, "lazarus.sotw")) return;
					Lazarus.getInstance().getSotwHandler().startSotwTimer(sender, Config.SOTW_DEFAULT_TIME * 60);
					return;
				}
				case "stop": {
					if(!checkPermission(sender, "lazarus.sotw")) return;
					Lazarus.getInstance().getSotwHandler().stopSotwTimer(sender);
					return;
				}
				case "hideplayers": {
					if(!checkPermission(sender, "lazarus.sotw")) return;
					Tasks.async(() -> Lazarus.getInstance().getSotwHandler().toggleSotwInvisibility(sender, null));
					return;
				}
				case "enable": {
					if(!this.checkConsoleSender(sender)) return;
					Lazarus.getInstance().getSotwHandler().enableSotwForPlayer((Player) sender);
					return;
				}
				case "time": {
					SotwTimer sotwTimer = TimerManager.getInstance().getSotwTimer();

					if(!sotwTimer.isActive()) {
						sender.sendMessage(Lang.PREFIX + Lang.SOTW_NOT_RUNNING);
						return;
					}

					sender.sendMessage(Lang.PREFIX + Lang.SOTW_TIME_STATUS
					.replace("<time>", sotwTimer.getDynamicTimeLeft()));
					return;
				}
				default: {
					(sender.hasPermission("lazarus.sotw")
						? Lang.SOTW_ADMIN_COMMAND_USAGE
						: Lang.SOTW_PLAYER_COMMAND_USAGE).forEach(sender::sendMessage);
				}
			}
		} else {
			if(!checkPermission(sender, "lazarus.sotw")) return;

			if(args[0].equalsIgnoreCase("start")) {
				int time = StringUtils.parseSeconds(args[1]);

				if(time == -1) {
					sender.sendMessage(Lang.KIT_PREFIX + Lang.COMMANDS_INVALID_DURATION);
					return;
				}

				Lazarus.getInstance().getSotwHandler().startSotwTimer(sender, time);
			} else {
				Lang.SOTW_ADMIN_COMMAND_USAGE.forEach(sender::sendMessage);
			}
		}
	}
}
