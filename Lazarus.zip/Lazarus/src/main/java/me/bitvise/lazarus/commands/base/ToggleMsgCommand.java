package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.profile.Profile;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;

public class ToggleMsgCommand extends BaseCommand {

    public ToggleMsgCommand() {
        super("togglemessages", Arrays.asList("togglemsg", "tmsg", "togglepm", "tpm"), true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        Profile data = Lazarus.getInstance().getProfileManager().getUserdata(player);
        data.getSettings().setMessages(!data.getSettings().isMessages());

        player.sendMessage(Lang.PREFIX + (data.getSettings().isMessages()
        ? Lang.TOGGLE_MESSAGES_TOGGLED_ON : Lang.TOGGLE_MESSAGES_TOGGLED_OFF));
    }
}
