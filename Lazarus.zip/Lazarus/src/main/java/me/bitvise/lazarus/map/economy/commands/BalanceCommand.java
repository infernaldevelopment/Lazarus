package me.bitvise.lazarus.map.economy.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.utils.Color;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;

public class BalanceCommand extends BaseCommand {

    public BalanceCommand() {
        super("balance", Arrays.asList("bal", "money"));

        this.setExecuteAsync(true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            if(sender instanceof ConsoleCommandSender) {
                sender.sendMessage(Lang.PREFIX + Lang.COMMANDS_FOR_PLAYERS_ONLY);
                return;
            }

            Player player = (Player) sender;

            sender.sendMessage(Lang.PREFIX + Lang.ECONOMY_BALANCE_SELF.replace("<amount>",
            String.valueOf(Lazarus.getInstance().getEconomyManager().getBalance(player))));
            return;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        if(!this.checkOfflinePlayer(sender, target, args[0])) return;

        sender.sendMessage(Lang.PREFIX + Lang.ECONOMY_BALANCE_OTHERS.replace("<player>", target.getName())
        .replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix((Player) target))).replace("<amount>", String.valueOf(Lazarus.getInstance().getEconomyManager().getBalance(target))));
    }
}
