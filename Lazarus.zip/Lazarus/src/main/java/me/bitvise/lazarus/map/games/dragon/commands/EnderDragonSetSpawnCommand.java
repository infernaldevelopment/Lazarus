package me.bitvise.lazarus.map.games.dragon.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.utils.StringUtils;

import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class EnderDragonSetSpawnCommand extends SubCommand {

    public EnderDragonSetSpawnCommand() {
        super("setspawn", "lazarus.enderdragon.setspawn", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        if(player.getWorld().getEnvironment() != World.Environment.THE_END) {
            player.sendMessage(Lang.ENDER_DRAGON_PREFIX + Lang.ENDER_DRAGON_SET_SPAWN_NOT_IN_END);
            return;
        }

        Lazarus.getInstance().getEnderDragonManager().setSpawnLocation(player);

        player.sendMessage(Lang.ENDER_DRAGON_PREFIX + Lang.ENDER_DRAGON_SET_SPAWN_SET
        .replace("<location>", StringUtils.getLocationName(player.getLocation())));
    }
}
