package me.bitvise.lazarus.factions.commands.admin;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.claim.ClaimManager;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.factions.FactionsManager;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SaveCommand extends SubCommand {

    public SaveCommand() {
        super("save", "lazarus.factions.save");

        this.setExecuteAsync(true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {

        Lazarus.getInstance().log("");
        FactionsManager.getInstance().saveFactions(true, false);
        FactionsManager.getInstance().savePlayers(true);
        ClaimManager.getInstance().saveClaims(true);
        Lazarus.getInstance().log("");

        if (sender instanceof Player) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_SAVED.replace("<factions>", FactionsManager.getInstance().getFactions().size() + ""));
        }
    }
}
