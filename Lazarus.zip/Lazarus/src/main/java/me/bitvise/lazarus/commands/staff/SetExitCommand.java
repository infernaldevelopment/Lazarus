package me.bitvise.lazarus.commands.staff;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.LocationUtils;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.handlers.event.ExitSetEvent;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.Location;
import org.bukkit.World.Environment;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SetExitCommand extends BaseCommand {

    public SetExitCommand() {
        super("setexit", "lazarus.setexit", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        if(args.length == 0) {
            Lang.SET_EXIT_USAGE.forEach(player::sendMessage);
            return;
        }

        switch(args[0].toLowerCase()) {
            case "nether":
                this.setExit(player, Environment.NETHER, "NETHER");
                return;
            case "end": {
                this.setExit(player, Environment.THE_END, "END");
                return;
            }
            default: Lang.SET_EXIT_USAGE.forEach(player::sendMessage);
        }
    }

    private void setExit(Player player, Environment environment, String world) {
        Location location = player.getLocation();
        Config.WORLD_EXITS.put(environment, location);

        new ExitSetEvent(player, environment, location);

        String worldName = StringUtils.getWorldName(player.getWorld());
        int x = location.getBlockX();
        int y = location.getBlockY();
        int z = location.getBlockZ();

        player.sendMessage(Lang.PREFIX + Lang.SET_EXIT_EXIT_SET
            .replace("<worldName>", StringUtils.capitalize(world.toLowerCase()))
            .replace("<world>", worldName)
            .replace("<x>", String.valueOf(x))
            .replace("<y>", String.valueOf(y))
            .replace("<z>", String.valueOf(z)));

        Lazarus.getInstance().getUtilitiesFile().set(world + "_EXIT", LocationUtils.locationToString(location));
        Lazarus.getInstance().getUtilitiesFile().save();
    }
}
