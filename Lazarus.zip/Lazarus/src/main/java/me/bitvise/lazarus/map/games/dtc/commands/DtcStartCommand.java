package me.bitvise.lazarus.map.games.dtc.commands;

import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.commands.manager.SubCommand;

import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.command.CommandSender;

public class DtcStartCommand extends SubCommand {

    DtcStartCommand() {
        super("start", "lazarus.dtc.start");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(Lazarus.getInstance().getDtcManager().isActive()) {
            sender.sendMessage(Lang.DTC_PREFIX + Lang.DTC_START_ALREADY_RUNNING);
            return;
        }

        if(args.length == 0) {
            Lazarus.getInstance().getDtcManager().startDtc(sender, Config.DTC_CORE_BREAKS);
            return;
        }

        if(!this.checkNumber(sender, args[0])) return;

        Lazarus.getInstance().getDtcManager().startDtc(sender, Integer.parseInt(args[0]));
    }
}
