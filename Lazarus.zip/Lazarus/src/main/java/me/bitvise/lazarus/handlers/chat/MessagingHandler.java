package me.bitvise.lazarus.handlers.chat;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.handlers.manager.Handler;
import me.bitvise.lazarus.profile.Profile;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.*;

public class MessagingHandler extends Handler implements Listener {

    private final Map<UUID, UUID> replies;
    private final Set<UUID> socialSpy;

    public MessagingHandler() {
        this.replies = new HashMap<>();
        this.socialSpy = new HashSet<>();
    }

    @Override
    public void disable() {
        this.replies.clear();
        this.socialSpy.clear();
    }

    public void sendMessage(Player sender, Player target, String message) {
        if(!this.isIgnoring(sender, target, message)) {
            this.sendMessageToBoth(sender, target, message);
        }
    }

    public void sendReplyMessage(Player sender, String message) {
        Player target = Bukkit.getPlayer(this.replies.get(sender.getUniqueId()));

        if(target == null) {
            sender.sendMessage(Lang.PREFIX + Lang.REPLY_NOBODY_TO_REPLY);
            this.replies.remove(sender.getUniqueId());
            return;
        }

        this.sendMessage(sender, target, message);
    }

    private void sendMessageToBoth(Player sender, Player target, String message) {
        this.replies.put(sender.getUniqueId(), target.getUniqueId());
        this.replies.put(target.getUniqueId(), sender.getUniqueId());

        sender.sendMessage(Lang.MESSAGE_SEND_FORMAT
            .replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target)))
            .replace("<player>", target.getName()) + message);

        target.sendMessage(Lang.MESSAGE_RECEIVE_FORMAT
            .replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(sender)))
            .replace("<player>", sender.getName()) + message);

        this.socialSpy.stream().map(Bukkit::getPlayer).forEach(staff -> staff.sendMessage(Lang.SOCIAL_SPY_MESSAGE_FORMAT
        .replace("<sender>", sender.getName()).replace("<target>", target.getName()).replace("<message>", message)));
    }

    private boolean isIgnoring(Player sender, Player target, String message) {
        Profile data = Lazarus.getInstance().getProfileManager().getUserdata(target);

        if(!data.getSettings().isMessages()) {
            sender.sendMessage(Lang.PREFIX + Lang.MESSAGE_MESSAGES_DISABLED.replace("<player>", target.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target))));
            return true;
        }

        if(data.isIgnoring(sender)) {
            sender.sendMessage(Lang.MESSAGE_SEND_FORMAT
                .replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target)))
                .replace("<player>", target.getName()) + message);

            return true;
        }

        if(data.getSettings().isSounds()) {
            target.playSound(target.getLocation(), Sound.NOTE_PIANO, 1.0f, 1.0f);
        }

        return false;
    }

    public boolean isSocialSpying(Player player) {
        return this.socialSpy.contains(player.getUniqueId());
    }

    public void toggleSocialSpy(Player player) {
        if(this.isSocialSpying(player)) {
            this.socialSpy.remove(player.getUniqueId());
            player.sendMessage(Lang.PREFIX + Lang.SOCIAL_SPY_DISABLED);
        } else {
            this.socialSpy.add(player.getUniqueId());
            player.sendMessage(Lang.PREFIX + Lang.SOCIAL_SPY_ENABLED);
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        this.replies.remove(event.getPlayer().getUniqueId());
        this.socialSpy.remove(event.getPlayer().getUniqueId());
    }
}
