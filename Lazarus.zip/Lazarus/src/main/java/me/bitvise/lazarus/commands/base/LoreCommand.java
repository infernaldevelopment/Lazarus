package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.utils.item.ItemUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import org.apache.commons.lang.StringUtils;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class LoreCommand extends BaseCommand {

    public LoreCommand() {
        super("lore", "lazarus.lore", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;
        ItemStack itemStack = player.getItemInHand();
        ItemMeta itemMeta = itemStack.getItemMeta();

        if (args.length < 1) {
            sender.sendMessage(Lang.PREFIX + Lang.LORE_COMMAND_USAGE);
            return;
        }

        if (itemStack == null) {
            sender.sendMessage(Lang.PREFIX + Lang.LORE_COMMAND_HOLD_ITEM);
            return;
        }

        String itemText = ChatColor.translateAlternateColorCodes('&', StringUtils.join(args, ' ', 0, args.length));
        List<String> itemLore = itemMeta.hasLore() ? itemMeta.getLore() : new ArrayList<String>(2);

        itemLore.add(itemText);
        itemMeta.setLore(itemLore);
        itemStack.setItemMeta(itemMeta);

        sender.sendMessage(Lang.PREFIX + Lang.LORE_COMMAND_ADDED.replace("<item>", ItemUtils.getItemName(itemStack)));
    }
}
