package me.bitvise.lazarus.handlers.portal;

import me.bitvise.lazarus.claim.ClaimManager;
import me.bitvise.lazarus.factions.Faction;
import me.bitvise.lazarus.factions.type.SpawnFaction;
import me.bitvise.lazarus.handlers.manager.Handler;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.World.Environment;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;

public class PortalHandler extends Handler implements Listener {

    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOWEST)
    public void onNetherPortal(PlayerPortalEvent event) {
        if(!Config.NETHER_PORTAL_TRANSLATION_ENABLED || event.getCause() != TeleportCause.NETHER_PORTAL) return;

        World fromWorld = event.getFrom().getWorld();

        if(fromWorld.getEnvironment() == Environment.NORMAL) {

            Location newTo = event.getFrom().clone();
            newTo.setWorld(event.getTo().getWorld());
            newTo.setX(newTo.getX() / Config.NETHER_PORTAL_TRANSLATION_VALUE);
            newTo.setZ(newTo.getZ() / Config.NETHER_PORTAL_TRANSLATION_VALUE);

            event.setTo(newTo);

        } else if(fromWorld.getEnvironment() == Environment.NETHER) {

            Location newTo = event.getFrom().clone();
            newTo.setWorld(event.getTo().getWorld());
            newTo.setX(newTo.getX() * Config.NETHER_PORTAL_TRANSLATION_VALUE);
            newTo.setZ(newTo.getZ() * Config.NETHER_PORTAL_TRANSLATION_VALUE);

            event.setTo(newTo);

        }
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onPlayerPortal(PlayerPortalEvent event) {
        World fromWorld = event.getFrom().getWorld();
        World toWorld = event.getTo().getWorld();

        if(fromWorld.getEnvironment() == Environment.NORMAL && event.getCause() == TeleportCause.END_PORTAL) {

            Location spawn = Config.WORLD_SPAWNS.get(Environment.THE_END);
            event.setTo(spawn == null ? toWorld.getSpawnLocation() : spawn);

        } else if(fromWorld.getEnvironment() == Environment.NETHER && event.getCause() == TeleportCause.NETHER_PORTAL) {

            Faction factionAt = ClaimManager.getInstance().getFactionAt(event.getFrom());
            if(!(factionAt instanceof SpawnFaction)) return;

            event.useTravelAgent(false);

            Location exit = Config.WORLD_EXITS.get(Environment.NETHER);
            event.setTo(exit == null ? toWorld.getSpawnLocation() : exit);

        } else if(fromWorld.getEnvironment() == Environment.THE_END && event.getCause() == TeleportCause.END_PORTAL) {

            Location exit = Config.WORLD_EXITS.get(Environment.THE_END);
            event.setTo(exit == null ? toWorld.getSpawnLocation() : exit);

        }
    }
}
