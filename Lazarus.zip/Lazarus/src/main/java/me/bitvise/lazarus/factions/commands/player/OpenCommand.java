package me.bitvise.lazarus.factions.commands.player;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.enums.Role;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.utils.Messages;

import me.bitvise.lazarus.utils.provider.Lang;
import org.apache.commons.lang.time.DurationFormatUtils;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class OpenCommand extends SubCommand {

    public OpenCommand() {
        super("open", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;
        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);

        if(faction == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
            return;
        }

        if(faction.getMember(player).getRole() != Role.LEADER) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_MUST_BE_LEADER);
            return;
        }

        long diff = faction.getOpenChangeCooldown() - System.currentTimeMillis();

        if(diff >= 0) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_OPEN_COOLDOWN
            .replace("<time>", DurationFormatUtils.formatDurationWords(diff, true, true)));
            return;
        }

        faction.setOpenStatus(!faction.isOpen());

        Messages.sendMessage(faction.isOpen() ? Lang.FACTIONS_OPEN_OPENED.replace("<name>",
        faction.getName()) : Lang.FACTIONS_OPEN_CLOSED.replace("<name>", faction.getName()));
    }
}
