package me.bitvise.lazarus.map.games.mountain.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.map.games.mountain.MountainData;
import me.bitvise.lazarus.commands.manager.SubCommand;

import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class MountainTeleportCommand extends SubCommand {

    MountainTeleportCommand() {
        super("teleport", Collections.singletonList("tp"), "lazarus.mountain.tp", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.MOUNTAIN_PREFIX + Lang.MOUNTAIN_TELEPORT_USAGE);
            return;
        }

        if(!this.checkNumber(sender, args[0])) return;

        MountainData mountain = Lazarus.getInstance().getMountainManager().getMountain(Integer.parseInt(args[0]));

        if(mountain == null) {
            sender.sendMessage(Lang.MOUNTAIN_PREFIX + Lang.MOUNTAIN_EXCEPTION_DOESNT_EXISTS.replace("<id>", args[0]));
            return;
        }

        Player player = (Player) sender;
        player.teleport(mountain.getCuboid().getCenter());
    }
}
