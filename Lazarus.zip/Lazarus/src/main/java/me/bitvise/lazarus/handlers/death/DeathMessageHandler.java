package me.bitvise.lazarus.handlers.death;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.nms.NmsUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.handlers.manager.Handler;
import me.bitvise.lazarus.profile.Profile;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemStack;

public class DeathMessageHandler extends Handler implements Listener {

    @EventHandler(priority = EventPriority.LOW)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();

        String deathMessage = this.getDeathMessage(player);
        event.setDeathMessage(deathMessage);

        Bukkit.getOnlinePlayers().forEach(online -> {
            if(player != online && player.getKiller() != online && !Lazarus.getInstance()
            .getProfileManager().getUserdata(online).getSettings().isDeathMessages()) return;

            online.sendMessage(deathMessage);
        });
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void cancelDeathMessage(PlayerDeathEvent event) {
        event.setDeathMessage(null);
    }

    private String getDeathMessage(Player player) {
        DamageCause cause = player.getLastDamageCause() == null
            ? DamageCause.CUSTOM
            : player.getLastDamageCause().getCause();

        String message = "";

        if(player.getLastDamageCause() instanceof EntityDamageByEntityEvent) {
            EntityDamageByEntityEvent damageEvent = (EntityDamageByEntityEvent) player.getLastDamageCause();

            switch(cause) {
                case ENTITY_ATTACK: {
                    message = this.getEntityAttackDeathMessage(player, damageEvent);
                    break;
                }
                case PROJECTILE: {
                    message = this.getProjectileDeathMessage(player, damageEvent);
                    break;
                }
                case ENTITY_EXPLOSION: {
                    message = this.getEntityExplosionDeathMessage(player, damageEvent);
                    break;
                }
                case FALLING_BLOCK: {
                    message = Lang.DEATHMESSAGE_REASON_FALLING_BLOCK.replace("<player>", this.getPlayerName(player));
                    break;
                }
                case LIGHTNING: {
                    message = Lang.DEATHMESSAGE_REASON_LIGHTNING.replace("<player>", this.getPlayerName(player));
                    break;
                }
                case FALL: {
                    message = Lang.DEATHMESSAGE_REASON_FALL.replace("<player>", this.getPlayerName(player));
                    break;
                }
            }
        } else {
            switch(cause) {
                case BLOCK_EXPLOSION: {
                    message = Lang.DEATHMESSAGE_REASON_BLOCK_EXPLOSION.replace("<player>", this.getPlayerName(player));
                    break;
                }
                case CONTACT: {
                    message = Lang.DEATHMESSAGE_REASON_CONTACT.replace("<player>", this.getPlayerName(player));
                    break;
                }
                case DROWNING: {
                    message = Lang.DEATHMESSAGE_REASON_DROWNING.replace("<player>", this.getPlayerName(player));
                    break;
                }
                case FIRE: {
                    message = Lang.DEATHMESSAGE_REASON_FIRE.replace("<player>", this.getPlayerName(player));
                    break;
                }
                case FIRE_TICK: {
                    message = Lang.DEATHMESSAGE_REASON_FIRE_TICK.replace("<player>", this.getPlayerName(player));
                    break;
                }
                case LAVA: {
                    message = Lang.DEATHMESSAGE_REASON_LAVA.replace("<player>", this.getPlayerName(player));
                    break;
                }
                case MAGIC: {
                    message = Lang.DEATHMESSAGE_REASON_MAGIC.replace("<player>", this.getPlayerName(player));
                    break;
                }
                case MELTING: {
                    message = Lang.DEATHMESSAGE_REASON_MELTING.replace("<player>", this.getPlayerName(player));
                    break;
                }
                case POISON: {
                    message = Lang.DEATHMESSAGE_REASON_POISON.replace("<player>", this.getPlayerName(player));
                    break;
                }
                case STARVATION: {
                    message = Lang.DEATHMESSAGE_REASON_STARVATION.replace("<player>", this.getPlayerName(player));
                    break;
                }
                case SUFFOCATION: {
                    message = Lang.DEATHMESSAGE_REASON_SUFFOCATION.replace("<player>", this.getPlayerName(player));
                    break;
                }
                case SUICIDE: {
                    message = Lang.DEATHMESSAGE_REASON_SUICIDE.replace("<player>", this.getPlayerName(player));
                    break;
                }
                case THORNS: {
                    message = Lang.DEATHMESSAGE_REASON_THORNS.replace("<player>", this.getPlayerName(player));
                    break;
                }
                case WITHER: {
                    message = Lang.DEATHMESSAGE_REASON_WITHER.replace("<player>", this.getPlayerName(player));
                    break;
                }
                case FALL: {
                    message = this.getFallDeathMessage(player);
                    break;
                }
                case VOID: {
                    message = this.getVoidDeathMessage(player);
                    break;
                }
                default: {
                    message = Lang.DEATHMESSAGE_REASON_CUSTOM.replace("<player>", this.getPlayerName(player));
                    break;
                }
            }
        }

        return message;
    }

    public String getPlayerName(OfflinePlayer player) {
        Profile data = Lazarus.getInstance().getProfileManager().getUserdata(player);

        return Lang.DEATHMESSAGE_PLAYER_NAME_FORMAT
            .replace("<player>", player.getName())
            .replace("<kills>", String.valueOf(data.getKills()));
    }

    public String getKillerName(Player killer) {
        Profile data = Lazarus.getInstance().getProfileManager().getUserdata(killer);

        return Lang.DEATHMESSAGE_KILLER_NAME_FORMAT
            .replace("<killer>", killer.getName())
            .replace("<kills>", data == null ? "?" : String.valueOf(data.getKills() + 1));
    }

    private String getEntityAttackDeathMessage(Player player, EntityDamageByEntityEvent damageEvent) {
        Entity damager = damageEvent.getDamager();

        if(damager instanceof Player) {
            Player playerDamager = (Player) damager;
            ItemStack handItem = playerDamager.getItemInHand();

            if(handItem != null && handItem.getType() != Material.AIR) {
                return Lang.DEATHMESSAGE_REASON_ENTITY_ATTACK_PLAYER_ITEM
                    .replace("<player>", this.getPlayerName(player))
                    .replace("<killer>", this.getKillerName(playerDamager))
                    .replace("<item>", NmsUtils.getInstance().getItemName(handItem));
            } else {
                return Lang.DEATHMESSAGE_REASON_ENTITY_ATTACK_PLAYER_NO_ITEM
                    .replace("<player>", this.getPlayerName(player))
                    .replace("<killer>", this.getKillerName(playerDamager));
            }
        } else {
            return Lang.DEATHMESSAGE_REASON_ENTITY_ATTACK_ENTITY
                .replace("<player>", this.getPlayerName(player))
                .replace("<entity>", StringUtils.getEntityName(damager.getType().name()));
        }
    }

    private String getProjectileDeathMessage(Player player, EntityDamageByEntityEvent damageEvent) {
        Projectile projectile = (Projectile) damageEvent.getDamager();

        if(projectile.getShooter() instanceof Player) {
            Player playerShooter = (Player) projectile.getShooter();
            ItemStack handItem = playerShooter.getItemInHand();

            if(handItem != null && handItem.getType() != Material.AIR) {
                return Lang.DEATHMESSAGE_REASON_PROJECTILE_PLAYER_ITEM
                    .replace("<player>", this.getPlayerName(player))
                    .replace("<killer>", this.getKillerName(playerShooter))
                    .replace("<item>", NmsUtils.getInstance().getItemName(handItem));
            } else {
                return Lang.DEATHMESSAGE_REASON_PROJECTILE_PLAYER_NO_ITEM
                    .replace("<player>", this.getPlayerName(player))
                    .replace("<killer>", this.getKillerName(playerShooter));
            }
        } else {
            Entity entityShooter = (Entity) projectile.getShooter();

            return Lang.DEATHMESSAGE_REASON_PROJECTILE_ENTITY
                .replace("<player>", this.getPlayerName(player))
                .replace("<entity>", StringUtils.getEntityName(entityShooter.getType().name()));
        }
    }

    private String getEntityExplosionDeathMessage(Player player, EntityDamageByEntityEvent damageEvent) {
        Entity damager = damageEvent.getDamager();

        if(damager instanceof TNTPrimed) {
            return Lang.DEATHMESSAGE_REASON_BLOCK_EXPLOSION
                .replace("<player>", this.getPlayerName(player));
        } else {
            return Lang.DEATHMESSAGE_REASON_ENTITY_EXPLOSION
                .replace("<player>", this.getPlayerName(player));
        }
    }

    private String getFallDeathMessage(Player player) {
        Player killer = player.getKiller();

        if(killer != null && player != killer) {
            return Lang.DEATHMESSAGE_REASON_FALL_KILLER
                .replace("<player>", this.getPlayerName(player))
                .replace("<killer>", this.getKillerName(killer));
        } else {
            return Lang.DEATHMESSAGE_REASON_FALL
            .replace("<player>", this.getPlayerName(player));
        }
    }

    private String getVoidDeathMessage(Player player) {
        Player killer = player.getKiller();

        if(killer != null && player != killer) {
            return Lang.DEATHMESSAGE_REASON_VOID_KILLER
                .replace("<player>", this.getPlayerName(player))
                .replace("<killer>", this.getKillerName(killer));
        } else {
            return Lang.DEATHMESSAGE_REASON_VOID
                .replace("<player>", this.getPlayerName(player));
        }
    }
}
