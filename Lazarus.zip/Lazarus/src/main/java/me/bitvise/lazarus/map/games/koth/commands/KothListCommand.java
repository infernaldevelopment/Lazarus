package me.bitvise.lazarus.map.games.koth.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.commands.manager.SubCommand;

import me.bitvise.lazarus.menu.type.KothsMenu;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class KothListCommand extends SubCommand {

    KothListCommand() {
        super("list");

        this.setExecuteAsync(true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        Lazarus.getInstance().getKothManager().listKoths(sender);
    }
}
