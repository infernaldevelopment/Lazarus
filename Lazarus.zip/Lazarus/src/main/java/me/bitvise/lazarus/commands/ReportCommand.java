package me.bitvise.lazarus.commands;

import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.timer.cooldown.CooldownTimer;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ReportCommand extends BaseCommand {

    public ReportCommand() {
        super("report", "lazarus.report", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length < 2) {
            sender.sendMessage(Lang.PREFIX + Lang.REPORT_USAGE);
            return;
        }

        Player player = (Player) sender;

        Player target = Bukkit.getPlayer(args[0]);
        if(!this.checkPlayer(sender, target, args[0])) return;

        CooldownTimer timer = TimerManager.getInstance().getCooldownTimer();

        if(timer.isActive(player, "REPORT")) {
            player.sendMessage(Lang.PREFIX + Lang.REPORT_COOLDOWN
            .replace("<seconds>", timer.getTimeLeft(player, "REPORT")));
            return;
        }

        String reason = StringUtils.joinArray(args, " ", 2);
        String reportedPrefix = Color.translate(ChatHandler.getInstance().getPrefix(player));
        String suspectPrefix = Color.translate(ChatHandler.getInstance().getPrefix(target));

        Lang.REPORT_FORMAT.forEach(line -> {

            line = line.replace("<reporter>", player.getName());
            line = line.replace("<reportedPrefix>", reportedPrefix);
            line = line.replace("<suspect>", target.getName());
            line = line.replace("<suspectPrefix>", suspectPrefix);
            line = line.replace("<reason>", reason);

            Messages.sendMessage(Color.translate(line), "lazarus.report.receive");
        });

        player.sendMessage(Lang.PREFIX + Lang.REPORT_REPORTED.replace("<player>", target.getName()));

        timer.activate(player, "REPORT", Config.REPORT_COOLDOWN,
        Lang.PREFIX + Lang.REPORT_COOLDOWN_EXPIRED);
    }
}
