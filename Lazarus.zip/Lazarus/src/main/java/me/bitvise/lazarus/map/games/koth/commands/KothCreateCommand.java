package me.bitvise.lazarus.map.games.koth.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.map.games.koth.KothData;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.claim.selection.Selection;
import me.bitvise.lazarus.claim.selection.SelectionType;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Config;

import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class KothCreateCommand extends SubCommand {

    KothCreateCommand() {
        super("create", Collections.singletonList("new"), "lazarus.koth.create", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.KOTH_CREATE_USAGE);
            return;
        }

        KothData koth = Lazarus.getInstance().getKothManager().getKoth(args[0]);

        if(koth != null) {
            sender.sendMessage(Lang.KOTH_CREATE_ALREADY_EXISTS.replace("<koth>", koth.getName()));
            return;
        }

        Player player = (Player) sender;
        Selection selection = Lazarus.getInstance().getSelectionManager().getSelection(player);

        if(selection == null || selection.getType() != SelectionType.EVENT_CLAIM) {
            Lazarus.getInstance().getSelectionManager().toggleSelectionProcess(player, SelectionType.EVENT_CLAIM, null);
            player.sendMessage(Lang.KOTH_CREATE_MAKE_A_SELECTION);
            return;
        }

        if(!selection.areBothPositionsSet()) {
            player.sendMessage(Lang.KOTH_CREATE_SET_BOTH_POSITIONS);
            return;
        }

        int captime = args.length == 1 ? Config.KOTH_DEFAULT_CAP_TIME : StringUtils.parseSeconds(args[1]);

        if(captime == -1) {
            sender.sendMessage(Lang.COMMANDS_INVALID_DURATION);
            return;
        }

        Lazarus.getInstance().getKothManager().createKoth(sender, args[0], captime, selection.toCuboid());
        Lazarus.getInstance().getSelectionManager().removeSelectionProcess(player);

        player.sendMessage(Lang.KOTH_CREATE_CREATED.replace("<koth>", args[0]));
    }
}
