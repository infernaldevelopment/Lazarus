package me.bitvise.lazarus.map.games.king.event;

public class KingStageEvent {
}
