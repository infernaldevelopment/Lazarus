package me.bitvise.lazarus.factions.commands.admin;

import me.bitvise.lazarus.claim.ClaimManager;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.Faction;
import me.bitvise.lazarus.factions.event.FactionClaimChangeEvent;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.factions.FactionsManager;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ClearClaimsCommand extends SubCommand {

    public ClearClaimsCommand() {
        super("clearclaims", "lazarus.factions.clearclaims");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player)sender;
        if(args.length == 0) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLEAR_CLAIMS_USAGE);
            return;
        }

        Faction faction = FactionsManager.getInstance().getAnyFaction(args[0]);

        if(faction == null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FACTION_DOESNT_EXIST.replace("<argument>", args[0]));
            return;
        }

        if(!ClaimManager.getInstance().removeAllClaims(faction, FactionClaimChangeEvent.ClaimChangeReason.UNCLAIM_ALL)) return;

        sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLEAR_CLAIMS_CLEARED_SENDER.replace("<faction>", faction.getDisplayName(sender)));

        if(!(faction instanceof PlayerFaction)) return;

        PlayerFaction playerFaction = (PlayerFaction) faction;
        playerFaction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLEAR_CLAIMS_CLEARED_FACTION.replace("<player>", player.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(player))));

        playerFaction.setHome(null);
        FactionsManager.getInstance().checkHomeTeleports(playerFaction, Lang.FACTIONS_CLEAR_CLAIMS_HOME_TELEPORT_CANCELLED);
    }
}
