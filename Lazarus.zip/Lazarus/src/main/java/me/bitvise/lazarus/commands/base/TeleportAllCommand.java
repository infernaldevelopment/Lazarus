package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class TeleportAllCommand extends BaseCommand {

    public TeleportAllCommand() {
        super("teleportall", Collections.singletonList("tpall"), "lazarus.teleportall", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        Bukkit.getOnlinePlayers().stream().filter(online -> online != player).forEach(online -> {
            if(!online.teleport(player)) return;
            online.sendMessage(Lang.PREFIX + Lang.TELEPORT_MESSAGE.replace("<player>", player.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(player))));
        });

        player.sendMessage(Lang.PREFIX + Lang.TELEPORT_ALL_MESSAGE);
    }
}
