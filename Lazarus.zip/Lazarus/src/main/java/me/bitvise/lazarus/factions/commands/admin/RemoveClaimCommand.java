package me.bitvise.lazarus.factions.commands.admin;

import me.bitvise.lazarus.claim.Claim;
import me.bitvise.lazarus.claim.ClaimManager;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.factions.FactionsManager;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class RemoveClaimCommand extends SubCommand {

    public RemoveClaimCommand() {
        super("removeclaim", "lazarus.factions.removeclaim", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        Claim claim = ClaimManager.getInstance().getClaimAt(player.getLocation());

        if(claim == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_REMOVE_CLAIM_NO_CLAIM);
            return;
        }

        if(!ClaimManager.getInstance().removeClaim(claim)) return;

        player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_REMOVE_CLAIM_REMOVED_SENDER
            .replace("<faction>", claim.getOwner().getDisplayName(sender))
            .replace("<location>", StringUtils.getLocationNameWithoutY(claim.getCenter())));

        if(!(claim.getOwner() instanceof PlayerFaction)) return;

        PlayerFaction faction = (PlayerFaction) claim.getOwner();

        faction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_REMOVE_CLAIM_REMOVED_FACTION.replace("<player>",
        player.getName()).replace("<location>", StringUtils.getLocationNameWithoutY(claim.getCenter())));

        if(faction.getHome() != null && claim.contains(faction.getHome())) {
            faction.setHome(null);
            FactionsManager.getInstance().checkHomeTeleports(faction, Lang.FACTIONS_UNCLAIM_HOME_TELEPORT_CANCELLED);
        }
    }
}
