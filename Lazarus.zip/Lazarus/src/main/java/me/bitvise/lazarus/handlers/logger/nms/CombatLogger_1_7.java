package me.bitvise.lazarus.handlers.logger.nms;

import lombok.Getter;
import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.handlers.logger.CombatLogger;
import me.bitvise.lazarus.map.games.conquest.ConquestManager;
import me.bitvise.lazarus.profile.Profile;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.utils.Tasks;

import me.bitvise.lazarus.utils.provider.Config;
import me.bitvise.lazarus.utils.provider.Lang;
import net.minecraft.server.v1_7_R4.*;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.*;
import org.bukkit.craftbukkit.v1_7_R4.CraftWorld;
import org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer;
import org.bukkit.craftbukkit.v1_7_R4.inventory.CraftItemStack;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.util.UUID;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class CombatLogger_1_7 extends EntitySkeleton implements CombatLogger {

    @Getter private Player player;
    private final int deathban;
    private final ItemStack[] contents;
    private final ItemStack[] armor;

    private final BukkitTask removeTask;

    public CombatLogger_1_7(World world, Player player) {
        super(((CraftWorld) world).getHandle());

        this.setHealth((float) player.getHealth());
        this.fireProof = true;
        this.persistent = true;

        this.player = player;
        this.deathban = Lazarus.getInstance().getDeathbanManager().getBanTime(player);
        this.contents = player.getInventory().getContents();
        this.armor = player.getInventory().getArmorContents();

        this.setEquipment(0, CraftItemStack.asNMSCopy(player.getItemInHand()));
        IntStream.rangeClosed(0, 3).forEach(i -> this.setEquipment(i + 1, CraftItemStack.asNMSCopy(this.armor[i])));

        EntityPlayer entityPlayer = ((CraftPlayer) player).getHandle();

        player.getActivePotionEffects().forEach(effect -> {
            if(effect.getDuration() > 12000) return;
            this.addEffect(entityPlayer.getEffect(MobEffectList.byId[effect.getType().getId()]));
        });

        this.setCustomName(Config.COMBAT_LOGGER_NAME_FORMAT.replace("<player>", player.getName()));
        this.setCustomNameVisible(true);

        Location loc = player.getLocation();
        double locY = loc.getBlock().getType() == Material.AIR ? loc.getY() : Math.floor(loc.getY()) + 1;

        this.setPositionRotation(loc.getX(), locY, loc.getZ(), loc.getYaw(), loc.getPitch());

        ((CraftWorld) world).getHandle().addEntity(this, SpawnReason.CUSTOM);

        this.removeTask = Tasks.syncLater(() -> {
            Lazarus.getInstance().getCombatLoggerHandler().removeCombatLogger(this.player.getUniqueId());
            this.bukkitEntity.remove();
            this.player = null;
        }, Config.COMBAT_LOGGER_TIME * 20L);
    }

    @Override
    public void removeCombatLogger() {
        this.removeTask.cancel();
        this.bukkitEntity.remove();
        this.player = null;
    }

    @Override
    public float getCombatLoggerHealth() {
        return this.getHealth();
    }

    @Override
    public Location getCombatLoggerLocation() {
        return this.getBukkitEntity().getLocation();
    }

    @Override
    public void move(double d0, double d1, double d2) {
        super.move(0, d1, 0);
    }

    @Override
    protected Entity findTarget() {
        return null;
    }

    @Override
    public void b(int i) {

    }

    @Override
    public boolean n(Entity entity) {
        return true;
    }

    @Override
    public void a(EntityLiving entityliving, float f) {

    }

    @Override
    public void collide(Entity entity) {

    }

    @Override
    protected void dropDeathLoot(boolean flag, int i) {

    }

    @Override
    protected void dropEquipment(boolean flag, int i) {

    }

    @Override
    public void handleEffectChanges(Player player) {
        player.getActivePotionEffects().forEach(effect -> {
            MobEffect nmsEffect = this.getEffect(MobEffectList.byId[effect.getType().getId()]);

            if(nmsEffect == null) {
                player.removePotionEffect(effect.getType());
                return;
            }

            player.addPotionEffect(new PotionEffect(PotionEffectType.getById(nmsEffect.getEffectId()),
            nmsEffect.getDuration(), nmsEffect.getAmplifier(), nmsEffect.isAmbient()), true);
        });
    }

    @Override
    public boolean damageEntity(DamageSource damageSource, float amount) {
        if(!this.isAlive()) return false;

        if(damageSource instanceof EntityDamageSourceIndirect && damageSource.isMagic()) {
            return false;
        }

        Entity damageSourceEntity = damageSource.getEntity();
        if(damageSourceEntity != null && this.player == damageSourceEntity.getBukkitEntity()) return false;

        if(damageSourceEntity instanceof EntityPlayer) {
            Player damager = (Player) damageSourceEntity.getBukkitEntity();

            if(Lazarus.getInstance().getSotwHandler().isUnderSotwProtection(damager)) {
                return false;
            }

            if(TimerManager.getInstance().getPvpProtTimer().isActive(damager)) {
                damager.sendMessage(Lang.PREFIX + Lang.PVP_PROT_PVP_DENY_VICTIM);
                return false;
            }

            if(Lazarus.getInstance().getStaffModeManager().isInStaffMode(damager)) {
                damager.sendMessage(Lang.PREFIX + Lang.STAFF_MODE_DAMAGE_DENY);
                return false;
            }

            if(Lazarus.getInstance().getVanishManager().isVanished(damager)) {
                damager.sendMessage(Lang.PREFIX + Lang.VANISH_DAMAGE_DENY);
                return false;
            }

            PlayerFaction playerFaction = FactionsManager.getInstance().getPlayerFaction(this.player);

            if(playerFaction != null) {
                PlayerFaction damagerFaction = FactionsManager.getInstance().getPlayerFaction(damager);

                if(playerFaction == damagerFaction) {
                    return false;
                }

                if(!Config.FACTION_ALLY_FRIENDLY_FIRE && playerFaction.isAlly(damagerFaction)) {
                    damager.sendMessage(Lang.FACTIONS_DENY_DAMAGE_ALLIES
                    .replace("<player>", Config.ALLY_COLOR + this.player.getName()));
                    return false;
                }
            }

            TimerManager.getInstance().getCombatTagTimer().activate(damager.getUniqueId());
        }

        return super.damageEntity(damageSource, amount);
    }

    @Override
    public void die(DamageSource damageSource) {
        Stream.of(this.contents).filter(item -> item != null && item.getType() != Material.AIR)
        .forEach(item -> world.getWorld().dropItemNaturally(this.bukkitEntity.getLocation(), item));

        Stream.of(this.armor).filter(item -> item != null && item.getType() != Material.AIR)
        .forEach(item -> world.getWorld().dropItemNaturally(this.bukkitEntity.getLocation(), item));

        String reason;
        Entity damager = damageSource.getEntity();

        if(damager instanceof EntityPlayer) {
            Player killer = ((EntityPlayer) damager).getBukkitEntity();

            Lazarus.getInstance().getProfileManager().getUserdata(killer).addKill();
            Lazarus.getInstance().getKillstreakHandler().checkKillerKillstreak(killer);

            PlayerFaction killerFaction = FactionsManager.getInstance().getPlayerFaction(killer);

            if(killerFaction != null) {
                killerFaction.setPoints(killerFaction.getPoints() + Config.FACTION_TOP_KILL);
            }

            reason = Lang.DEATHMESSAGE_REASON_COMBATLOGGER_KILLER
                .replace("<player>", Lazarus.getInstance().getDeathMessageHandler().getPlayerName(this.player))
                .replace("<killer>", Lazarus.getInstance().getDeathMessageHandler().getKillerName(killer));
        } else {
            reason = Lang.DEATHMESSAGE_REASON_COMBATLOGGER.replace("<player>",
                Lazarus.getInstance().getDeathMessageHandler().getPlayerName(this.player));
        }

        Bukkit.getOnlinePlayers().forEach(online -> {
            if((damager != null && damager.getBukkitEntity() != online) && !Lazarus.getInstance()
                .getProfileManager().getUserdata(online).getSettings().isDeathMessages()) return;

            online.sendMessage(reason);
        });

        UUID playerUUID = this.player.getUniqueId();

        Tasks.async(() -> {
            OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(playerUUID);
            Profile profile = Lazarus.getInstance().getProfileManager().getUserdata(offlinePlayer);

            profile.addDeath();
            profile.setKillstreak(0);
            profile.addLastDeath(reason);
        });

        Lazarus.getInstance().getDeathbanManager().deathbanPlayer(this.player,
            this.bukkitEntity.getLocation(), this.deathban, reason);

        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(this.player);

        if(faction != null) {
            faction.onDeath(this.player);

            ConquestManager conquestManager = Lazarus.getInstance().getConquestManager();

            if(conquestManager.isActive()) {
                conquestManager.onDeath(this.player, faction);
            }
        }

        super.die(damageSource);

        EntityPlayer entityPlayer = ((CraftPlayer) this.player).getHandle();

        entityPlayer.getBukkitEntity().getInventory().clear();
        entityPlayer.getBukkitEntity().getInventory().setArmorContents(null);
        entityPlayer.setPosition(this.locX, this.locY, this.locZ);
        entityPlayer.setHealth(0);
        entityPlayer.getBukkitEntity().saveData();

        Lazarus.getInstance().getCombatLoggerHandler().removeCombatLogger(this.player.getUniqueId());

        this.removeTask.cancel();
        this.player = null;
    }
}
