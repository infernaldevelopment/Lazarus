package me.bitvise.lazarus.factions.type;

import me.bitvise.lazarus.factions.Faction;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.entity.Player;

public class WarzoneFaction extends Faction {

    public WarzoneFaction() {
        super(Config.WARZONE_NAME);
    }

    @Override
    public boolean shouldCancelPvpTimerEntrance(Player player) {
        return false;
    }
}
