package me.bitvise.lazarus.factions.commands.player;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.enums.Role;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class FriendlyFireCommand extends SubCommand {

    public FriendlyFireCommand() {
        super("friendlyfire", Collections.singletonList("ff"), true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;
        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);

        if(faction == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
            return;
        }

        if(faction.getMember(player).getRole() != Role.LEADER) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_MUST_BE_LEADER);
            return;
        }

        faction.setFriendlyFire(!faction.isFriendlyFire());

        faction.sendMessage(Lang.FACTION_PREFIX + (faction.isFriendlyFire()
            ? Lang.FACTIONS_FRIENDLY_FIRE_TOGGLED_ON
            : Lang.FACTIONS_FRIENDLY_FIRE_TOGGLED_OFF));
    }
}
