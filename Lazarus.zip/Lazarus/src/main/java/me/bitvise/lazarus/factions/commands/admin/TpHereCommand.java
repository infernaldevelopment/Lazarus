package me.bitvise.lazarus.factions.commands.admin;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.utils.provider.Lang;

import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class TpHereCommand extends SubCommand {

    public TpHereCommand() {
        super("tphere", Collections.singletonList("teleporthere"), "lazarus.factions.tphere", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length < 1) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_TP_HERE_USAGE);
            return;
        }

        PlayerFaction faction = FactionsManager.getInstance().searchForFaction(args[0]);

        if(faction == null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FACTION_DOESNT_EXIST.replace("<argument>", args[0]));
            return;
        }

        Player player = (Player) sender;

        faction.getOnlinePlayers().forEach(online -> {
            if(!online.teleport(player)) return;

            online.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_TP_HERE_TELEPORTED_FACTION
                .replace("<player>", player.getName()));
        });

        player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_TP_HERE_TELEPORTED_SENDER
            .replace("<faction>", faction.getName()));
    }
}
