package me.bitvise.lazarus.map.games.mountain.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.map.games.mountain.MountainData;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.SubCommand;
import org.bukkit.command.CommandSender;

public class MountainUpdateCommand extends SubCommand {

    MountainUpdateCommand() {
        super("update", "lazarus.mountain.update");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.MOUNTAIN_PREFIX + Lang.MOUNTAIN_UPDATE_USAGE);
            return;
        }

        if(!this.checkNumber(sender, args[0])) return;

        MountainData mountain = Lazarus.getInstance().getMountainManager().getMountain(Integer.parseInt(args[0]));

        if(mountain == null) {
            sender.sendMessage(Lang.MOUNTAIN_PREFIX + Lang.MOUNTAIN_EXCEPTION_DOESNT_EXISTS.replace("<id>", args[0]));
            return;
        }

        mountain.cacheMaterials();

        sender.sendMessage(Lang.MOUNTAIN_PREFIX + Lang.MOUNTAIN_UPDATE_UPDATED
        .replace("<id>", String.valueOf(mountain.getId())));
    }
}
