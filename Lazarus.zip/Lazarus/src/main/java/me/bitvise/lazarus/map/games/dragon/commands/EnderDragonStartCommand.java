package me.bitvise.lazarus.map.games.dragon.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.SubCommand;

import org.bukkit.command.CommandSender;

public class EnderDragonStartCommand extends SubCommand {

    public EnderDragonStartCommand() {
        super("start", "lazarus.enderdragon.start");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(Lazarus.getInstance().getEnderDragonManager().isActive()) {
            sender.sendMessage(Lang.ENDER_DRAGON_PREFIX + Lang.ENDER_DRAGON_START_ALREADY_RUNNING);
            return;
        }

        if(Lazarus.getInstance().getEnderDragonManager() == null) {

            return;
        }

        Lazarus.getInstance().getEnderDragonManager().startEnderDragon(sender);
    }
}
