package me.bitvise.lazarus.handlers.timer;

import com.lunarclient.bukkitapi.LunarClientAPI;
import com.lunarclient.bukkitapi.nethandler.client.LCPacketTitle;
import lombok.Getter;
import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.claim.ClaimManager;
import me.bitvise.lazarus.factions.Faction;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.utils.*;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.item.ItemUtils;
import me.bitvise.lazarus.utils.nms.NmsUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.handlers.manager.Handler;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.*;
import org.bukkit.World.Environment;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;
import java.util.concurrent.TimeUnit;

public class SotwHandler extends Handler implements Listener {

    private boolean hidePlayers;

    private final Set<UUID> sotwEnabledPlayers;
    private final Set<Material> autoInventoryMaterial;

    public SotwHandler() {
        this.hidePlayers = Config.SOTW_HIDE_PLAYERS;
        this.sotwEnabledPlayers = new HashSet<>();

        this.autoInventoryMaterial = EnumSet.of(Material.STONE, Material.COBBLESTONE, Material.DIRT,
            Material.GRASS, Material.SAND, Material.SOUL_SAND, Material.COAL_ORE, Material.DIAMOND_ORE,
            Material.EMERALD_ORE, Material.GLOWING_REDSTONE_ORE, Material.GOLD_ORE, Material.IRON_ORE,
            Material.LAPIS_ORE, Material.QUARTZ_ORE, Material.REDSTONE_ORE, Material.NETHERRACK);
    }

    @Override
    public void disable() {
        this.sotwEnabledPlayers.clear();
    }

    public void startSotwTimer(CommandSender sender, int time) {
        if(this.isActive()) {
            sender.sendMessage(Lang.PREFIX + Lang.SOTW_ALREADY_RUNNING);
            return;
        }

        if(this.hidePlayers) {
            Tasks.async(() -> this.toggleSotwInvisibility(null, true));
        }

        if (Config.LUNAR_CLIENT_API_ENABLED && Bukkit.getPluginManager().isPluginEnabled("LunarClient-API")) {
            Bukkit.getOnlinePlayers().forEach(online -> {

                LunarClientAPI.getInstance().sendPacket(online, new LCPacketTitle("TITLE", Lang.SOTW_STARTED_TITLE, TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5)));
                LunarClientAPI.getInstance().sendPacket(online, new LCPacketTitle("SUBTITLE", Lang.SOTW_STARTED_SUBTITLE.replace("<time>", StringUtils.formatTime(time, StringUtils.FormatType.SECONDS_TO_HOURS)), TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5)));
            });
        }

        TimerManager.getInstance().getSotwTimer().activate(time);
        Lazarus.getInstance().getScoreboardManager().updateAllTabRelations();

        Messages.sendMessage(Lang.SOTW_STARTED.replace("<time>", StringUtils.formatTime(time, StringUtils.FormatType.SECONDS_TO_HOURS)));
    }

    public void stopSotwTimer(CommandSender sender) {
        if(!this.isActive()) {
            sender.sendMessage(Lang.PREFIX + Lang.SOTW_NOT_RUNNING);
            return;
        }

        this.sotwEnabledPlayers.clear();

        Tasks.async(() -> this.showSotwInvisiblePlayers());
        Lazarus.getInstance().getScoreboardManager().updateAllTabRelations();

        if (Config.LUNAR_CLIENT_API_ENABLED && Bukkit.getPluginManager().isPluginEnabled("LunarClient-API")) {
            Bukkit.getOnlinePlayers().forEach(online -> {

                LunarClientAPI.getInstance().sendPacket(online, new LCPacketTitle("TITLE", Lang.SOTW_ENDED_TITLE, TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5)));
                LunarClientAPI.getInstance().sendPacket(online, new LCPacketTitle("SUBTITLE", Lang.SOTW_ENDED_SUBTITLE, TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5)));
            });
        }

        TimerManager.getInstance().getSotwTimer().cancel();
        Messages.sendMessage(Lang.SOTW_ENDED);
    }

    public boolean isActive() {
        return TimerManager.getInstance().getSotwTimer().isActive();
    }

    public boolean isPlayerSotwEnabled(Player player) {
        return this.sotwEnabledPlayers.contains(player.getUniqueId());
    }

    public boolean isUnderSotwProtection(Player player) {
        return this.isActive() && !this.isPlayerSotwEnabled(player);
    }

    public void enableSotwForPlayer(Player player) {
        if(!this.isActive()) {
            player.sendMessage(Lang.PREFIX + Lang.SOTW_NOT_RUNNING);
            return;
        }

        if(this.sotwEnabledPlayers.contains(player.getUniqueId())) {
            player.sendMessage(Lang.PREFIX + Lang.SOTW_ALREADY_ENABLED);
            return;
        }

        Lazarus.getInstance().getScoreboardManager().getScoreboards()
            .values().forEach(sb -> sb.updateRelation(player));

        this.sotwEnabledPlayers.add(player.getUniqueId());

        if (Config.LUNAR_CLIENT_API_ENABLED && Bukkit.getPluginManager().isPluginEnabled("LunarClient-API")) {
            Bukkit.getOnlinePlayers().forEach(online -> {

                LunarClientAPI.getInstance().sendPacket(player, new LCPacketTitle("TITLE", Lang.SOTW_ENABLED_TITLE, TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5)));
                LunarClientAPI.getInstance().sendPacket(player, new LCPacketTitle("SUBTITLE", Lang.SOTW_ENABLED_SUBTITLE, TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5)));
            });
        }

        player.sendMessage(Lang.PREFIX + Lang.SOTW_ENABLED);
    }

    public void showSotwInvisiblePlayers() {
        Bukkit.getOnlinePlayers().forEach(player -> Bukkit.getOnlinePlayers().forEach(online -> {
            if(Lazarus.getInstance().getVanishManager().isVanished(online)) return;

            player.showPlayer(online);
        }));
    }

    public void toggleSotwInvisibility(CommandSender sender, Boolean hide) {
        this.hidePlayers = hide != null ? hide : !this.hidePlayers;

        if(this.hidePlayers) {
            Bukkit.getOnlinePlayers().forEach(player -> Bukkit.getOnlinePlayers().forEach(online -> {
                if(Lazarus.getInstance().getVanishManager().isVanished(online)) return;
                if(!ClaimManager.getInstance().getFactionAt(online.getLocation()).isSafezone()) return;

                player.hidePlayer(online);
            }));
        } else {
            Bukkit.getOnlinePlayers().forEach(player -> Bukkit.getOnlinePlayers().forEach(online -> {
                if(Lazarus.getInstance().getVanishManager().isVanished(online)) return;

                player.showPlayer(online);
            }));
        }

        String prefix;
        if (sender instanceof Player) {
            Player p = (Player) sender;
            prefix = Color.translate(ChatHandler.getInstance().getPrefix(p));
        } else {
            prefix = Color.translate("&4");
        }

        if (sender != null) {
            Messages.sendMessage(Lang.PREFIX + (this.hidePlayers ? Lang.HIDEPLAYERS_ENABLED_COMMAND.replace("<prefix>", prefix).replace("<player>", sender.getName()) : Lang.HIDEPLAYERS_DISABLED_COMMAND.replace("<prefix>", prefix).replace("<player>", sender.getName())), "lazarus.staff");
        }
    }

    private void toggleSotwInvisibility(Player player, Faction toFaction) {
        if(Lazarus.getInstance().getVanishManager().isVanished(player)) return;

        if(toFaction.isSafezone()) {
            Bukkit.getOnlinePlayers().forEach(online -> online.hidePlayer(player));
        } else {
            Bukkit.getOnlinePlayers().forEach(online -> online.showPlayer(player));
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlayerMove(PlayerMoveEvent event) {
        if(!this.isActive()) return;

        if(event.getFrom().getBlockX() == event.getTo().getBlockX()
            && event.getFrom().getBlockY() == event.getTo().getBlockY()
            && event.getFrom().getBlockZ() == event.getTo().getBlockZ()) return;

        Faction toFaction = ClaimManager.getInstance().getFactionAt(event.getTo());

        if(ClaimManager.getInstance().getFactionAt(event.getFrom()) != toFaction && this.hidePlayers) {
            this.toggleSotwInvisibility(event.getPlayer(), toFaction);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlayerTeleport(PlayerTeleportEvent event) {
        if(!this.isActive()) return;

        Faction toFaction = ClaimManager.getInstance().getFactionAt(event.getTo());

        if(ClaimManager.getInstance().getFactionAt(event.getFrom()) != toFaction && this.hidePlayers) {
            this.toggleSotwInvisibility(event.getPlayer(), toFaction);
        }
    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {
        if(!this.isActive()) return;

        Player killer = event.getEntity().getKiller();
        if(killer == null) return;

        Location location = event.getEntity().getLocation();

        if(killer.getInventory().firstEmpty() == -1) {
            event.getDrops().forEach(drop -> location.getWorld().dropItemNaturally(location, drop));
        } else {
            event.getDrops().forEach(drop -> killer.getInventory().addItem(drop));
        }

        event.getDrops().clear();
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        if(!this.isActive() || event.getPlayer().getGameMode() == GameMode.CREATIVE) return;

        Block block = event.getBlock();
        if(!this.autoInventoryMaterial.contains(block.getType())) return;

        Player player = event.getPlayer();

        ItemStack item = player.getItemInHand();
        NmsUtils.getInstance().damageItemInHand(player);

        List<ItemStack> drops = NmsUtils.getInstance().getBlockDrops(item, block);

        if(player.getInventory().firstEmpty() == -1) {
            drops.forEach(drop -> block.getWorld().dropItemNaturally(block.getLocation(), drop));
        } else {
            drops.forEach(drop -> player.getInventory().addItem(drop));
        }

        if(!ItemUtils.hasEnchantment(item, Enchantment.SILK_TOUCH)) {
            player.giveExp(event.getExpToDrop());
        }

        if(!ItemUtils.isOre(block.getType()) || !ItemUtils.hasEnchantment(item, Enchantment.SILK_TOUCH)) {
            NmsUtils.getInstance().increaseStatistic(player, Statistic.MINE_BLOCK, block.getType());
        }

        block.setType(Material.AIR);
        event.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOW)
    public void onPlayerDamage(EntityDamageEvent event) {
        if(!this.isActive()) return;
        if(!(event.getEntity() instanceof Player)) return;

        Player player = (Player) event.getEntity();
        if(this.sotwEnabledPlayers.contains(player.getUniqueId())) return;

        if(event.getCause() == DamageCause.VOID) {
            Location endSpawn = Config.WORLD_SPAWNS.get(Environment.THE_END);

            player.teleport(endSpawn == null ? player.getWorld().getSpawnLocation() : endSpawn);
            player.sendMessage(Lang.PREFIX + Lang.SOTW_VOID_FIX);
        }

        event.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOW)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if(!this.isActive() || !(event.getEntity() instanceof Player)) return;

        Player damager = PlayerUtils.getAttacker(event);
        if(damager == null) return;

        Player victim = (Player) event.getEntity();
        if(this.isPlayerSotwEnabled(victim) && this.isPlayerSotwEnabled(damager)) return;

        event.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onCreatureSpawn(CreatureSpawnEvent event) {
        if(!this.isActive() || !Config.SOTW_SPAWN_MOBS_FROM_SPAWNERS_ONLY) return;

        SpawnReason reason = event.getSpawnReason();
        if(ServerUtils.ALLOWED_SPAWN_REASONS.contains(reason)) return;

        event.setCancelled(true);
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        if(!this.isActive() || !this.hidePlayers) return;

        Bukkit.getOnlinePlayers().forEach(online -> {
            if(!ClaimManager.getInstance().getFactionAt(online.getLocation()).isSafezone()) return;
            event.getPlayer().hidePlayer(online);
        });

        this.toggleSotwInvisibility(event.getPlayer(), ClaimManager.getInstance().getFactionAt(event.getPlayer()));
    }
}
