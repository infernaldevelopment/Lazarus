package me.bitvise.lazarus.commands.staff;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.command.CommandSender;

public class ChatControlCommand extends BaseCommand {

    public ChatControlCommand() {
        super("chat", "lazarus.chatcontrol");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            Lang.CHAT_USAGE.forEach(sender::sendMessage);
            return;
        }

        if(args.length == 1) {
            switch(args[0].toLowerCase()) {
                case "mute": {
                    Lazarus.getInstance().getChatControlHandler().toggleChat(sender);
                    return;
                }
                case "clear": {
                    Lazarus.getInstance().getChatControlHandler().clearChat(sender);
                    return;
                }
                default: {
                    Lang.CHAT_USAGE.forEach(sender::sendMessage);
                    return;
                }
            }
        }

        switch(args[0].toLowerCase()) {
            case "delay": {
                Lazarus.getInstance().getChatControlHandler().setDelay(sender, args[1]);
                return;
            }
            case "toggle": {
                if(args[1].equalsIgnoreCase("foundore")) {
                    Lazarus.getInstance().getChatControlHandler().toggleFoundOreMessages(sender);
                    return;
                }

                Lang.CHAT_USAGE.forEach(sender::sendMessage);
                return;
            }
            default: Lang.CHAT_USAGE.forEach(sender::sendMessage);
        }
    }
}
