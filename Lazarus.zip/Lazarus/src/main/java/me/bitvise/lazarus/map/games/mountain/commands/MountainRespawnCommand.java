package me.bitvise.lazarus.map.games.mountain.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.map.games.Placeholder;
import me.bitvise.lazarus.utils.provider.Lang;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.map.games.mountain.MountainData;
import me.bitvise.lazarus.utils.Messages;
import org.bukkit.command.CommandSender;

public class MountainRespawnCommand extends SubCommand {

    public MountainRespawnCommand() {
        super("respawn", "lazarus.mountain.respawn");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.MOUNTAIN_PREFIX + Lang.MOUNTAIN_RESPAWN_USAGE);
            return;
        }

        if(!this.checkNumber(sender, args[0])) return;

        MountainData mountain = Lazarus.getInstance().getMountainManager().getMountain(Integer.parseInt(args[0]));

        if(mountain == null) {
            sender.sendMessage(Lang.MOUNTAIN_PREFIX + Lang.MOUNTAIN_EXCEPTION_DOESNT_EXISTS.replace("<id>", args[0]));
            return;
        }

        mountain.respawn();
        Messages.sendMessage(Placeholder.MountainReplacer.parse(mountain, Lang.MOUNTAIN_RESPAWN_RESPAWNED));
    }
}
