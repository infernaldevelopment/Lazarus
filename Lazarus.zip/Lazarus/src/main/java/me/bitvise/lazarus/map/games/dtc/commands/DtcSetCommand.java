package me.bitvise.lazarus.map.games.dtc.commands;

import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.map.games.dtc.DtcManager;
import me.bitvise.lazarus.utils.StringUtils;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.HashSet;

public class DtcSetCommand extends SubCommand {

    public DtcSetCommand() {
        super("set", "lazarus.dtc.set", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;
        Block targetBlock = player.getTargetBlock((HashSet<Byte>) null, 5);

        if(targetBlock == null || targetBlock.getType() != Material.OBSIDIAN) {
            player.sendMessage(Lang.DTC_PREFIX + Lang.DTC_SET_MUST_BE_OBSIDIAN);
            return;
        }

        DtcManager dtcManager = Lazarus.getInstance().getDtcManager();

        dtcManager.getDtcData().setLocation(targetBlock.getLocation());
        if(!dtcManager.isActive()) targetBlock.setType(Material.AIR);

        player.sendMessage(Lang.DTC_PREFIX + Lang.DTC_SET_CORE_SET.replace("<location>",
        StringUtils.getLocationNameWithWorld(targetBlock.getLocation())));
    }
}
