package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.profile.Profile;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class IgnoreCommand extends BaseCommand {

    public IgnoreCommand() {
        super("ignore", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.PREFIX + Lang.IGNORE_USAGE);
            return;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if(!this.checkPlayer(sender, target, args[0])) return;

        Player player = (Player) sender;

        if(player == target) {
            player.sendMessage(Lang.PREFIX + Lang.IGNORE_CANNOT_IGNORE_SELF);
            return;
        }

        Profile data = Lazarus.getInstance().getProfileManager().getUserdata(player);

        if(data.isIgnoring(target)) {
            data.removeIgnoring(target);
            player.sendMessage(Lang.PREFIX + Lang.IGNORE_DISABLED.replace("<player>", target.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target))));
        } else {
            data.addIgnoring(target);
            player.sendMessage(Lang.PREFIX + Lang.IGNORE_ENABLED.replace("<player>", target.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target))));
        }
    }
}
