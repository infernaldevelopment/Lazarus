package me.bitvise.lazarus.commands.staff;

import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.command.CommandSender;

public class CustomTimerCommand extends BaseCommand {

    public CustomTimerCommand() {
        super("customtimer", "lazarus.customtimer");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            Lang.CUSTOM_TIMER_USAGE.forEach(sender::sendMessage);
            return;
        }

        if(args.length < 4) {

            if(args[0].equalsIgnoreCase("list")) {
                TimerManager.getInstance().getCustomTimer().listActiveTimers(sender);
                return;
            }

            if(args.length >= 2 && (args[0].equalsIgnoreCase("cancel") || args[0].equalsIgnoreCase("stop"))) {
                if(TimerManager.getInstance().getCustomTimer().cancel(sender, args[1])) return;

                sender.sendMessage(Lang.PREFIX + Lang.CUSTOM_TIMER_NOT_RUNNING.replace("<name>", args[1]));
                return;
            }

            Lang.CUSTOM_TIMER_USAGE.forEach(sender::sendMessage);
            return;
        }

        if(args[0].equalsIgnoreCase("start")) {
            int duration = StringUtils.parseSeconds(args[args.length-1]);

            if(duration == -1) {
                sender.sendMessage(Lang.PREFIX + Lang.COMMANDS_INVALID_DURATION);
                return;
            }

            TimerManager.getInstance().getCustomTimer().activate(sender, args, duration);
            return;
        }

        Lang.CUSTOM_TIMER_USAGE.forEach(sender::sendMessage);
    }
}
