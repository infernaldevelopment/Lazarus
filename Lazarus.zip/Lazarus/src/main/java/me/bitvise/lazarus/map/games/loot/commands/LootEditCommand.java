package me.bitvise.lazarus.map.games.loot.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.provider.Lang;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.map.games.loot.LootData;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class LootEditCommand extends SubCommand {

    public LootEditCommand() {
        super("edit", "lazarus.loot.edit", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.LOOT_PREFIX + Lang.LOOT_EDIT_USAGE);
            return;
        }

        LootData loot = Lazarus.getInstance().getLootManager().getLootByName(args[0]);

        if(loot == null) {
            sender.sendMessage(Lang.LOOT_PREFIX + Lang.LOOT_EXCEPTION_DOESNT_EXIST.replace("<loot>", args[0]));
            return;
        }

        Lazarus.getInstance().getLootManager().editLoot((Player) sender, loot);
    }
}
