package me.bitvise.lazarus.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.item.ItemUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SalvageCommand extends BaseCommand {

    public SalvageCommand() {
        super("salvage", "lazarus.salvage", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        if(!ItemUtils.isSalvageable(player.getItemInHand().getType())) {
            player.sendMessage(Lang.PREFIX + Lang.SALVAGE_NOT_SALVAGEABLE);
            return;
        }

        Lazarus.getInstance().getSalvageHandler().handleSalvage(player);
    }
}
