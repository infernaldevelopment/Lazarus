package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class EnderchestCommand extends BaseCommand {

    public EnderchestCommand() {
        super("enderchest", Collections.singletonList("ec"), "lazarus.enderchest", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        if(Config.COMBAT_TAG_DISABLE_ENDERCHESTS && TimerManager.getInstance().getCombatTagTimer().isActive(player)) {
            player.sendMessage(Lang.PREFIX + Lang.COMBAT_TAG_ENDERCHEST_DENY);
            return;
        }

        if(args.length == 0) {
            player.sendMessage(Lang.PREFIX + Lang.ENDERCHEST_COMMAND_OPENED);
            player.openInventory(player.getEnderChest());
            return;
        }

        if(!this.checkPermission(sender, "lazarus.enderchest.others")) return;

        Player target = Bukkit.getPlayer(args[0]);
        if(!this.checkPlayer(sender, target, args[0])) return;

        player.sendMessage(Lang.PREFIX + Lang.ENDERCHEST_COMMAND_OPENED_OTHERS.replace("<player>", target.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target))));
        player.openInventory(target.getEnderChest());
    }
}
