package me.bitvise.lazarus.commands;

import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.command.CommandSender;

import java.util.Collections;

public class HelpCommand extends BaseCommand {

    public HelpCommand() {
        super("help", Collections.singletonList("?"), "lazarus.help");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Lang.HELP_MESSAGE.forEach(line -> {

            line = line.replace("<placeholder:square>", StringUtils.SQUARE);

            sender.sendMessage(Color.translate(line));
        });
    }
}
