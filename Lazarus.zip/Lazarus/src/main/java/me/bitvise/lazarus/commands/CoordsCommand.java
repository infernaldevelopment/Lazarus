package me.bitvise.lazarus.commands;

import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.command.CommandSender;

public class CoordsCommand extends BaseCommand {

    public CoordsCommand() {
        super("coords", "lazarus.coords");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Lang.COORDS_MESSAGE.forEach(sender::sendMessage);
    }
}
