package me.bitvise.lazarus.factions.commands.player;

import com.lunarclient.bukkitapi.LunarClientAPI;
import com.lunarclient.bukkitapi.nethandler.client.LCPacketTitle;
import me.bitvise.lazarus.claim.ClaimManager;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.Faction;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.factions.type.WarzoneFaction;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.timer.scoreboard.StuckTimer;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.StringUtils.FormatType;

import me.bitvise.lazarus.utils.provider.Config;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.concurrent.TimeUnit;

public class StuckCommand extends SubCommand {

    public StuckCommand() {
        super("stuck", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        if(player.getWorld().getEnvironment() != World.Environment.NORMAL) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_STUCK_ONLY_IN_OVERWORLD);
            return;
        }

        Faction faction = ClaimManager.getInstance().getFactionAt(player);

        if(!(faction instanceof PlayerFaction) && !(faction instanceof WarzoneFaction)) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_STUCK_ONLY_FROM_ENEMY_CLAIMS);
            return;
        }

        PlayerFaction playerFaction = FactionsManager.getInstance().getPlayerFaction(player);

        if(playerFaction != null && playerFaction == faction) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_STUCK_IN_OWN_CLAIM);
            return;
        }

        StuckTimer timer = TimerManager.getInstance().getStuckTimer();

        if(timer.isActive(player)) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_STUCK_ALREADY_TELEPORTING);
            return;
        }

        FactionsManager.getInstance().setStuckInitialLocation(player, player.getLocation());

        Location safeLocation = ClaimManager.getInstance().getSafeLocation(player);
        safeLocation.setPitch(player.getLocation().getPitch());
        safeLocation.setYaw(player.getLocation().getYaw());

        timer.activate(player, safeLocation);

        if (Config.LUNAR_CLIENT_API_ENABLED && Bukkit.getPluginManager().isPluginEnabled("LunarClient-API")) {

            LunarClientAPI.getInstance().sendPacket(player, new LCPacketTitle("TITLE", Lang.FACTIONS_STUCK_TASK_STARTED_TITLE, TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5)));
            LunarClientAPI.getInstance().sendPacket(player, new LCPacketTitle("SUBTITLE", Lang.FACTIONS_STUCK_TASK_STARTED_SUBTITLE.replace("<time>", StringUtils.formatTime(Config.FACTION_STUCK_WARMUP, FormatType.SECONDS_TO_MINUTES)), TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5)));
        }

        player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_STUCK_TASK_STARTED.replace("<time>", StringUtils.formatTime(Config.FACTION_STUCK_WARMUP, FormatType.SECONDS_TO_MINUTES)));
    }
}
