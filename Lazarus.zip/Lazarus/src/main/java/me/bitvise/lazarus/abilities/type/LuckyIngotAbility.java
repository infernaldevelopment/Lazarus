package me.bitvise.lazarus.abilities.type;

import me.bitvise.lazarus.abilities.AbilityItem;
import me.bitvise.lazarus.abilities.AbilityType;
import me.bitvise.lazarus.utils.creator.ConfigCreator;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.abilities.utils.AbilityUtils;
import org.apache.commons.lang.time.DurationFormatUtils;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.potion.PotionEffect;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class LuckyIngotAbility extends AbilityItem {

    private int percentage;

    private List<PotionEffect> positiveEffects;
    private List<PotionEffect> negativeEffects;

    public LuckyIngotAbility(ConfigCreator config) {
        super(AbilityType.LUCKY_INGOT, "LUCKY_INGOT", config);

        this.overrideActivationMessage();
    }

    @Override
    protected void disable() {
        this.positiveEffects.clear();
        this.negativeEffects.clear();
    }

    @Override
    protected void loadAdditionalData(ConfigurationSection abilitySection) {
        this.percentage = abilitySection.getInt("POSITIVE_EFFECT_PERCENTAGE");

        this.positiveEffects = AbilityUtils.loadEffects(abilitySection, "POSITIVE_EFFECTS");
        this.negativeEffects = AbilityUtils.loadEffects(abilitySection, "NEGATIVE_EFFECTS");
    }

    public void sendActivationMessage(Player player, List<PotionEffect> effects) {
        this.activationMessage.forEach(line -> player.sendMessage(line
            .replace("<abilityName>", this.displayName)
            .replace("<effects>", AbilityUtils.getEffectList(effects, Lang.ABILITIES_LUCKY_INGOT_EFFECT_FORMAT))
            .replace("<cooldown>", DurationFormatUtils.formatDurationWords(this.cooldown * 1000, true, true))));
    }

    @Override
    protected boolean onItemClick(Player player, PlayerInteractEvent event) {
        List<PotionEffect> effects = this.positiveEffects;

        if(ThreadLocalRandom.current().nextInt() > this.percentage) {
            effects = this.negativeEffects;
        }

        this.addEffects(player, effects);
        this.sendActivationMessage(player, effects);

        event.setCancelled(true);
        return true;
    }
}
