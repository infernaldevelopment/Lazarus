package me.bitvise.lazarus.handlers.timer;

import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.utils.*;
import me.bitvise.lazarus.utils.provider.Config;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.handlers.manager.Handler;

import org.bukkit.Sound;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public class ByrdeHandler extends Handler implements Listener {

    public void startByrdeTimer(CommandSender sender, int time) {
        if(this.isActive()) {
            sender.sendMessage(Lang.PREFIX + Lang.BYRDE_ALREADY_RUNNING);
            return;
        }

        TimerManager.getInstance().getByrdeTimer().activate(time);
        Messages.sendMessage(Lang.BYRDE_STARTED.replace("<time>", StringUtils.formatTime(time, StringUtils.FormatType.SECONDS_TO_HOURS)));
    }

    public void stopByrdeTimer(CommandSender sender) {
        if(!this.isActive()) {
            sender.sendMessage(Lang.PREFIX + Lang.BYRDE_NOT_RUNNING);
            return;
        }

        TimerManager.getInstance().getByrdeTimer().cancel();
        Messages.sendMessage(Lang.BYRDE_ENDED);
    }

    public boolean isActive() {
        return TimerManager.getInstance().getByrdeTimer().isActive();
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = event.getEntity().getKiller();

        String rankPrefixVictim = Color.translate(ChatHandler.getInstance().getPrefix(victim));
        String rankPrefixKiller = Color.translate(ChatHandler.getInstance().getPrefix(killer));

        if (this.isActive()) {
            if (killer != null) {
                if (Config.BYRDE_HEAL_PLAYER_AFTER_KILL) {
                    killer.sendMessage(Lang.PREFIX + Lang.BYRDE_HEAL_PLAYER_AFTER_KILL_MESSAGE.replace("<player>", victim.getName()).replace("<prefix>", rankPrefixVictim));
                    victim.sendMessage(Lang.PREFIX + Lang.BYRDE_VICTIM_DEATH_MESSAGE.replace("<player>", killer.getName()).replace("<prefix>", rankPrefixKiller));

                    killer.playSound(killer.getLocation(), Sound.valueOf(Config.BYRDE_SOUND_HEAL_PLAYER_AFTER_KILL), 2.5f, 2.5f);
                    killer.getWorld().createExplosion(killer.getLocation(), 10);
                }
            }
        }
    }
}

