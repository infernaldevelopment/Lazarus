package me.bitvise.lazarus.abilities.type;

import me.bitvise.lazarus.abilities.AbilityItem;
import me.bitvise.lazarus.abilities.AbilityType;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.timer.scoreboard.EnderPearlTimer;
import me.bitvise.lazarus.utils.creator.ConfigCreator;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

public class SecondChanceAbility extends AbilityItem {

    public SecondChanceAbility(ConfigCreator config) {
        super(AbilityType.SECOND_CHANCE, "SECOND_CHANCE", config);
    }

    @Override
    protected boolean onItemClick(Player player, PlayerInteractEvent event) {
        EnderPearlTimer enderPearlTimer = TimerManager.getInstance().getEnderPearlTimer();

        if(!enderPearlTimer.isActive(player)) {
            player.sendMessage(Lang.ABILITIES_PREFIX + Lang.ABILITIES_SECOND_CHANCE_NOT_ON_COOLDOWN);
            return false;
        }

        enderPearlTimer.cancel(player);

        event.setCancelled(true);
        return true;
    }
}
