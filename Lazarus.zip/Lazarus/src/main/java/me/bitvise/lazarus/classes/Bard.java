package me.bitvise.lazarus.classes;

import lombok.Getter;
import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.timer.cooldown.CooldownTimer;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.item.ItemUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.classes.items.BardClickableItem;
import me.bitvise.lazarus.classes.items.BardHoldableItem;
import me.bitvise.lazarus.classes.manager.PvpClass;
import me.bitvise.lazarus.classes.manager.PvpClassManager;
import me.bitvise.lazarus.classes.utils.PvpClassUtils;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.claim.ClaimManager;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.Event.Result;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class Bard extends PvpClass {

    @Getter private final Map<UUID, BardPower> bardPowers;

    private final List<BardClickableItem> clickables;
    private final List<BardHoldableItem> holdables;

    private final BardHoldableTask holdableTask;

    public Bard(PvpClassManager manager) {
        super(manager, "Bard",
            Material.GOLD_HELMET,
            Material.GOLD_CHESTPLATE,
            Material.GOLD_LEGGINGS,
            Material.GOLD_BOOTS
        );

        this.bardPowers = new HashMap<>();

        this.clickables = PvpClassUtils.loadBardClickableItems();
        this.holdables = PvpClassUtils.loadBardHoldableItems();

        this.holdableTask = new BardHoldableTask();
    }

    @Override
    public void disable() {
        super.disable();

        this.bardPowers.clear();
        this.clickables.clear();
        this.holdables.clear();

        this.holdableTask.cancel();
    }

    private BardClickableItem getClickableItem(ItemStack item) {
        return this.clickables.stream().filter(clickable -> clickable.getItem().getType() == item.getType()
        && clickable.getItem().getDurability() == item.getDurability()).findFirst().orElse(null);
    }

    private BardHoldableItem getHoldableItem(ItemStack item) {
        return this.holdables.stream().filter(holdable -> holdable.getItem().getType() == item.getType()
        && holdable.getItem().getDurability() == item.getDurability()).findFirst().orElse(null);
    }

    private double getPower(UUID uuid) {
        return this.bardPowers.get(uuid).getPower() / 1000;
    }

    public String getBardPower(UUID uuid) {
        return String.format(Locale.ROOT, "%.1f", this.getPower(uuid));
    }

    private void modifyPower(Player player, int amount) {
        this.bardPowers.get(player.getUniqueId()).withdrawPower(amount);
    }

    private void applyHoldableEffect(Player player, PlayerFaction faction, BardHoldableItem item) {
        if(faction == null) {
            if(!item.isCanBardHimself()) return;

            this.getManager().addPotionEffect(player, item.getPotionEffect());
            return;
        }

        for(Player member : faction.getOnlinePlayers()) {
            if(player.getWorld() != member.getWorld() || (!item.isCanBardHimself() && player == member)) continue;
            if(player.getLocation().distance(member.getLocation()) > item.getDistance()) continue;

            this.getManager().addPotionEffect(member, item.getPotionEffect());
        }
    }

    private void applyClickableEffect(Player player, PlayerFaction faction, BardClickableItem item) {
        if(item.isApplyToEnemy()) {
            this.getManager().addPotionEffect(player, item.getPotionEffect());
            int amountOfEnemies = 0;

            for(Entity nearby : player.getNearbyEntities(item.getDistance(), item.getDistance(), item.getDistance())) {
                if(!(nearby instanceof Player)) continue;

                Player enemy = (Player) nearby;
                if(Lazarus.getInstance().getStaffModeManager().isInStaffModeOrVanished(enemy)) continue;
                if(ClaimManager.getInstance().getFactionAt(enemy).isSafezone()) continue;
                if(TimerManager.getInstance().getPvpProtTimer().isActive(enemy)) continue;

                PlayerFaction enemyFaction = FactionsManager.getInstance().getPlayerFaction(enemy);
                if(faction != null && (faction == enemyFaction || faction.isAlly(enemyFaction))) continue;

                amountOfEnemies++;

                this.getManager().addPotionEffect(enemy, item.getPotionEffect());
                TimerManager.getInstance().getCombatTagTimer().activate(enemy.getUniqueId());

                enemy.sendMessage(Lang.PREFIX + Lang.BARD_CLICKABLE_MESSAGE_OTHERS.replace("<effect>",
                item.getChatColor() + StringUtils.getPotionEffectName(item.getPotionEffect())));
            }

            player.sendMessage(Lang.PREFIX + Lang.BARD_CLICKABLE_MESSAGE_ENEMY
                .replace("<effect>", item.getChatColor() + StringUtils.getPotionEffectName(item.getPotionEffect()))
                .replace("<amount>", String.valueOf(amountOfEnemies)));
        } else {
            if(faction != null) {
                int amountOfTeammates = 0;

                for(Player member : faction.getOnlinePlayers()) {
                    if(player.getWorld() != member.getWorld() || (!item.isCanBardHimself() && player == member)) continue;
                    if(player.getLocation().distance(member.getLocation()) > item.getDistance()) continue;

                    this.getManager().addPotionEffect(member, item.getPotionEffect());

                    if(member != player) {
                        amountOfTeammates++;

                        member.sendMessage(Lang.PREFIX + Lang.BARD_CLICKABLE_MESSAGE_OTHERS.replace("<effect>",
                        item.getChatColor() + StringUtils.getPotionEffectName(item.getPotionEffect())));
                    }
                }

                player.sendMessage(Lang.PREFIX + Lang.BARD_CLICKABLE_MESSAGE_FRIENDLY
                    .replace("<effect>", item.getChatColor() + StringUtils.getPotionEffectName(item.getPotionEffect()))
                    .replace("<amount>", String.valueOf(amountOfTeammates)));
            } else {
                if(!item.isCanBardHimself()) {
                    player.sendMessage(Lang.PREFIX + Lang.BARD_CAN_NOT_BARD_TO_YOURSELF);
                    return;
                }

                player.sendMessage(Lang.PREFIX + Lang.BARD_CLICKABLE_MESSAGE_OTHERS.replace("<effect>",
                item.getChatColor() + StringUtils.getPotionEffectName(item.getPotionEffect())));

                this.getManager().addPotionEffect(player, item.getPotionEffect());
            }
        }
    }

    private boolean canBard(Player player) {
        if(Lazarus.getInstance().getStaffModeManager().isInStaffModeOrVanished(player)) {
            player.sendMessage(Lang.PREFIX + Lang.BARD_VANISHED_OR_IN_STAFFMODE);
            return false;
        }

        if(TimerManager.getInstance().getPvpProtTimer().isActive(player)) {
            player.sendMessage(Lang.PREFIX + Lang.BARD_CAN_NOT_BARD_WITH_PVP_TIMER);
            return false;
        }

        if(ClaimManager.getInstance().getFactionAt(player).isSafezone()) {
            player.sendMessage(Lang.PREFIX + Lang.BARD_CAN_NOT_BARD_IN_SAFEZONE);
            return false;
        }

        if(Lazarus.getInstance().getSotwHandler().isUnderSotwProtection(player)) {
            player.sendMessage(Lang.PREFIX + Lang.BARD_CAN_NOT_BARD_WHEN_SOTW_NOT_ENABLED);
            return false;
        }

        return true;
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlayerItemHeld(PlayerItemHeldEvent event) {
        Player player = event.getPlayer();
        if(!this.isActive(player)) return;

        BardHoldableItem holdableItem = this.getHoldableItem(player.getItemInHand());
        if(holdableItem == null || !this.canBard(player)) return;

        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);
        this.applyHoldableEffect(player, faction, holdableItem);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerInteract(PlayerInteractEvent event) {
        if(event.useInteractedBlock() == Result.DENY && event.useItemInHand() == Result.DENY) return;

        if(!this.isActive(event.getPlayer()) || !event.hasItem()) return;
        if(event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();

        BardClickableItem clickableItem = this.getClickableItem(event.getItem());
        if(clickableItem == null || !this.canBard(player)) return;

        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);
        CooldownTimer timer = TimerManager.getInstance().getCooldownTimer();

        if(timer.isActive(player, "BARDBUFF")) {
            player.sendMessage(Lang.PREFIX + Lang.BARD_CLICKABLE_ACTIVE_COOLDOWN
            .replace("<seconds>", timer.getTimeLeft(player, "BARDBUFF")));
            return;
        }

        int currentPower = (int) this.getPower(player.getUniqueId());

        if(currentPower < clickableItem.getEnergyNeeded()) {
            player.sendMessage(Lang.PREFIX + Lang.BARD_CLICKABLE_NOT_ENOUGH_ENERGY
                .replace("<energy>", String.valueOf(clickableItem.getEnergyNeeded()))
                .replace("<currentEnergy>", String.valueOf(currentPower)));

            return;
        }

        if(Config.BARD_COMBAT_TAG_ON_CLICKABLE_ITEM || clickableItem.isApplyToEnemy()) {
            TimerManager.getInstance().getCombatTagTimer().activate(player.getUniqueId());
        }

        this.modifyPower(player, clickableItem.getEnergyNeeded());
        ItemUtils.removeOneItem(player);

        timer.activate(player, "BARDBUFF", clickableItem.getCooldown(),
            Lang.PREFIX + Lang.BARD_CLICKABLE_COOLDOWN_EXPIRED);

        this.applyClickableEffect(player, faction, clickableItem);
    }

    class BardHoldableTask extends BukkitRunnable {

        BardHoldableTask() {
            this.runTaskTimerAsynchronously(Lazarus.getInstance(), 0L, 20L);
        }

        @Override
        public void run() {
            getPlayers().forEach(uuid -> {
                Player player = Bukkit.getPlayer(uuid);
                if(player == null) return;

                BardHoldableItem holdableItem = getHoldableItem(player.getItemInHand());
                if(holdableItem == null || !canBard(player)) return;

                PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);
                applyHoldableEffect(player, faction, holdableItem);
            });
        }
    }

    public static class BardPower {

        private double power;

        public BardPower() {
            this.power = System.currentTimeMillis();
        }

        double getPower() {
            return Math.min(Config.BARD_MAX_ENERGY, System.currentTimeMillis() - this.power);
        }

        void withdrawPower(int amount) {
            this.power = System.currentTimeMillis() - (this.getPower() - (amount * 1000));
        }
    }
}