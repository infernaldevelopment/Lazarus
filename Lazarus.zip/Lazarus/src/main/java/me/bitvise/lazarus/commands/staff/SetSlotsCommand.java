package me.bitvise.lazarus.commands.staff;

import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.nms.NmsUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class SetSlotsCommand extends BaseCommand {

    public SetSlotsCommand() {
        super("setslots", Collections.singletonList("slots"), "lazarus.setslots");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.PREFIX + Lang.SET_SLOTS_USAGE);
            return;
        }

        String prefix;
        if (sender instanceof Player) {
            Player p = (Player) sender;
            prefix = Color.translate(ChatHandler.getInstance().getPrefix(p));
        } else {
            prefix = "&4";
        }

        if(!this.checkNumber(sender, args[0])) return;
        int amount = Math.abs(Integer.parseInt(args[0]));

        NmsUtils.getInstance().changeServerSlots(amount);

        Lang.SET_SLOTS_MESSAGE.forEach(line -> Messages.sendMessage(line.replace("<number>",
        String.valueOf(amount)).replace("<player>", sender.getName()).replace("<prefix>", prefix)));
    }
}
