package me.bitvise.lazarus.map.games.conquest.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.provider.Lang;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.map.games.conquest.RunningConquest;

import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.command.CommandSender;

public class ConquestSetPointsCommand extends SubCommand {

    public ConquestSetPointsCommand() {
        super("setpoints", "lazarus.conquest.setpoints");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length < 2) {
            sender.sendMessage(Lang.CONQUEST_PREFIX + Lang.CONQUEST_SET_POINTS_USAGE);
            return;
        }

        RunningConquest conquest = Lazarus.getInstance().getConquestManager().getRunningConquest();

        if(conquest == null) {
            sender.sendMessage(Lang.CONQUEST_PREFIX + Lang.CONQUEST_EXCEPTION_NOT_RUNNING);
            return;
        }

        PlayerFaction faction = FactionsManager.getInstance().searchForFaction(args[0]);

        if(faction == null) {
            sender.sendMessage(Lang.CONQUEST_PREFIX + Lang.CONQUEST_SET_POINTS_INVALID_FACTION
            .replace("<argument>", args[0]));
            return;
        }

        if(!this.checkNumber(sender, args[1])) return;

        int amount = Math.min(Integer.parseInt(args[1]), Config.CONQUEST_POINTS_TO_WIN - 1);
        conquest.setPoints(faction, amount);

        sender.sendMessage(Lang.CONQUEST_PREFIX + Lang.CONQUEST_SET_POINTS_CHANGED
        .replace("<faction>", faction.getName()).replace("<amount>", String.valueOf(amount)));
    }
}
