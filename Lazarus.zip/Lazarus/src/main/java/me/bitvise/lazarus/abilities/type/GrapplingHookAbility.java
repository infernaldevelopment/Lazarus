package me.bitvise.lazarus.abilities.type;

import me.bitvise.lazarus.abilities.AbilityItem;
import me.bitvise.lazarus.abilities.AbilityType;
import me.bitvise.lazarus.utils.creator.ConfigCreator;
import org.bukkit.event.Listener;

public class GrapplingHookAbility extends AbilityItem implements Listener {

    private int duration;
    private final String cooldownName;

    public GrapplingHookAbility(ConfigCreator config) {
        super(AbilityType.GRAPPLING_HOOK, "GRAPPLINGHOOK", config);

        this.cooldownName = "GrapplingHook";
    }
}
