package me.bitvise.lazarus.commands.staff;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.command.CommandSender;

import java.util.Collections;

public class FreezeAllCommand extends BaseCommand {

    public FreezeAllCommand() {
        super("freezeall", Collections.singletonList("ssall"), "lazarus.freezeall");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Lazarus.getInstance().getFreezeHandler().toggleFreezeAll(sender);
    }
}
