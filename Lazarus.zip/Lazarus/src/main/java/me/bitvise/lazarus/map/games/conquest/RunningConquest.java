package me.bitvise.lazarus.map.games.conquest;

import lombok.Getter;
import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.map.games.Capzone;
import me.bitvise.lazarus.map.games.conquest.event.ConquestCappedEvent;
import me.bitvise.lazarus.map.games.loot.LootData;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.Tasks;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicBoolean;

@Getter
public class RunningConquest extends BukkitRunnable {

    private final ConquestData conquest;
    private final LootData loot;

    private final long startTime;

    private final Map<ZoneType, Capzone> capzones;
    private final Map<PlayerFaction, Integer> factionPoints;

    private final AtomicBoolean running;

    RunningConquest(ConquestData conquest, LootData loot, int time) {
        this.conquest = conquest;
        this.loot = loot;

        this.startTime = System.currentTimeMillis();
        this.capzones = new EnumMap<>(ZoneType.class);

        this.conquest.getCuboids().forEach((type, cuboid) -> {
            this.capzones.put(type, new Capzone(cuboid, time));
            cuboid.getPlayers().forEach(player -> this.onPlayerEnterCapzone(player, type));
        });

        this.factionPoints = Collections.synchronizedMap(new LinkedHashMap<>());
        this.running = new AtomicBoolean(true);

        this.runTaskTimerAsynchronously(Lazarus.getInstance(), 0L, 20L);
    }

    public String getTimeEntry(ZoneType type) {
        return type.getColor() + this.capzones.get(type).getTimeLeft();
    }

    private int getPoints(PlayerFaction faction) {
        return this.factionPoints.getOrDefault(faction, 0);
    }

    public int setPoints(PlayerFaction faction, int value) {
        value = Config.CONQUEST_ALLOW_NEGATIVE_POINTS ? value : Math.max(0, value);
        this.factionPoints.put(faction, value);

        List<Entry<PlayerFaction, Integer>> copy = new ArrayList<>(this.factionPoints.entrySet());
        this.factionPoints.clear();

        copy.stream().sorted(Entry.<PlayerFaction, Integer>comparingByValue().reversed())
        .forEach(entry -> this.factionPoints.put(entry.getKey(), entry.getValue()));

        return value;
    }

    private int addPoints(PlayerFaction faction, int amount) {
        return this.setPoints(faction, this.getPoints(faction) + amount);
    }

    void removePoints(PlayerFaction faction, int amount) {
        this.setPoints(faction, this.getPoints(faction) - amount);
    }

    private void handleWin(Player capper, PlayerFaction faction) {
        this.running.set(false);

        Lang.CONQUEST_CAPPED.forEach(line -> Messages.sendMessage(line
            .replace("<faction>", faction.getName())
            .replace("<uptime>", StringUtils.formatMillis(System.currentTimeMillis() - this.startTime))));

        Tasks.sync(() -> {
            new ConquestCappedEvent(this.conquest, this.loot, capper);
            Lazarus.getInstance().getConquestManager().stopConquest(false);
        });
    }

    private void sendStartedCappingMessage(PlayerFaction faction, ZoneType type) {
        faction.sendMessage(Lang.CONQUEST_PREFIX + Lang
        .CONQUEST_STARTED_CAPPING.replace("<zone>", type.getName()));
    }

    void onPlayerEnterCapzone(Player player, ZoneType type) {
        if(Lazarus.getInstance().getStaffModeManager().isInStaffModeOrVanished(player)) return;

        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);
        if(faction == null) return;

        Capzone capzone = this.capzones.get(type);

        if(capzone.hasNoPlayers()) {
            this.sendStartedCappingMessage(faction, type);
        }

        capzone.addPlayer(player);
    }

    void onPlayerLeaveCapzone(Player player, ZoneType type) {
        if(FactionsManager.getInstance().getPlayerFaction(player) == null) return;

        Capzone capzone = this.capzones.get(type);
        if(!capzone.getPlayers().contains(player.getName())) return;

        if(capzone.getCapperName().equals(player.getName())) {
            capzone.setTime(Config.CONQUEST_CAP_TIME);

            player.sendMessage(Lang.CONQUEST_PREFIX + Lang.CONQUEST_STOPPED_CAPPING
            .replace("<zone>", type.getName()));

            if(capzone.getPlayers().size() > 1) {
                this.sendStartedCappingMessage(FactionsManager.getInstance()
                .getPlayerFaction(capzone.getNextCapper()), type);
            }
        }

        capzone.removePlayer(player);
    }

    @Override
    public void run() {
        this.capzones.values().forEach(capzone -> {
            if(capzone.hasNoPlayers()) return;
            if(capzone.decreaseTime() > 0) return;

            capzone.setTime(Config.CONQUEST_CAP_TIME);

            Player capper = capzone.getCapper();
            PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(capper);

            int current = this.addPoints(faction, Config.CONQUEST_POINTS_PER_CAP);

            if(current >= Config.CONQUEST_POINTS_TO_WIN && this.running.get()) {
                this.handleWin(capper, faction);
            }
        });
    }
}
