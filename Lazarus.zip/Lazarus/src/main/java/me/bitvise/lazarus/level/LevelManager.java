package me.bitvise.lazarus.level;

import me.bitvise.lazarus.utils.ManagerEnabler;
import org.bukkit.event.Listener;

public class LevelManager implements Listener, ManagerEnabler {


}
