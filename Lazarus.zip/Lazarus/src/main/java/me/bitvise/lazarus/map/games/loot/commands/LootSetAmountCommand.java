package me.bitvise.lazarus.map.games.loot.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.map.games.loot.LootData;
import org.bukkit.command.CommandSender;

public class LootSetAmountCommand extends SubCommand {

    public LootSetAmountCommand() {
        super("setamount", "lazarus.loot.setamount");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length < 2) {
            sender.sendMessage(Lang.LOOT_PREFIX + Lang.LOOT_SET_AMOUNT_USAGE);
            return;
        }

        LootData loot = Lazarus.getInstance().getLootManager().getLootByName(args[0]);

        if(loot == null) {
            sender.sendMessage(Lang.LOOT_PREFIX + Lang.LOOT_EXCEPTION_DOESNT_EXIST.replace("<loot>", args[0]));
            return;
        }

        if(!this.checkNumber(sender, args[1])) return;

        loot.setAmount(Math.abs(Integer.parseInt(args[1])));

        sender.sendMessage(Lang.LOOT_PREFIX + Lang.LOOT_SET_AMOUNT_CHANGED
        .replace("<loot>", loot.getName()).replace("<amount>", args[1]));
    }
}
