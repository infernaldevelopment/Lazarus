package me.bitvise.lazarus.factions.commands.admin;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionPlayer;
import me.bitvise.lazarus.factions.enums.Role;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;

public class ForceDemoteCommand extends SubCommand {

    public ForceDemoteCommand() {
        super("forcedemote", "lazarus.factions.forcedemote");

        this.setExecuteAsync(true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FORCE_DEMOTE_USAGE);
            return;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        if(!this.checkOfflinePlayer(sender, target, args[0])) return;

        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(target.getUniqueId());

        if(faction == null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION.replace("<player>", target.getName()));
            return;
        }

        FactionPlayer targetPlayer = faction.getMember(target);

        if(targetPlayer.getRole() == Role.LEADER) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FORCE_DEMOTE_CANNOT_DEMOTE_LEADER);
            return;
        }

        if(targetPlayer.getRole().getDemote() == null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FORCE_DEMOTE_MIN_DEMOTE);
            return;
        }

        targetPlayer.setRole(targetPlayer.getRole().getDemote());

        if(Config.TAB_ENABLED) {
            Lazarus.getInstance().getTabManager().updateFactionPlayerList(faction);
        }

        sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FORCE_DEMOTED_SENDER.replace("<player>",
        target.getName()).replace("<role>", targetPlayer.getRole().getName()));

        faction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FORCE_DEMOTED_FACTION.replace("<player>",
        target.getName()).replace("<role>", targetPlayer.getRole().getName()));
    }
}
