package me.bitvise.lazarus.factions.commands.admin;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.timer.cooldown.FactionFreezeTimer;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.factions.FactionsManager;
import org.apache.commons.lang.time.DurationFormatUtils;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class SetFreezeCommand extends SubCommand {

    public SetFreezeCommand() {
        super("setfreeze", Collections.singletonList("setregen"), "lazarus.factions.setfreeze");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length < 2) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_SET_FREEZE_USAGE);
            return;
        }

        PlayerFaction faction = FactionsManager.getInstance().searchForFaction(args[0]);

        if(faction == null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FACTION_DOESNT_EXIST.replace("<argument>", args[0]));
            return;
        }

        int duration = StringUtils.parseSeconds(args[1]);

        if(duration == -1) {
            sender.sendMessage(Lang.PREFIX + Lang.COMMANDS_INVALID_DURATION);
            return;
        }

        FactionFreezeTimer timer = TimerManager.getInstance().getFactionFreezeTimer();

        timer.cancel(faction);
        timer.activate(faction, duration);

        String prefix;
        if (sender instanceof Player) {
            Player p = (Player) sender;
            prefix = Color.translate(ChatHandler.getInstance().getPrefix(p));
        } else {
            prefix = Color.translate("&4");
        }

        String time = DurationFormatUtils.formatDurationWords(duration * 1000, true, true);

        sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_SET_FREEZE_CHANGED_SENDER
            .replace("<faction>", faction.getName())
            .replace("<time>", time));

        faction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_SET_FREEZE_CHANGED_FACTION
            .replace("<player>", sender.getName())
             .replace("<prefix>", prefix)
            .replace("<time>", time));
    }
}
