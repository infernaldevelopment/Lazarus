package me.bitvise.lazarus.factions.commands.admin;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.Faction;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.type.SystemFaction;

import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.command.CommandSender;

import java.util.Collections;

public class SystemRenameCommand extends SubCommand {

    public SystemRenameCommand() {
        super("systemrename", Collections.singletonList("renamesystem"), "lazarus.factions.systemrename");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length < 2) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_SYSTEM_RENAME_USAGE);
            return;
        }

        Faction faction = FactionsManager.getInstance().getFactionByName(args[0]);

        if(faction == null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FACTION_DOESNT_EXIST.replace("<argument>", args[0]));
            return;
        }

        if(!(faction instanceof SystemFaction)) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_SYSTEM_RENAME_NOT_SYSTEM_FACTION);
            return;
        }

        if(faction.getClass() != SystemFaction.class) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_SYSTEM_RENAME_CANNOT_RENAME_THIS_TYPE);
            return;
        }

        if(faction.getName().equalsIgnoreCase(args[1])) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_SYSTEM_RENAME_SAME_NAME.replace("<name>", args[1]));
            return;
        }

        if(FactionsManager.getInstance().getFactionByName(args[1]) != null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FACTION_ALREADY_EXISTS.replace("<name>", args[1]));
            return;
        }

        String oldName = faction.getName(sender);

        if(!faction.setName(sender, args[1], true)) return;

        sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_SYSTEM_RENAMED.replace("<faction>",
        oldName).replace("<name>", ((SystemFaction) faction).getColor() + args[1]));
    }
}
