package me.bitvise.lazarus.map.games.dragon.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.map.games.loot.LootData;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class EnderDragonLootCommand extends SubCommand {

    EnderDragonLootCommand() {
        super("loot", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        LootData loot = Lazarus.getInstance().getLootManager().getLootByName("EnderDragon");
        ((Player) sender).openInventory(loot.getInventory());
    }
}
