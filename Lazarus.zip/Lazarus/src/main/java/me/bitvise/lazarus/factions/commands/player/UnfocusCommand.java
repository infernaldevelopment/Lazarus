package me.bitvise.lazarus.factions.commands.player;

import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.enums.Role;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;

public class UnfocusCommand extends BaseCommand {

    public UnfocusCommand() {
        super("unfocus", Arrays.asList("removeofocus"), "lazarus.unfocus", true);

        this.setExecuteAsync(true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);

        if(faction == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
            return;
        }

        if(!faction.getMember(player).getRole().isAtLeast(Role.CAPTAIN)) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NO_PERMISSION.replace("<role>", Role.getName(Role.CAPTAIN)));
            return;
        }

        if(faction.getFocused() == null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.UNFOCUS_NOT_FOCUSING);
            return;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(faction.getFocused());

        faction.unfocusPlayer(target);
        player.sendMessage(Lang.FACTION_PREFIX + Lang.UNFOCUS_UNFOCUSED.replace("<player>", target.getName()));
    }
}
