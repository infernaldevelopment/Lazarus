package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.menu.type.LeaderboardsMenu;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class LeaderboardsCommand extends BaseCommand {

    public LeaderboardsCommand() {
        super("leaderboards", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        new LeaderboardsMenu().openMenu(player);
    }
}
