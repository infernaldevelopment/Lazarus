package me.bitvise.lazarus.menu.type;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.map.deathban.Deathban;
import me.bitvise.lazarus.map.deathban.DeathbanManager;
import me.bitvise.lazarus.menu.Button;
import me.bitvise.lazarus.menu.Menu;
import me.bitvise.lazarus.utils.item.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Map;

public class DeathbanMenu extends Menu {


    @Override
    public String getTitle(Player player) {
        return "&8Deathban Manager";
    }

    @Override
    public int getSize() {
        return 9*3;
    }

    @Override
    public Map<Integer, Button> getButtons(Player player) {
        Map<Integer, Button> buttons = Maps.newHashMap();

        return buttons;
    }

    private static class DeathbanStatusButton extends Button {

        @Override
        public ItemStack getButtonItem(Player player) {
            List<String> lore = Lists.newArrayList();

            return new ItemBuilder(Material.COMPASS).setName("&aDeathban Status").setLore(lore).build();
        }
    }


    private static class DeathbanReviveButton extends Button {

        @Override
        public ItemStack getButtonItem(Player player) {
            List<String> lore = Lists.newArrayList();
            return new ItemBuilder(Material.DIAMOND_SWORD).setName("&aDeathban Revive").setLore(lore).build();
        }
    }
}
