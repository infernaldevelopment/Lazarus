package me.bitvise.lazarus.abilities.type;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;
import me.bitvise.lazarus.abilities.AbilityItem;
import me.bitvise.lazarus.abilities.AbilityType;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.timer.cooldown.CooldownTimer;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.creator.ConfigCreator;
import me.bitvise.lazarus.utils.nms.NmsUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import org.apache.commons.lang.time.DurationFormatUtils;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.UUID;

public class ExoticBoneAbility extends AbilityItem implements Listener {

    private int duration;
    private int hits;
    private final String cooldownName;

    private final Table<UUID, UUID, Integer> playerHits;

    public ExoticBoneAbility(ConfigCreator config) {
        super(AbilityType.EXOTIC_BONE, "EXOTIC_BONE", config);

        this.cooldownName = "ExoticBone";
        this.playerHits = HashBasedTable.create();

        this.overrideActivationMessage();
    }

    @Override
    protected void disable() {
        this.playerHits.clear();
    }

    @Override
    protected void loadAdditionalData(ConfigurationSection abilitySection) {
        this.duration = abilitySection.getInt("DURATION");
        this.hits = abilitySection.getInt("HITS") - 1;
    }

    public void sendActivationMessage(Player player, Player target) {
        this.activationMessage.forEach(line -> player.sendMessage(line
            .replace("<abilityName>", this.displayName)
            .replace("<player>", target.getName())
            .replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target)))
            .replace("<duration>", DurationFormatUtils.formatDurationWords(this.duration * 1000, true, true))
            .replace("<cooldown>", DurationFormatUtils.formatDurationWords(this.cooldown * 1000, true, true))));
    }

    @Override
    protected boolean onPlayerItemHit(Player damager, Player target, EntityDamageByEntityEvent event) {
        UUID damagerUUID = damager.getUniqueId();
        UUID targetUUID = target.getUniqueId();

        if(this.playerHits.contains(damagerUUID, targetUUID)) {
            int hitsNeeded = this.playerHits.get(damagerUUID, targetUUID) - 1;

            if(hitsNeeded == 0) {
                this.activateAbilityOnTarget(damager, target);
                this.playerHits.remove(damagerUUID, targetUUID);
                return true;
            }

            this.playerHits.put(damagerUUID, targetUUID, hitsNeeded);
            return false;
        }

        this.playerHits.put(damagerUUID, targetUUID, this.hits);
        return false;
    }

    private void activateAbilityOnTarget(Player damager, Player target) {
        TimerManager.getInstance().getCooldownTimer().activate(target, this.cooldownName, this.duration,
            Lang.ABILITIES_PREFIX + Lang.ABILITIES_EXOTIC_BONE_TARGET_EXPIRED);

        target.sendMessage(Lang.ABILITIES_PREFIX + Lang.ABILITIES_EXOTIC_BONE_TARGET_ACTIVATED
            .replace("<player>", damager.getName())
            .replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(damager)))
            .replace("<abilityName>", this.displayName)
            .replace("<duration>", DurationFormatUtils.formatDurationWords(this.duration * 1000, true, true)));

        this.sendActivationMessage(damager, target);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();

        CooldownTimer cooldownTimer = TimerManager.getInstance().getCooldownTimer();
        if(!cooldownTimer.isActive(player, this.cooldownName)) return;

        event.setCancelled(true);

        player.sendMessage(Lang.ABILITIES_PREFIX + Lang.ABILITIES_EXOTIC_BONE_CANNOT_INTERACT
            .replace("<time>", cooldownTimer.getDynamicTimeLeft(player, this.cooldownName)));
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();

        CooldownTimer cooldownTimer = TimerManager.getInstance().getCooldownTimer();
        if(!cooldownTimer.isActive(player, this.cooldownName)) return;

        event.setCancelled(true);

        player.sendMessage(Lang.ABILITIES_PREFIX + Lang.ABILITIES_EXOTIC_BONE_CANNOT_INTERACT
            .replace("<time>", cooldownTimer.getDynamicTimeLeft(player, this.cooldownName)));
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if(event.useInteractedBlock() == Event.Result.DENY || !event.hasBlock()) return;
        if(event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if(!NmsUtils.getInstance().getExoticBoneClickables().contains(event.getClickedBlock().getType())) return;

        Player player = event.getPlayer();

        CooldownTimer cooldownTimer = TimerManager.getInstance().getCooldownTimer();
        if(!cooldownTimer.isActive(player, this.cooldownName)) return;

        event.setCancelled(true);

        player.sendMessage(Lang.ABILITIES_PREFIX + Lang.ABILITIES_EXOTIC_BONE_CANNOT_INTERACT
            .replace("<time>", cooldownTimer.getDynamicTimeLeft(player, this.cooldownName)));
    }
}
