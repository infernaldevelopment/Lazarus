package me.bitvise.lazarus.handlers.chat;

import lombok.Getter;
import lombok.Setter;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.timer.cooldown.CooldownTimer;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.handlers.manager.Handler;
import me.bitvise.lazarus.utils.provider.Config;
import org.apache.commons.lang.time.DurationFormatUtils;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

@Getter
@Setter
public class ChatControlHandler extends Handler implements Listener {

    private boolean showFoundOre;
    private boolean muted;
    private int delay;

    public ChatControlHandler() {
        this.showFoundOre = true;
        this.delay = Config.DEFAULT_CHAT_DELAY;
    }

    public void toggleChat(CommandSender sender) {
        String prefix;
        if (sender instanceof Player) {
            Player p = (Player) sender;
            prefix = Color.translate(ChatHandler.getInstance().getPrefix(p));
        } else {
            prefix = Color.translate("&4");
        }

        if(this.isMuted()) {
            this.muted = false;

            Messages.sendMessage(Lang.PREFIX + Lang.CHAT_UNMUTED
            .replace("<player>", sender.getName()).replace("<prefix>", prefix));
            return;
        }

        this.muted = true;

        Messages.sendMessage(Lang.PREFIX + Lang.CHAT_MUTED
        .replace("<player>", sender.getName()).replace("<prefix>", prefix));
    }

    public void setDelay(CommandSender sender, String time) {
        int duration = StringUtils.parseSeconds(time);
        String prefix;
        if (sender instanceof Player) {
            Player p = (Player) sender;
            prefix = Color.translate(ChatHandler.getInstance().getPrefix(p));
        } else {
            prefix = Color.translate("&4");
        }

        if(duration == -1) {
            sender.sendMessage(Lang.PREFIX + Lang.COMMANDS_INVALID_DURATION);
            return;
        }

        this.delay = duration;

        Messages.sendMessage(Lang.PREFIX + Lang.CHAT_DELAY_BROADCAST.replace("<player>", sender.getName()).replace("<prefix>", prefix).replace("<delay>",
        DurationFormatUtils.formatDurationWords(this.delay * 1000L, true, true)));
    }

    public void toggleFoundOreMessages(CommandSender sender) {
        if(this.isShowFoundOre()) {
            this.showFoundOre = false;
            sender.sendMessage(Lang.PREFIX + Lang.CHAT_FOUNDORE_DISABLED);
            return;
        }

        this.showFoundOre = true;
        sender.sendMessage(Lang.PREFIX + Lang.CHAT_FOUNDORE_ENABLED);
    }

    public void clearChat(CommandSender sender) {
        String prefix;
        if (sender instanceof Player) {
            Player p = (Player) sender;
            prefix = Color.translate(ChatHandler.getInstance().getPrefix(p));
        } else {
            prefix =  Color.translate("&4");
        }

        for(Player player : Bukkit.getOnlinePlayers()) {
            if(player.hasPermission("lazarus.chatcontrol.clear.bypass")) continue;

            for(int i = 0; i < 100; i++) {
                player.sendMessage("\n");
            }
        }

        Messages.sendMessage(Lang.PREFIX + Lang.CHAT_CLEAR_BROADCAST
        .replace("<player>", sender.getName()).replace("<prefix>", prefix));
    }

    @EventHandler(ignoreCancelled = true)
    public void onAsyncPlayerChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();

        if(this.isMuted() && !player.hasPermission("lazarus.chatcontrol.mute.bypass")) {

            event.setCancelled(true);
            player.sendMessage(Lang.PREFIX + Lang.CHAT_EVENT_MUTED_MESSAGE);

        } else if(this.getDelay() > 0 && !player.hasPermission("lazarus.chatcontrol.delay.bypass")) {

            CooldownTimer timer = TimerManager.getInstance().getCooldownTimer();

            if(timer.isActive(player, "CHAT")) {
                event.setCancelled(true);
                player.sendMessage(Lang.PREFIX + Lang.CHAT_COOLDOWN_MESSAGE
                .replace("<seconds>", timer.getTimeLeft(player, "CHAT")));
                return;
            }

            timer.activate(player, "CHAT", this.delay, null);
        }
    }
}
