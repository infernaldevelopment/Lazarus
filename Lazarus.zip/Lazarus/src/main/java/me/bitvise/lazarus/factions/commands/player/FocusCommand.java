package me.bitvise.lazarus.factions.commands.player;

import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.enums.Role;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class FocusCommand extends BaseCommand {

    public FocusCommand() {
        super("focus", "lazarus.focus", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FOCUS_USAGE);
            return;
        }

        Player player = (Player) sender;
        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);
        PlayerFaction focused = FactionsManager.getInstance().getPlayerFaction(faction.getFocused());

        if(faction == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
            return;
        }

        if(!faction.getMember(player).getRole().isAtLeast(Role.CAPTAIN)) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NO_PERMISSION
            .replace("<role>", Role.getName(Role.CAPTAIN)));
            return;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if(!this.checkPlayer(sender, target, args[0])) return;

        if(faction.getMember(target) != null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FOCUS_CANNOT_FOCUS);
            return;
        }

        if(faction.getFocused() == target.getUniqueId()) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FOCUS_ALREADY_FOCUSING
            .replace("<player>", target.getName()));
            return;
        }


        faction.sendMessage(Lang.FOCUS_FOCUSED.replace("<player>", target.getName()));
        faction.focusPlayer(target);
    }
}
