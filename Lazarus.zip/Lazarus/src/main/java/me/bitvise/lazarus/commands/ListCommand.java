package me.bitvise.lazarus.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

import java.util.ArrayList;
import java.util.List;

public class ListCommand extends BaseCommand {

    public ListCommand() {
        super("list", "lazarus.list");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        List<String> onlineplayers = new ArrayList<>();

        Bukkit.getOnlinePlayers().stream().forEach(online -> {
            if(!Config.LIST_SHOW_VANISHED_STAFF && Lazarus.getInstance().getVanishManager().isVanished(online)) return;

            onlineplayers.add(Color.translate(ChatHandler.getInstance().getPrefix(online) + online.getName()));
        });

        String onlineplayersname = onlineplayers.isEmpty() ? Lang.COMMANDS_NO_ONLINE_PLAYERS : String.join(ChatColor.YELLOW + ", ", onlineplayers);

        int online = Config.LIST_SHOW_VANISHED_STAFF ? Bukkit.getOnlinePlayers().size() : Bukkit.getOnlinePlayers().size() - Lazarus.getInstance().getVanishManager().vanishedAmount();

        Lang.LIST_COMMAND.forEach(message -> {

            message = message.replace("<players>", onlineplayersname);
            message = message.replace("<online>", String.valueOf(Bukkit.getOnlinePlayers().size()));
            message = message.replace("<maxonline>", String.valueOf(Bukkit.getMaxPlayers()));

            sender.sendMessage(Color.translate(message));
        });
    }
}
