package me.bitvise.lazarus.factions.commands.admin;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionPlayer;
import me.bitvise.lazarus.factions.enums.Role;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.factions.FactionsManager;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;

public class ForceKickCommand extends SubCommand {

    public ForceKickCommand() {
        super("forcekick", "lazarus.factions.forcekick");

        this.setExecuteAsync(true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FORCE_KICK_USAGE);
            return;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        if(!this.checkOfflinePlayer(sender, target, args[0])) return;

        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(target.getUniqueId());

        if(faction == null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION.replace("<player>", target.getName()));
            return;
        }

        FactionPlayer targetPlayer = faction.getMember(target);

        if(targetPlayer.getRole() == Role.LEADER) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FORCE_KICK_CANNOT_KICK_LEADER);
            return;
        }

        if(!FactionsManager.getInstance().kickPlayer(target, faction)) return;

        sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FORCE_KICKED_SENDER
        .replace("<player>", target.getName()).replace("<faction>", faction.getName()));

        if(target.isOnline()) target.getPlayer().sendMessage(Lang.FACTION_PREFIX +
        Lang.FACTIONS_FORCE_KICKED_SELF.replace("<name>", faction.getName()));

        faction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FORCE_KICKED_OTHERS.replace("<player>", target.getName()));
    }
}
