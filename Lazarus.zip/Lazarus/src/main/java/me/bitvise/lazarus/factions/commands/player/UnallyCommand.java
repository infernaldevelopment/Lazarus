package me.bitvise.lazarus.factions.commands.player;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.enums.Role;
import me.bitvise.lazarus.factions.type.PlayerFaction;

import me.bitvise.lazarus.utils.provider.Config;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class UnallyCommand extends SubCommand {

    public UnallyCommand() {
        super("unally", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(Config.FACTION_MAX_ALLIES <= 0) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_ALLIES_DISABLED);
            return;
        }

        if(args.length == 0) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_UNALLY_USAGE);
            return;
        }

        Player player = (Player) sender;

        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);

        if(faction == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
            return;
        }

        if(!faction.getMember(player).getRole().isAtLeast(Role.CAPTAIN)) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NO_PERMISSION.replace("<role>", Role.getName(Role.CAPTAIN)));
            return;
        }

        PlayerFaction targetFaction = FactionsManager.getInstance().searchForFaction(args[0]);

        if(targetFaction == null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FACTION_DOESNT_EXIST.replace("<argument>", args[0]));
            return;
        }

        if(!faction.isAlly(targetFaction)) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_UNALLY_NOT_ALLIES.replace("<faction>", targetFaction.getName(sender)));
            return;
        }

        if(!FactionsManager.getInstance().removeAllyRelation(faction, targetFaction)) return;

        faction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_UNALLY_REMOVED.replace("<faction>", targetFaction.getName()));
        targetFaction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_UNALLY_REMOVED.replace("<faction>", faction.getName()));
    }
}
