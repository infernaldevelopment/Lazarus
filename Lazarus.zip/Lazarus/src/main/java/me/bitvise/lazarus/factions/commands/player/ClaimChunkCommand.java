package me.bitvise.lazarus.factions.commands.player;

import me.bitvise.lazarus.claim.Claim;
import me.bitvise.lazarus.claim.ClaimManager;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.enums.Role;
import me.bitvise.lazarus.factions.type.PlayerFaction;

import me.bitvise.lazarus.utils.StringUtils;

import me.bitvise.lazarus.utils.provider.Config;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.Chunk;
import org.bukkit.World.Environment;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ClaimChunkCommand extends SubCommand {

    public ClaimChunkCommand() {
        super("claimchunk", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);

        if(faction == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
            return;
        }

        if(!faction.getMember(player).getRole().isAtLeast(Role.CO_LEADER)) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NO_PERMISSION.replace("<role>", Role.getName(Role.CO_LEADER)));
            return;
        }

        int claimCount = faction.getClaims().size();

        if(claimCount >= Config.FACTION_MAX_CLAIMS) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_MAX_CLAIMS_EXCEEDED);
            return;
        }

        if(claimCount >= faction.getMembers().size() * Config.FACTION_CLAIMS_PER_PLAYER) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_MAX_CLAIMS_EXCEEDED);
            return;
        }

        if(player.getWorld().getEnvironment() != Environment.NORMAL) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_CAN_CLAIM_ONLY_IN_OVERWORLD);
            return;
        }

        Chunk chunk = player.getLocation().getChunk();

        int x1 = chunk.getX() * 16;
        int x2 = x1 + 15;
        int z1 = chunk.getZ() * 16;
        int z2 = z1 + 15;

        Claim claim = new Claim(faction, chunk.getWorld(), x1, x2, z1, z2);

        if(!ClaimManager.getInstance().isSelectionConnected(faction, claim)) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_CLAIM_NOT_CONNECTED);
            return;
        }

        if(!ClaimManager.getInstance().canClaimSelection(faction, claim, player, true)) return;

        int price = ClaimManager.getInstance().getClaimPrice(faction, claim.sizeX() * claim.sizeZ());

        if(faction.getBalance() < price) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_NOT_ENOUGH_MONEY);
            return;
        }

        if(!ClaimManager.getInstance().addClaim(claim)) return;
        faction.removeBalance(price);

        faction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_CLAIM_CLAIMED
            .replace("<location1>", StringUtils.getLocationNameWithoutY(claim.getMinimumPoint()))
            .replace("<location2>", StringUtils.getLocationNameWithoutY(claim.getMaximumPoint()))
            .replace("<player>", player.getName()));
    }
}
