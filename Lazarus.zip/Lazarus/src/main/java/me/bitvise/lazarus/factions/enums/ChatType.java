package me.bitvise.lazarus.factions.enums;

import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.utils.provider.Config;

public enum ChatType {

    PUBLIC, ALLY, FACTION;

    public String getName() {
        return StringUtils.capitalize(this.name().toLowerCase());
    }

    public String getFormat() {
        if(this == ChatType.ALLY) {
            return Lang.FACTION_CHAT_ALLY_FORMAT;
        }

        return Lang.FACTION_CHAT_FACTION_FORMAT;
    }

    public static ChatType parseType(String arg) {
        switch(arg.toLowerCase()) {
            case "f":
            case "fc":
            case "faction": return ChatType.FACTION;
            case "a":
            case "ac":
            case "ally": return ChatType.ALLY;
            case "p":
            case "pc":
            case "public": return ChatType.PUBLIC;
            default: return null;
        }
    }

    public ChatType nextType() {
        switch(this) {
            case FACTION: {
                if(Config.FACTION_MAX_ALLIES <= 0) {
                    return PUBLIC;
                } else {
                    return ALLY;
                }
            }
            case PUBLIC: {
                return FACTION;
            }
            default: {
                return PUBLIC;
            }
        }
    }
}
