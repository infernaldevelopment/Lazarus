package me.bitvise.lazarus.map.kits.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.map.kits.kit.KitData;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.utils.StringUtils;
import org.apache.commons.lang.time.DurationFormatUtils;
import org.bukkit.command.CommandSender;

public class KitDelayCommand extends SubCommand {

	KitDelayCommand() {
		super("delay", "lazarus.kits.delay");
	}

	@Override
	public void execute(CommandSender sender, String[] args) {
		if(args.length < 2) {
			sender.sendMessage(Lang.KIT_PREFIX + Lang.KITS_SET_DELAY_USAGE);
			return;
		}
			
		KitData kit = Lazarus.getInstance().getKitsManager().getKit(args[0]);
			
		if(kit == null) {
			sender.sendMessage(Lang.KIT_PREFIX + Lang.KITS_EXCEPTION_DOESNT_EXISTS.replace("<kit>", args[0]));
			return;
		}

		int delay = StringUtils.parseSeconds(args[1]);

		if(delay == -1) {
			sender.sendMessage(Lang.KIT_PREFIX + Lang.COMMANDS_INVALID_DURATION);
			return;
		}

		kit.setDelay(delay);

		sender.sendMessage(Lang.KIT_PREFIX + Lang.KITS_SET_DELAY_CHANGED.replace("<kit>", args[0])
		.replace("<delay>", DurationFormatUtils.formatDurationWords(delay * 1000, true, true)));
	}
}
