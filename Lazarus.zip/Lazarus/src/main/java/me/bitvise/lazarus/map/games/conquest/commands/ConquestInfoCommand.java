package me.bitvise.lazarus.map.games.conquest.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.map.games.Placeholder;
import me.bitvise.lazarus.utils.provider.Lang;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.map.games.conquest.ConquestData;
import org.bukkit.command.CommandSender;

import java.util.Objects;

public class ConquestInfoCommand extends SubCommand {

    public ConquestInfoCommand() {
        super("info");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        ConquestData conquest = Lazarus.getInstance().getConquestManager().getConquest();

        if(conquest.getCuboids().values().stream().anyMatch(Objects::isNull)) {
            sender.sendMessage(Lang.CONQUEST_PREFIX + Lang.CONQUEST_INFO_NOT_SETUP);
            return;
        }

        Lang.CONQUEST_INFO_MESSAGE.forEach(line -> sender.sendMessage(Placeholder
        .ConquestReplacer.parse(conquest, line)));
    }
}
