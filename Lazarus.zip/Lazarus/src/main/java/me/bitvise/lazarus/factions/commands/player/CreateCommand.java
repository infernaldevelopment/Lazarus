package me.bitvise.lazarus.factions.commands.player;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.StringUtils;

import me.bitvise.lazarus.utils.provider.Config;
import me.bitvise.lazarus.utils.provider.Lang;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class CreateCommand extends SubCommand {

    public CreateCommand() {
        super("create", Collections.singletonList("new"), true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CREATE_USAGE);
            return;
        }

        if(Config.FACTION_NAME_DISALLOWED_NAMES.contains(args[0].toLowerCase())) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_BLOCKED_FACTION_NAME);
            return;
        }

        if(args[0].length() < Config.FACTION_NAME_MINIMUM_LENGTH) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NAME_TOO_SHORT);
            return;
        }

        if(args[0].length() > Config.FACTION_NAME_MAXIMUM_LENGTH) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NAME_TOO_BIG);
            return;
        }

        if(!StringUtils.isAlphaNumeric(args[0])) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NAME_NOT_ALPHANUMERIC);
            return;
        }

        if(FactionsManager.getInstance().getFactionByName(args[0]) != null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FACTION_ALREADY_EXISTS.replace("<name>", args[0]));
            return;
        }

        Player player = (Player) sender;

        if(FactionsManager.getInstance().getPlayerFaction(player) != null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_ALREADY_IN_FACTION_SELF);
            return;
        }

        if(!FactionsManager.getInstance().createPlayerFaction(args[0], player)) return;

        player.sendMessage(Lang.FACTIONS_LEARN_MORE);
        if (!Lazarus.getInstance().getSotwHandler().isActive()) {
            Messages.sendMessage(Lang.FACTIONS_CREATED.replace("<player>", player.getName()).replace("<name>", args[0]).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(player))));
        }
    }
}
