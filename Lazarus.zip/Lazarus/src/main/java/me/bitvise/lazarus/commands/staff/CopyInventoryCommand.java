package me.bitvise.lazarus.commands.staff;

import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class CopyInventoryCommand extends BaseCommand {

    public CopyInventoryCommand() {
        super("copyinv", Collections.singletonList("cpi"), "lazarus.copyinv", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.PREFIX + Lang.COPY_INVENTORY_USAGE);
            return;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if(!this.checkPlayer(sender, target, args[0])) return;

        Player player = (Player) sender;

        player.getInventory().setContents(target.getInventory().getContents());
        player.getInventory().setArmorContents(target.getInventory().getArmorContents());

        sender.sendMessage(Lang.PREFIX + Lang.COPY_INVENTORY_COPIED
            .replace("<player>", target.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target))));
    }
}
