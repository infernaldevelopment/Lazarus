package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class KillCommand extends BaseCommand {

    public KillCommand() {
        super("kill", "lazarus.kill");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.PREFIX + Lang.KILL_USAGE);
            return;
        }

        String prefix;
        if (sender instanceof Player) {
            Player p = (Player) sender;
            prefix = Color.translate(ChatHandler.getInstance().getPrefix(p));
        } else {
            prefix = "&4";
        }

        Player target = Bukkit.getPlayer(args[0]);
        if(!this.checkPlayer(sender, target, args[0])) return;

        target.setHealth(0);

        target.sendMessage(Lang.PREFIX + Lang.KILL_MESSAGE_SELF.replace("<player>", sender.getName()).replace("<prefix>", Color.translate(prefix)));
        sender.sendMessage(Lang.PREFIX + Lang.KILL_MESSAGE_OTHERS.replace("<player>", target.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target))));
    }
}
