package me.bitvise.lazarus.level;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum LevelEnum {

    HORSE("Horse", 100),
    CAT("Cat", 50),
    DOG("Dog", 25),
    NONE("None", 0);

    private final String name;
    private final int number;


}
