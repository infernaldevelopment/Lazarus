package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;

public class TeleportHereCommand extends BaseCommand {

    public TeleportHereCommand() {
        super("teleporthere", Arrays.asList("tphere", "s"), "lazarus.teleporthere", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        if(args.length == 0) {
            player.sendMessage(Lang.PREFIX + Lang.TELEPORT_HERE_USAGE);
            return;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if(!this.checkPlayer(sender, target, args[0])) return;

        if(!target.teleport(player)) return;

        target.sendMessage(Lang.PREFIX + Lang.TELEPORT_MESSAGE.replace("<player>", player.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(player))));
        player.sendMessage(Lang.PREFIX + Lang.TELEPORT_HERE_MESSAGE.replace("<player>", target.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target))));
    }
}
