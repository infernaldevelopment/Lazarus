package me.bitvise.lazarus.profile;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.FileUtils;
import me.bitvise.lazarus.utils.Tasks;
import me.bitvise.lazarus.utils.provider.Config;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent.Result;
import org.bukkit.event.player.PlayerQuitEvent;

import java.io.File;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class ProfileManager implements Listener {

    protected final Map<UUID, Profile> profile;

    public ProfileManager() {
        this.profile = new ConcurrentHashMap<>();

        Bukkit.getOnlinePlayers().forEach(this::loadUserdata);
        Bukkit.getPluginManager().registerEvents(this, Lazarus.getInstance());
    }

    public void disable() {
        this.profile.keySet().forEach(uuid -> this.saveUserdata(uuid, false));
        this.profile.clear();
    }

    private void loadUserdata(Player player) {
        this.loadUserdata(player.getUniqueId(), player.getName());
    }

    protected void loadUserdata(UUID uuid, String name) {
        if(this.profile.containsKey(uuid)) return;

        File file = new File(Config.USERDATA_DIR, uuid + ".json");

        if(!file.exists()) {
            this.profile.put(uuid, new Profile(uuid, name));
            return;
        }

        String content = FileUtils.readWholeFile(file);
        if(content == null) return;

        this.profile.put(uuid, Lazarus.getInstance().getGson().fromJson(content, Profile.class));
    }

    public int getUniquePlayers() {
        return this.profile.size();
    }

    private void saveUserdata(Player player) {
        this.saveUserdata(player.getUniqueId(), true);
    }

    public void saveUserdata(UUID uuid, boolean remove) {
        Profile profile = this.getUserdata(uuid);
        if(profile == null) return;

        File file = FileUtils.getOrCreateFile(Config.USERDATA_DIR, uuid + ".json");

        FileUtils.writeString(file, Lazarus.getInstance().getGson().toJson(profile, Profile.class));
        if(remove) this.profile.remove(uuid);
    }

    public void saveUserdata(Profile profile) {
        if(profile == null) return;

        File file = FileUtils.getOrCreateFile(Config.USERDATA_DIR, profile.getUuid() + ".json");
        FileUtils.writeString(file, Lazarus.getInstance().getGson().toJson(profile, Profile.class));
    }

    public Profile getUserdata(Player player) {
        return this.getUserdata(player.getUniqueId());
    }

    public Profile getUserdata(UUID uuid) {
        return this.profile.get(uuid);
    }

    public Profile getUserdata(OfflinePlayer player) {
        if(this.profile.containsKey(player.getUniqueId())) return this.getUserdata(player.getUniqueId());

        File file = new File(Config.USERDATA_DIR, player.getUniqueId() + ".json");
        if(!file.exists()) return null;

        String content = FileUtils.readWholeFile(file);
        if(content == null) return null;

        Profile profile = Lazarus.getInstance().getGson().fromJson(content, Profile.class);
        this.profile.put(player.getUniqueId(), profile);

        return profile;
    }

    public void deleteAllUserdata() {
        int removed = this.profile.size();

        Config.USERDATA_DIR.delete();
        this.profile.clear();

        Bukkit.getOnlinePlayers().forEach(player -> {
            UUID uuid = player.getUniqueId();
            this.profile.put(uuid, new Profile(uuid, player.getName()));
        });

        Lazarus.getInstance().log("&c&l[-] &eRemoved " + removed + " profiles!");
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onAsyncPlayerPreLogin(AsyncPlayerPreLoginEvent event) {
        this.loadUserdata(event.getUniqueId(), event.getName());

        if(this.getUserdata(event.getUniqueId()) == null) {
            event.disallow(Result.KICK_OTHER, Lang.USERDATA_FAILED_TO_LOAD);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerQuit(PlayerQuitEvent event) {
        Profile data = this.getUserdata(event.getPlayer());
        data.getKitDelays().values().removeIf(delay -> delay != -1 && delay < System.currentTimeMillis());

        Tasks.async(() -> this.saveUserdata(event.getPlayer()));
    }
}
