package me.bitvise.lazarus.commands;

import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;

public class TellLocationCommand extends BaseCommand {

    public TellLocationCommand() {
        super("telllocation", Arrays.asList("tellloc", "tl"), "lazarus.telllocation", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);

        if(faction == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
            return;
        }

        if(args.length > 0 && player.hasPermission("lazarus.telllocation.others")) {
            Player target = Bukkit.getPlayer(args[0]);

            if(!this.checkPlayer(sender, target, args[0])) return;

            PlayerFaction playerFaction = FactionsManager.getInstance().getPlayerFaction(player);
            PlayerFaction targetFaction = FactionsManager.getInstance().getPlayerFaction(target);

            if(playerFaction != targetFaction) {
                player.sendMessage(Lang.FACTIONS_NOT_IN_FACTION_OTHERS.replace("<player>", target.getName()));
                return;
            }

            player.sendMessage(Lang.TELL_LOCATION_MESSAGE
                .replace("<player>", target.getName())
                .replace("<world>", StringUtils.getWorldName(target.getLocation()))
                .replace("<location>", StringUtils.getLocationName(target.getLocation())));

            return;
        }

        faction.sendMessage(Lang.TELL_LOCATION_MESSAGE
            .replace("<player>", player.getName())
            .replace("<world>", StringUtils.getWorldName(player.getLocation()))
            .replace("<location>", StringUtils.getLocationName(player.getLocation())));
    }
}