package me.bitvise.lazarus.abilities.type;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.abilities.AbilityType;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.utils.Tasks;
import me.bitvise.lazarus.utils.creator.ConfigCreator;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.abilities.AbilityItem;
import me.bitvise.lazarus.utils.PlayerUtils;
import org.apache.commons.lang.time.DurationFormatUtils;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.HashSet;
import java.util.Set;

public class WebGunAbility extends AbilityItem implements Listener {

    private final String cooldownName;
    private final String metadataName;

    private int duration;
    private int radius;

    public WebGunAbility(ConfigCreator config) {
        super(AbilityType.WEB_GUN, "WEB_GUN", config);

        this.cooldownName = "PrePearl";
        this.metadataName = "webGun";
        this.removeOneItem = false;

        this.overrideActivationMessage();
    }

    @Override
    protected void loadAdditionalData(ConfigurationSection abilitySection) {
        this.duration = abilitySection.getInt("DURATION");
        this.radius = abilitySection.getInt("RADIUS");
    }

    public void sendActivationMessage(Player player, int radius) {
        this.activationMessage.forEach(line -> player.sendMessage(line
                .replace("<abilityName>", this.displayName)
                .replace("<radius>", String.valueOf(radius))
                .replace("<cooldown>", DurationFormatUtils.formatDurationWords(this.cooldown * 1000, true, true))));
    }

    @Override
    protected boolean onItemClick(Player player, PlayerInteractEvent event) {
        player.setMetadata(this.metadataName, PlayerUtils.TRUE_METADATA_VALUE);
        return true;
    }

    @EventHandler(ignoreCancelled = true)
    public void onProjectileLaunch(ProjectileLaunchEvent event) {
        if(!(event.getEntity().getShooter() instanceof Player)) return;

        Projectile projectile = event.getEntity();

        Player player = (Player) projectile.getShooter();
        if(!player.hasMetadata(this.metadataName)) return;

        player.removeMetadata(this.metadataName, Lazarus.getInstance());
        projectile.setMetadata(this.metadataName, PlayerUtils.TRUE_METADATA_VALUE);
    }

    @EventHandler
    public void onProjectileHit(ProjectileHitEvent event) {
        Projectile projectile = event.getEntity();
        if(!(projectile.getShooter() instanceof Player) || !projectile.hasMetadata(this.metadataName)) return;

        projectile.removeMetadata(this.metadataName, Lazarus.getInstance());

        this.handleCobwebCreation(projectile);
    }

    private void handleCobwebCreation(Projectile projectile) {
        double radius = this.radius / 2.0D;

        int min = (int) Math.floor(radius);
        int max = (int) Math.ceil(radius);

        Set<Location> blocks = new HashSet<>();
        Location land = projectile.getLocation();

        for(int x = land.getBlockX() - min; x < land.getBlockX() + max; x++) {
            for(int z = land.getBlockZ() - min; z < land.getBlockZ() + max; z++) {
                Location location = new Location(land.getWorld(), x, land.getBlockY(), z);
                if(location.getBlock().getType() != Material.AIR) continue;

                location.getBlock().setType(Material.WEB);
                blocks.add(location);
            }
        }

        Player shooter = (Player) projectile.getShooter();
        String message = Lang.ABILITIES_PREFIX + Lang.ABILITIES_WEB_GUN_COBWEB_REMOVE;

        TimerManager.getInstance().getCooldownTimer().activate(shooter, this.cooldownName, this.duration,
            message, () -> Tasks.sync(() -> blocks.forEach(location -> location.getBlock().setType(Material.AIR))));

        this.sendActivationMessage(shooter, this.radius);
    }
}
