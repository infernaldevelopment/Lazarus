package me.bitvise.lazarus.handlers.kitmap;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.claim.ClaimManager;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.timer.scoreboard.TeleportTimer;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.handlers.manager.Handler;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World.Environment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.*;
import org.bukkit.scheduler.BukkitRunnable;

public class KitmapHandler extends Handler implements Listener {

    private ItemClearTask itemClearTask;

    public KitmapHandler() {
        if(Config.KITMAP_CLEAR_ITEMS_ENABLED) {
            this.itemClearTask = new ItemClearTask();
        }

        TimerManager.getInstance().getPvpProtTimer().clearPvpProtections();
    }

    @Override
    public void disable() {
        if(this.itemClearTask != null) this.itemClearTask.cancel();
    }

    private void checkPlayerMove(Player player, Location from, Location to) {
        if(from.getBlockX() == to.getBlockX() && from.getBlockZ() == to.getBlockZ()) return;

        TeleportTimer timer = TimerManager.getInstance().getTeleportTimer();

        if(timer.isActive(player)) {
            timer.cancel(player);
            player.sendMessage(Lang.PREFIX + Lang.SPAWN_TELEPORT_CANCELLED_MOVED);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlayerDropItem(PlayerDropItemEvent event) {
        if(!Config.KITMAP_DISABLE_ITEM_DROP_IN_SAFEZONE) return;

        if(ClaimManager.getInstance().getFactionAt(event.getPlayer()).isSafezone()) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(Lang.FACTION_PREFIX + Lang.KITMAP_DENY_ITEM_DROP);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlayerMove(PlayerMoveEvent event) {
        this.checkPlayerMove(event.getPlayer(), event.getFrom(), event.getTo());
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlayerTeleport(PlayerTeleportEvent event) {
        this.checkPlayerMove(event.getPlayer(), event.getFrom(), event.getTo());
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityDamage(EntityDamageEvent event) {
        if(!(event.getEntity() instanceof Player)) return;

        Player player = (Player) event.getEntity();
        TeleportTimer timer = TimerManager.getInstance().getTeleportTimer();

        if(timer.isActive(player)) {
            timer.cancel(player);
            player.sendMessage(Lang.PREFIX + Lang.SPAWN_TELEPORT_CANCELLED_DAMAGE);
        }
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        if(event.getEntity().getKiller() == null || !Config.KITMAP_KILL_REWARD_ENABLED) return;

        Config.KITMAP_KILL_REWARD.forEach(command -> Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
            command.replace("<player>", event.getEntity().getKiller().getName())));
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if(player.hasPlayedBefore()) return;

        Location spawn = Config.WORLD_SPAWNS.get(Environment.NORMAL);
        player.teleport(spawn == null ? player.getWorld().getSpawnLocation() : spawn);
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        TimerManager.getInstance().getTeleportTimer().cancel(event.getPlayer());
    }

    private static class ItemClearTask extends BukkitRunnable {

        ItemClearTask() {
            this.runTaskTimerAsynchronously(Lazarus.getInstance(), 0L, Config.KITMAP_CLEAR_ITEMS_INTERVAL * 20L);
        }

        @Override
        public void run() {
            Bukkit.getWorlds().forEach(world -> world.getEntities().stream().filter(entity -> entity instanceof Item).forEach(Entity::remove));
        }
    }
}
