package me.bitvise.lazarus.classes;

import lombok.AllArgsConstructor;
import lombok.Getter;
import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.classes.manager.PvpClass;
import me.bitvise.lazarus.classes.manager.PvpClassManager;
import me.bitvise.lazarus.classes.utils.PvpClassUtils;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Statistic;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.potion.PotionEffect;

import java.util.*;
import java.util.stream.Collectors;

public class Miner extends PvpClass {

    private final Map<Integer, DiamondData> diamondData;

    public Miner(PvpClassManager manager) {
        super(manager, "Miner",
            Material.IRON_HELMET,
            Material.IRON_CHESTPLATE,
            Material.IRON_LEGGINGS,
            Material.IRON_BOOTS
        );

        this.diamondData = new HashMap<>();
        this.loadDiamondData();
    }

    @Override
    public String getDisplayName() {
        return Config.KITMAP_MODE_ENABLED ? "Builder" : "Miner";
    }

    private void loadDiamondData() {
        ConfigurationSection section = Lazarus.getInstance().getClassesFile()
        .getConfigurationSection("MINER_CLASS.POTION_EFFECT_REWARDS");

        section.getKeys(false).forEach(diamondAmount -> {
            int diamonds = Integer.parseInt(diamondAmount);
            String name = section.getString(diamondAmount + ".NAME");
            List<PotionEffect> effects = PvpClassUtils.loadPassiveEffects(this, "POTION_EFFECT_REWARDS." + diamondAmount + ".EFFECTS");

            this.diamondData.put(diamonds, new DiamondData(name, diamonds, effects));
        });
    }

    public Collection<DiamondData> getDiamondData(int diamondAmount) {
        return this.diamondData.values().stream().filter(data -> data.getDiamonds() <= diamondAmount).collect(Collectors.toList());
    }

    public void sendEffectInfo(CommandSender sender) {
        sender.sendMessage(Lang.MINER_EFFECT_HEADER);
        sender.sendMessage(Lang.MINER_EFFECT_TITLE);

        this.diamondData.values().stream().sorted(Comparator.comparingInt(DiamondData::getDiamonds)).forEach(data -> {
            StringJoiner joiner = new StringJoiner(", ");
            data.getEffects().forEach(effect -> joiner.add(StringUtils.getPotionEffectName(effect)));

            Lang.MINER_EFFECT_FORMAT.forEach(line -> sender.sendMessage(line
            .replace("<name>", data.getName())
            .replace("<diamonds>", String.valueOf(data.getDiamonds()))
            .replace("<effects>", joiner.toString())));
        });

        sender.sendMessage(Lang.MINER_EFFECT_FOOTER);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        if(block.getType() != Material.DIAMOND_ORE || event.getPlayer().getGameMode() == GameMode.CREATIVE) return;

        Player player = event.getPlayer();
        int diamonds = player.getStatistic(Statistic.MINE_BLOCK, Material.DIAMOND_ORE) + 1;

        DiamondData diamondData = this.diamondData.get(diamonds);
        if(diamondData == null) return;

        diamondData.getEffects().forEach(effect -> player.addPotionEffect(effect, true));
        String prefix = Color.translate(ChatHandler.getInstance().getPrefix(player));

        Messages.sendMessage(Lang.MINER_EFFECT_REWARD.replace("<player>", player.getName()).replace("<name>", diamondData.getName()).replace("<prefix>", prefix));
    }

    @Getter
    @AllArgsConstructor
    public static class DiamondData {

        private final String name;
        private final int diamonds;
        private final List<PotionEffect> effects;
    }
}
