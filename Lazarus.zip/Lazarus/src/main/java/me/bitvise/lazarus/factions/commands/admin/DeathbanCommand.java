package me.bitvise.lazarus.factions.commands.admin;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.Faction;
import me.bitvise.lazarus.factions.type.SystemFaction;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.factions.FactionsManager;
import org.bukkit.command.CommandSender;

public class DeathbanCommand extends SubCommand {

    public DeathbanCommand() {
        super("deathban", "lazarus.factions.deathban");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_DEATHBAN_USAGE);
            return;
        }

        Faction faction = FactionsManager.getInstance().getFactionByName(args[0]);

        if(faction == null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FACTION_DOESNT_EXIST.replace("<argument>", args[0]));
            return;
        }

        if(!(faction instanceof SystemFaction)) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_DEATHBAN_NOT_SYSTEM_FACTION);
            return;
        }

        faction.setDeathban(!faction.isDeathban());

        sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_DEATHBAN_CHANGED
            .replace("<faction>", faction.getDisplayName(sender))
            .replace("<deathban>", faction.getDeathbanString()));
    }
}
