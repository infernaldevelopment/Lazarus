package me.bitvise.lazarus.factions.type;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import me.bitvise.lazarus.factions.Faction;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.StringJoiner;

@Getter
@Setter
@NoArgsConstructor
public class SystemFaction extends Faction {

    private String color;
    private boolean safezone;
    private boolean enderpearls;

    public SystemFaction(String name) {
        super(name);

        this.enderpearls = true;
        this.setColor(Color.translate("&b"));
    }

    public String getColor() {
        return this.color;
    }

    public void setColor(String value) {
        this.color = value;
    }

    @Override
    public String getName(CommandSender sender) {
        return this.getColor() + super.getName();
    }

    @Override
    public boolean isSafezone() {
        return this.safezone;
    }

    @Override
    public boolean shouldCancelPvpTimerEntrance(Player player) {
        return !this.isSafezone();
    }

    @Override
    public void showInformation(CommandSender sender) {
        StringJoiner claimInfo = new StringJoiner("\n");

        this.getClaims().forEach(claim -> {
            String locationString = StringUtils.getLocationNameWithWorldWithoutY(claim.getCenter());
            claimInfo.add(Lang.FACTIONS_SYSTEM_CLAIM_FORMAT.replace("<claimLocation>", locationString));
        });

        String claimInfoString = claimInfo.length() != 0
            ? claimInfo.toString()
            : Lang.FACTIONS_SYSTEM_CLAIM_FORMAT.replace("<claimLocation>", "None");

        Lang.FACTIONS_SYSTEM_FACTION_SHOW.forEach(line -> sender.sendMessage(line
            .replace("<factionName>", this.getName(sender))
            .replace("<claims>", claimInfoString)));
    }
}
