package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;

public class MessageCommand extends BaseCommand {

    public MessageCommand() {
        super("message", Arrays.asList("msg", "m", "tell"), true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length <= 1) {
            sender.sendMessage(Lang.PREFIX + Lang.MESSAGE_USAGE);
            return;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if(!this.checkPlayer(sender, target, args[0])) return;

        Player player = (Player) sender;

        if(!player.hasPermission("lazarus.staff") && Lazarus.getInstance().getVanishManager().isVanished(target)) {
            player.sendMessage(Lang.PREFIX + Lang.COMMANDS_PLAYER_NOT_ONLINE.replace("<player>", target.getName()));
            return;
        }

        Lazarus.getInstance().getMessagingHandler().sendMessage(player, target, StringUtils.joinArray(args, " ", 2));
    }
}
