package me.bitvise.lazarus.map.games.schedule.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.map.games.schedule.ScheduleData;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.SubCommand;
import org.bukkit.command.CommandSender;

import java.util.Collections;

public class ScheduleDeleteCommand extends SubCommand {

    ScheduleDeleteCommand() {
        super("delete", Collections.singletonList("remove"), "lazarus.schedule.delete");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.SCHEDULE_PREFIX + Lang.SCHEDULE_DELETE_USAGE);
            return;
        }

        if(!this.checkNumber(sender, args[0])) return;

        ScheduleData schedule = Lazarus.getInstance().getScheduleManager().getScheduleById(Integer.parseInt(args[0]));

        if(schedule == null) {
            sender.sendMessage(Lang.SCHEDULE_PREFIX + Lang.SCHEDULE_DELETE_DOESNT_EXIST.replace("<id>", args[0]));
            return;
        }

        Lazarus.getInstance().getScheduleManager().removeSchedule(schedule, true);

        sender.sendMessage(Lang.SCHEDULE_PREFIX + Lang.SCHEDULE_DELETE_DELETED
        .replace("<id>", String.valueOf(schedule.getId())));
    }
}
