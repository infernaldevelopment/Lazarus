package me.bitvise.lazarus.abilities.type;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.abilities.AbilityItem;
import me.bitvise.lazarus.abilities.AbilityType;
import me.bitvise.lazarus.claim.ClaimManager;
import me.bitvise.lazarus.factions.Faction;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.utils.creator.ConfigCreator;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.utils.PlayerUtils;
import org.apache.commons.lang.time.DurationFormatUtils;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerInteractEvent;

public class SwitcherAbility extends AbilityItem implements Listener {

    private int maxDistance;
    private boolean switchWithTeammates;
    private boolean switchWithAllies;

    private final String metadataName;

    public SwitcherAbility(ConfigCreator config) {
        super(AbilityType.SWITCHER, "SWITCHER", config);

        this.metadataName = "switcher";
        this.removeOneItem = false;

        this.overrideActivationMessage();
    }

    @Override
    protected void loadAdditionalData(ConfigurationSection abilitySection) {
        this.maxDistance = abilitySection.getInt("MAX_DISTANCE");
        this.switchWithTeammates = abilitySection.getBoolean("SWITCH_WITH_TEAMMATES");
        this.switchWithAllies = abilitySection.getBoolean("SWITCH_WITH_ALLIES");
    }

    public void sendActivationMessage(Player player, int distance) {
        this.activationMessage.forEach(line -> player.sendMessage(line
            .replace("<abilityName>", this.displayName)
            .replace("<maxDistance>", String.valueOf(distance))
            .replace("<cooldown>", DurationFormatUtils.formatDurationWords(this.cooldown * 1000, true, true))));
    }

    @Override
    protected boolean onItemClick(Player player, PlayerInteractEvent event) {
        player.setMetadata(this.metadataName, PlayerUtils.TRUE_METADATA_VALUE);
        this.sendActivationMessage(player, this.maxDistance);
        return true;
    }

    @EventHandler(ignoreCancelled = true)
    public void onProjectileLaunch(ProjectileLaunchEvent event) {
        if(!(event.getEntity().getShooter() instanceof Player)) return;

        Projectile projectile = event.getEntity();

        Player player = (Player) projectile.getShooter();
        if(!player.hasMetadata(this.metadataName)) return;

        player.removeMetadata(this.metadataName, Lazarus.getInstance());
        projectile.setMetadata(this.metadataName, PlayerUtils.TRUE_METADATA_VALUE);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if(!(event.getEntity() instanceof Player) || !(event.getDamager() instanceof Projectile)) return;

        Projectile projectile = (Projectile) event.getDamager();
        if(!projectile.hasMetadata(this.metadataName)) return;

        projectile.removeMetadata(this.metadataName, Lazarus.getInstance());

        event.setCancelled(true);

        Player target = (Player) event.getEntity();
        Player shooter = (Player) projectile.getShooter();

        if(this.isSwitchAllowed(shooter, target)) {
            this.switchPositions(shooter, target);
            target.damage(0, shooter);
        }
    }

    private void switchPositions(Player shooter, Player target) {
        Location shooterLocation = shooter.getLocation();

        //shooter.teleport(target.getLocation());
        target.teleport(shooterLocation);
    }

    private boolean isSwitchAllowed(Player shooter, Player target) {
        if(shooter.getLocation().distance(target.getLocation()) > this.maxDistance) {
            shooter.sendMessage(Lang.ABILITIES_PREFIX + Lang.ABILITIES_SWITCHER_SWITCH_DENIED_DISTANCE_TOO_FAR);
            return false;
        }

        Faction factionAtShooter = ClaimManager.getInstance().getFactionAt(shooter);

        if(factionAtShooter.isSafezone()) {
            this.handleAbilityRefund(shooter, Lang.ABILITIES_PREFIX + Lang.ABILITIES_SWITCHER_SWITCH_DENIED_SAFEZONE);
            return false;
        }

        Faction factionAtPlayer = ClaimManager.getInstance().getFactionAt(target);

        if(factionAtPlayer.isSafezone()) {
            this.handleAbilityRefund(shooter, Lang.ABILITIES_PREFIX + Lang.ABILITIES_SWITCHER_SWITCH_DENIED_SAFEZONE_TARGET);
            return false;
        }

        if(TimerManager.getInstance().getPvpProtTimer().isActive(shooter)) {
            this.handleAbilityRefund(shooter, Lang.ABILITIES_PREFIX + Lang.ABILITIES_SWITCHER_SWITCH_DENIED_PVP_TIMER);
            return false;
        }

        if(TimerManager.getInstance().getPvpProtTimer().isActive(target)) {
            this.handleAbilityRefund(shooter, Lang.ABILITIES_PREFIX + Lang.ABILITIES_SWITCHER_SWITCH_DENIED_PVP_TIMER_TARGET);
            return false;
        }

        if(Lazarus.getInstance().getSotwHandler().isUnderSotwProtection(shooter)) {
            this.handleAbilityRefund(shooter, Lang.ABILITIES_PREFIX + Lang.ABILITIES_SWITCHER_SWITCH_DENIED_SOTW);
            return false;
        }

        if(Lazarus.getInstance().getSotwHandler().isUnderSotwProtection(target)) {
            this.handleAbilityRefund(shooter, Lang.ABILITIES_PREFIX + Lang.ABILITIES_SWITCHER_SWITCH_DENIED_SOTW_TARGET);
            return false;
        }

        PlayerFaction damagerFaction = FactionsManager.getInstance().getPlayerFaction(shooter);

        if(damagerFaction != null) {
            PlayerFaction targetFaction = FactionsManager.getInstance().getPlayerFaction(target);

            if(!this.switchWithTeammates && damagerFaction == targetFaction) {
                shooter.sendMessage(Lang.ABILITIES_PREFIX + Lang.ABILITIES_SWITCHER_SWITCH_DENIED_TEAMMATES);
                return false;
            }

            if(!this.switchWithAllies && damagerFaction.isAlly(targetFaction)) {
                shooter.sendMessage(Lang.ABILITIES_PREFIX + Lang.ABILITIES_SWITCHER_SWITCH_DENIED_ALLIES);
                return false;
            }
        }

        return true;
    }
}
