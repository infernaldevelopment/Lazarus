package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.apache.commons.lang.time.DurationFormatUtils;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SeenCommand extends BaseCommand {

    public SeenCommand() {
        super("seen", "lazarus.seen");

        this.setExecuteAsync(true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.PREFIX + Lang.SEEN_USAGE);
            return;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);

        if(target.isOnline()) {
            sender.sendMessage(Lang.PREFIX + Lang.SEEN_ONLINE.replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix((Player) target))).replace("<player>", target.getName()).replace("<time>",
            DurationFormatUtils.formatDurationWords(System.currentTimeMillis() - target.getLastPlayed(), true, true)));
            return;
        }

        if(!target.hasPlayedBefore()) {
            sender.sendMessage(Lang.PREFIX + Lang.COMMANDS_PLAYER_NOT_FOUND.replace("<player>", args[0]));
            return;
        }

        sender.sendMessage(Lang.PREFIX + Lang.SEEN_MESSAGE.replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix((Player) target))).replace("<player>", target.getName()).replace("<time>",
        DurationFormatUtils.formatDurationWords(System.currentTimeMillis() - target.getLastPlayed(), true, true)));
    }
}
