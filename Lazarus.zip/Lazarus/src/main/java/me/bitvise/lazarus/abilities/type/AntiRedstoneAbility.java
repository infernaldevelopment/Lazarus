package me.bitvise.lazarus.abilities.type;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;
import me.bitvise.lazarus.abilities.AbilityItem;
import me.bitvise.lazarus.abilities.AbilityType;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.timer.cooldown.CooldownTimer;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.creator.ConfigCreator;
import me.bitvise.lazarus.utils.provider.Lang;
import org.apache.commons.lang.time.DurationFormatUtils;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.EnumSet;
import java.util.Set;
import java.util.UUID;

public class AntiRedstoneAbility extends AbilityItem implements Listener {

    private int duration;
    private int hits;
    private final String cooldownName;

    private final Set<Material> clickables;
    private final Set<Material> physical;

    private final Table<UUID, UUID, Integer> playerHits;

    public AntiRedstoneAbility(ConfigCreator config) {
        super(AbilityType.ANTI_REDSTONE, "ANTI_REDSTONE", config);

        this.cooldownName = "AntiRedstone";

        this.clickables = EnumSet.of(Material.LEVER, Material.STONE_BUTTON, Material.WOOD_BUTTON);
        this.physical = EnumSet.of(Material.GOLD_PLATE, Material.IRON_PLATE, Material.STONE_PLATE, Material.WOOD_PLATE);
        this.playerHits = HashBasedTable.create();

        this.overrideActivationMessage();
    }

    @Override
    protected void disable() {
        this.clickables.clear();
        this.physical.clear();

        this.playerHits.clear();
    }

    @Override
    protected void loadAdditionalData(ConfigurationSection abilitySection) {
        this.duration = abilitySection.getInt("DURATION");
        this.hits = abilitySection.getInt("HITS") - 1;
    }

    public void sendActivationMessage(Player player, Player target) {
        this.activationMessage.forEach(line -> player.sendMessage(line
            .replace("<abilityName>", this.displayName)
            .replace("<player>", target.getName())
            .replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target)))
            .replace("<duration>", DurationFormatUtils.formatDurationWords(this.duration * 1000, true, true))
            .replace("<cooldown>", DurationFormatUtils.formatDurationWords(this.cooldown * 1000, true, true))));
    }

    @Override
    protected boolean onPlayerItemHit(Player damager, Player target, EntityDamageByEntityEvent event) {
        UUID damagerUUID = damager.getUniqueId();
        UUID targetUUID = target.getUniqueId();

        if(this.playerHits.contains(damagerUUID, targetUUID)) {
            int hitsNeeded = this.playerHits.get(damagerUUID, targetUUID) - 1;

            if(hitsNeeded == 0) {
                this.activateAbilityOnTarget(damager, target);
                this.playerHits.remove(damagerUUID, targetUUID);
                return true;
            }

            this.playerHits.put(damagerUUID, targetUUID, hitsNeeded);
            return false;
        }

        this.playerHits.put(damagerUUID, targetUUID, this.hits);
        return false;
    }

    private void activateAbilityOnTarget(Player damager, Player target) {
        TimerManager.getInstance().getCooldownTimer().activate(target, this.cooldownName, this.duration,
            Lang.ABILITIES_PREFIX + Lang.ABILITIES_ANTI_REDSTONE_TARGET_EXPIRED);

        target.sendMessage(Lang.ABILITIES_PREFIX + Lang.ABILITIES_ANTI_REDSTONE_TARGET_ACTIVATED
            .replace("<player>", damager.getName())
            .replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(damager)))
            .replace("<abilityName>", this.displayName)
            .replace("<duration>", DurationFormatUtils.formatDurationWords(this.duration * 1000, true, true)));

        this.sendActivationMessage(damager, target);
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if(event.useInteractedBlock() == Event.Result.DENY || !event.hasBlock()) return;

        Player player = event.getPlayer();

        CooldownTimer cooldownTimer = TimerManager.getInstance().getCooldownTimer();
        if(!cooldownTimer.isActive(player, this.cooldownName)) return;

        Block block = event.getClickedBlock();

        if(event.getAction() == Action.RIGHT_CLICK_BLOCK && this.clickables.contains(block.getType())) {
            player.sendMessage(Lang.ABILITIES_PREFIX + Lang.ABILITIES_ANTI_REDSTONE_CANNOT_USE
                .replace("<time>", cooldownTimer.getDynamicTimeLeft(player, this.cooldownName)));

            event.setCancelled(true);
            return;
        }

        if(event.getAction() == Action.PHYSICAL && this.physical.contains(block.getType())) {
            this.sendDelayedMessage(player, Lang.ABILITIES_PREFIX + Lang.ABILITIES_ANTI_REDSTONE_CANNOT_USE
                .replace("<time>", cooldownTimer.getDynamicTimeLeft(player, this.cooldownName)));

            event.setCancelled(true);
        }
    }
}
