package me.bitvise.lazarus.factions.type;

import me.bitvise.lazarus.utils.Color;

public class ConquestFaction extends SystemFaction {

    public ConquestFaction() {
        super("Conquest");

        this.setColor(Color.translate("&b"));
    }
}
