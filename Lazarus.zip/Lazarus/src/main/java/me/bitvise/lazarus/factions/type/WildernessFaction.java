package me.bitvise.lazarus.factions.type;

import me.bitvise.lazarus.factions.Faction;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.entity.Player;

public class WildernessFaction extends Faction {

    public WildernessFaction() {
        super(Config.WILDERNESS_NAME);
    }

    @Override
    public boolean shouldCancelPvpTimerEntrance(Player player) {
        return false;
    }
}
