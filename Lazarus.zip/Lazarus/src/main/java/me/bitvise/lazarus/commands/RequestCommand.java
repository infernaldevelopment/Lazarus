package me.bitvise.lazarus.commands;

import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.timer.cooldown.CooldownTimer;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class RequestCommand extends BaseCommand {

    public RequestCommand() {
        super("request", Collections.singletonList("helpop"), "lazarus.request", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.PREFIX + Lang.REQUEST_USAGE);
            return;
        }

        Player player = (Player) sender;

        CooldownTimer timer = TimerManager.getInstance().getCooldownTimer();

        if(timer.isActive(player, "REQUEST")) {
            player.sendMessage(Lang.PREFIX + Lang.REQUEST_COOLDOWN
            .replace("<seconds>", timer.getTimeLeft(player, "REQUEST")));
            return;
        }

        String message = StringUtils.joinArray(args, " ", 1);
        String rankPrefix = Color.translate(ChatHandler.getInstance().getPrefix(player));

        Lang.REQUEST_FORMAT.forEach(line -> {

            line = line.replace("<prefix>", rankPrefix);
            line = line.replace("<player>", player.getName());
            line = line.replace("<message>", message);

            Messages.sendMessage(Color.translate(line), "lazarus.request.receive");
        });

        player.sendMessage(Lang.PREFIX + Lang.REQUEST_REQUESTED);

        timer.activate(player, "REQUEST", Config.REQUEST_COOLDOWN,
        Lang.PREFIX + Lang.REQUEST_COOLDOWN_EXPIRED);
    }
}
