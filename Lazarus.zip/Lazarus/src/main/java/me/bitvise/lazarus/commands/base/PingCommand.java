package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.nms.NmsUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PingCommand extends BaseCommand {

    public PingCommand() {
        super("ping", "lazarus.ping");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            if(!this.checkConsoleSender(sender)) return;

            Player player = (Player) sender;

            player.sendMessage(Lang.PREFIX + Lang.PING_MESSAGE_SELF.replace("<ping>",
            String.valueOf(NmsUtils.getInstance().getPing(player))));
            return;
        }

        if(!this.checkPermission(sender, "lazarus.ping.others")) return;

        Player target = Bukkit.getPlayer(args[0]);
        if(!this.checkPlayer(sender, target, args[0])) return;

        sender.sendMessage(Lang.PREFIX + Lang.PING_MESSAGE_OTHERS.replace("<player>", target.getName())
        .replace("<ping>", String.valueOf(NmsUtils.getInstance().getPing(target)).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target)))));
    }
}
