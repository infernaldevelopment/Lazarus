package me.bitvise.lazarus.handlers.manager;

public abstract class Handler {

    protected Handler() { }

    public void disable() { }
}
