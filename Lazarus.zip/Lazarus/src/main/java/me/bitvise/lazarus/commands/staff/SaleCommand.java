package me.bitvise.lazarus.commands.staff;

import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.timer.type.SystemTimer;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SaleCommand extends BaseCommand {

    public SaleCommand() {
        super("sale", "lazarus.sale");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length < 2) {
            Lang.SALE_USAGE.forEach(sender::sendMessage);
            return;
        }

        if(args.length == 2 && args[0].equalsIgnoreCase("stop")) {
            switch(args[1].toUpperCase()) {
                case "STORE": {
                    this.stopSaleTimer(sender, "Store");
                    return;
                }
                case "KEY": {
                    this.stopSaleTimer(sender, "Key");
                    return;
                }
                default: {
                    Lang.SALE_USAGE.forEach(sender::sendMessage);
                    return;
                }
            }
        }

        if(args.length >= 3 && args[0].equalsIgnoreCase("start")) {
            switch(args[1].toUpperCase()) {
                case "STORE": {
                    this.startSaleTime(sender, "Store", args[2]);
                    return;
                }
                case "KEY": {
                    this.startSaleTime(sender, "Key", args[2]);
                    return;
                }
                default: Lang.SALE_USAGE.forEach(sender::sendMessage);
            }
        }
    }

    private void startSaleTime(CommandSender sender, String name, String time) {
        SystemTimer timer = name.equalsIgnoreCase("Store") ? TimerManager.getInstance()
        .getSaleTimer() : TimerManager.getInstance().getKeySaleTimer();

        if(timer.isActive()) {
            sender.sendMessage(Lang.PREFIX + Lang.SALE_EXCEPTION_ALREADY_RUNNING.replace("<type>", name));
            return;
        }

        int duration = StringUtils.parseSeconds(time);

        if(duration == -1) {
            sender.sendMessage(Lang.PREFIX + Lang.COMMANDS_INVALID_DURATION);
            return;
        }

        String prefix;
        if (sender instanceof Player) {
            Player p = (Player) sender;
            prefix = Color.translate(ChatHandler.getInstance().getPrefix(p));
        } else {
            prefix = Color.translate("&4");
        }

        timer.activate(duration);

        Messages.sendMessage(Lang.SALE_STARTED.replace("<type>", name).replace("<time>", timer.getDynamicTimeLeft()).replace("<prefix>", prefix).replace("<player>", sender.getName()), "lazarus.staff");
    }

    private void stopSaleTimer(CommandSender sender, String name) {
        SystemTimer timer = name.equalsIgnoreCase("STORE") ? TimerManager.getInstance()
        .getSaleTimer() : TimerManager.getInstance().getKeySaleTimer();

        if(!timer.isActive()) {
            sender.sendMessage(Lang.PREFIX + Lang.SALE_EXCEPTION_NOT_RUNNING.replace("<type>", name));
            return;
        }

        timer.cancel();

        String prefix;
        if (sender instanceof Player) {
            Player p = (Player) sender;
            prefix = Color.translate(ChatHandler.getInstance().getPrefix(p));
        } else {
            prefix = Color.translate("&4");
        }

        Messages.sendMessage(Lang.PREFIX + Lang.SALE_STOPPED.replace("<type>", name).replace("<prefix>", prefix).replace("<player>", sender.getName()), "lazarus.staff");
    }
}
