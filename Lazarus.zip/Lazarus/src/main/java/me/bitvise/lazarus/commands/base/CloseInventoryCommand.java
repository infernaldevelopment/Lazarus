package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.utils.StringUtils;
import org.bukkit.Sound;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class CloseInventoryCommand extends BaseCommand {

    public CloseInventoryCommand() {
        super("closeinventory", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        if (player.getInventory() != null) {
            player.closeInventory();

            StringUtils.playSound(player, Sound.CHEST_CLOSE);
        }
    }
}
