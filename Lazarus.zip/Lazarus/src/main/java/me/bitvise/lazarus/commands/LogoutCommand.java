package me.bitvise.lazarus.commands;

import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.timer.scoreboard.LogoutTimer;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class LogoutCommand extends BaseCommand {

	public LogoutCommand() {
		super("logout", "lazarus.logout", true);
	}
	
	@Override
	public void execute(CommandSender sender, String[] args) {
		Player player = (Player) sender;

		LogoutTimer logoutTimer = TimerManager.getInstance().getLogoutTimer();

		if(logoutTimer.isActive(player)) {
			player.sendMessage(Lang.PREFIX + Lang.LOGOUT_ALREADY_RUNNING);
			return;
		}

		logoutTimer.activate(player);

		player.sendMessage(Lang.PREFIX + Lang.LOGOUT_START_MESSAGE
		.replace("<seconds>", String.valueOf(Config.LOGOUT_DELAY)));
	}
}
