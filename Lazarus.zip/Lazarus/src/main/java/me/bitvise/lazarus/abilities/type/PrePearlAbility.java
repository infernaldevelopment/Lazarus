package me.bitvise.lazarus.abilities.type;

import me.bitvise.lazarus.abilities.AbilityItem;
import me.bitvise.lazarus.abilities.AbilityType;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.utils.creator.ConfigCreator;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.utils.provider.Config;
import org.apache.commons.lang.time.DurationFormatUtils;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class PrePearlAbility extends AbilityItem implements Listener {

    private final String cooldownName;

    private int teleportAfter;
    private boolean activateEnderpearlTimer;

    public PrePearlAbility(ConfigCreator config) {
        super(AbilityType.PRE_PEARL, "PRE_PEARL", config);

        this.cooldownName = "PrePearl";

        this.overrideActivationMessage();
    }

    @Override
    protected void loadAdditionalData(ConfigurationSection abilitySection) {
        this.teleportAfter = abilitySection.getInt("TELEPORT_AFTER");
        this.activateEnderpearlTimer = abilitySection.getBoolean("ACTIVATE_ENDERPEARL_TIMER");
    }

    public void sendActivationMessage(Player player, int teleportAfter) {
        this.activationMessage.forEach(line -> player.sendMessage(line
            .replace("<abilityName>", this.displayName)
            .replace("<time>", String.valueOf(teleportAfter))
            .replace("<cooldown>", DurationFormatUtils.formatDurationWords(this.cooldown * 1000, true, true))));
    }

    @Override
    protected boolean onItemClick(Player player, PlayerInteractEvent event) {
        player.getWorld().playEffect(player.getLocation(), Effect.EXPLOSION_HUGE, 1, 32);

        String message = Lang.ABILITIES_PREFIX + Lang.ABILITIES_PRE_PEARL_TELEPORTED;
        Location prePearlLocation = player.getLocation().clone();

        TimerManager.getInstance().getCooldownTimer().activate(player, this.cooldownName,
            this.teleportAfter, message, () -> player.teleport(prePearlLocation));

        if(Config.ENDER_PEARL_COOLDOWN_ENABLED && this.activateEnderpearlTimer) {
            TimerManager.getInstance().getEnderPearlTimer().reactivate(player);
        }

        this.sendActivationMessage(player, this.teleportAfter);

        event.setCancelled(true);
        return true;
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        TimerManager.getInstance().getCooldownTimer().cancel(event.getPlayer(), this.cooldownName);
    }
}
