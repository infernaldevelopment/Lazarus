package me.bitvise.lazarus.commands.staff;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.profile.Profile;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SetReclaimCommand extends BaseCommand {

    public SetReclaimCommand() {
        super("setreclaim", "lazarus.setreclaim");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length < 2) {
            sender.sendMessage(Lang.PREFIX + Lang.SET_RECLAIM_USAGE);
            return;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if(!this.checkPlayer(sender, target, args[0])) return;

        if(!StringUtils.isBoolean(args[1])) {
            sender.sendMessage(Lang.PREFIX + Lang.SET_RECLAIM_INVALID_BOOLEAN);
            return;
        }

        Profile profile = Lazarus.getInstance().getProfileManager().getUserdata(target);
        profile.setReclaimUsed(Boolean.parseBoolean(args[1]));

        sender.sendMessage(Lang.PREFIX + (profile.isReclaimUsed() ? Lang.SET_RECLAIM_SET_USED_MESSAGE
        : Lang.SET_RECLAIM_SET_NOT_USED_MESSAGE).replace("<player>", target.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target))));
    }
}
