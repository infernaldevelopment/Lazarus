package me.bitvise.lazarus.handlers.timer;

import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.timer.scoreboard.AppleTimer;
import me.bitvise.lazarus.timer.scoreboard.GAppleTimer;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.handlers.manager.Handler;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemConsumeEvent;

public class GoldenAppleHandler extends Handler implements Listener {
	
	private void applyNormalCooldown(Player player) {
		if(Config.NORMAL_GOLDEN_APPLE_COOLDOWN == 0) return;
		
		TimerManager.getInstance().getAppleTimer().activate(player);
    	
    	player.sendMessage(Lang.PREFIX + Lang.NORMAL_APPLE_COOLDOWN_STARTED.replace("<time>",
		StringUtils.formatTime(Config.NORMAL_GOLDEN_APPLE_COOLDOWN, StringUtils.FormatType.SECONDS_TO_MINUTES)));
    }

	private void applyEnchantedCooldown(Player player) {
		if(Config.ENCHANTED_GOLDEN_APPLE_COOLDOWN == 0) return;

		TimerManager.getInstance().getGAppleTimer().activate(player);

		player.sendMessage(Lang.PREFIX + Lang.ENCHANTED_APPLE_COOLDOWN_STARTED.replace("<time>",
		StringUtils.formatTime(Config.ENCHANTED_GOLDEN_APPLE_COOLDOWN, StringUtils.FormatType.SECONDS_TO_HOURS)));
	}
	
	@EventHandler(ignoreCancelled = true)
	public void onPlayerItemConsume(PlayerItemConsumeEvent event) {
		if(event.getItem().getType() != Material.GOLDEN_APPLE) return;

		Player player = event.getPlayer();

		switch(event.getItem().getDurability()) {
			case 0: {
				AppleTimer timer = TimerManager.getInstance().getAppleTimer();

				if(timer.isActive(player)) {
					event.setCancelled(true);
					player.sendMessage(Lang.PREFIX + Lang.NORMAL_APPLE_COOLDOWN_DENY.replace("<time>", timer.getDynamicTimeLeft(player)));
					player.updateInventory();
					return;
				}

				this.applyNormalCooldown(player);
				break;
			}
			case 1: {
                GAppleTimer timer = TimerManager.getInstance().getGAppleTimer();

                if(timer.isActive(player)) {
                    event.setCancelled(true);
                    player.sendMessage(Lang.PREFIX + Lang.ENCHANTED_APPLE_COOLDOWN_DENY.replace("<time>", timer.getDynamicTimeLeft(player)));
                    player.updateInventory();
                    return;
                }

                this.applyEnchantedCooldown(player);
			}
		}
	}
}
