package me.bitvise.lazarus.handlers.chat;

import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.handlers.manager.Handler;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

public class BlockedCommandsHandler extends Handler implements Listener {

    @EventHandler(ignoreCancelled = true)
    public void onPlayerCommandPreprocess(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        if(player.hasPermission("lazarus.blockedcommands.bypass")) return;

        String[] args = event.getMessage().split(" ", 2);

        if(args[0].contains(":") && Config.BLOCKED_COMMANDS_DISABLE_COLON) {
            event.setCancelled(true);
            player.sendMessage(Lang.PREFIX + Lang.DISABLED_COMMANDS_COLON_DISABLED);

            Messages.sendMessage(Lang.PREFIX + Lang.DISABLED_COMMANDS_FILTERED.replace("<player>", player.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(player))), "lazarus.staff");
            return;
        }

        if(Config.BLOCKED_COMMANDS.stream().noneMatch(command -> args[0].equalsIgnoreCase(command))) return;

        event.setCancelled(true);
        player.sendMessage(Lang.PREFIX + Lang.DISABLED_COMMANDS_MESSAGE);

        Messages.sendMessage(Lang.PREFIX + Lang.DISABLED_COMMANDS_FILTERED.replace("<player>", player.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(player))), "lazarus.staff");
    }
}
