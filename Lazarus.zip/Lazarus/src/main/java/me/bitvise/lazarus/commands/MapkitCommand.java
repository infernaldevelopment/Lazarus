package me.bitvise.lazarus.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class MapkitCommand extends BaseCommand {

	public MapkitCommand() {
		super("mapkit", "lazarus.mapkit", true);
	}

	@Override
	public void execute(CommandSender sender, String[] args) {
		Player player = (Player) sender;

		if(args.length == 1 && args[0].equalsIgnoreCase("edit")) {
			if(!player.hasPermission("lazarus.mapkit.edit")) {
				player.sendMessage(Lang.PREFIX + Lang.COMMANDS_NO_PERMISSION);
				return;
			}

			Lazarus.getInstance().getMapkitHandler().setEditingMapkit(player);
		}

        player.openInventory(Lazarus.getInstance().getMapkitHandler().getMapkitInv());
	}
}
