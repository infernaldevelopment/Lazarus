package me.bitvise.lazarus.map.games.dragon.nms;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.map.games.dragon.EnderDragon;
import me.bitvise.lazarus.map.games.loot.LootData;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.provider.Config;
import net.minecraft.server.v1_7_R4.DamageSource;
import net.minecraft.server.v1_7_R4.EntityEnderDragon;
import net.minecraft.server.v1_7_R4.EntityPlayer;
import net.minecraft.server.v1_7_R4.GenericAttributes;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_7_R4.CraftWorld;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

public class EnderDragon_1_7 extends EntityEnderDragon implements EnderDragon {

    private final LootData loot;
    private final Map<String, Float> damagers;

    public EnderDragon_1_7(Location loc, LootData loot) {
        super(((CraftWorld) loc.getWorld()).getHandle());

        this.getAttributeInstance(GenericAttributes.maxHealth).setValue(Config.ENDER_DRAGON_HEALTH);
        this.setHealth(Config.ENDER_DRAGON_HEALTH);

        this.persistent = true;
        this.damagers = new HashMap<>();
        this.loot = loot;

        this.setCustomName(Config.ENDER_DRAGON_NAME);
        this.setCustomNameVisible(true);

        this.setPositionRotation(loc.getX(), loc.getY(), loc.getZ(), loc.getYaw(), loc.getPitch());

        int x = loc.getBlockX() >> 4;
        int z = loc.getBlockZ() >> 4;

        if(loc.getWorld().isChunkLoaded(x, z)) {
            ((CraftWorld) loc.getWorld()).getHandle().addEntity(this, SpawnReason.CUSTOM);
            return;
        }

        loc.getWorld().getChunkAtAsync(x, z, (chunk) -> ((CraftWorld) loc.getWorld()).getHandle().addEntity(this, SpawnReason.CUSTOM));
    }

    @Override
    public void disable() {
        this.damagers.clear();
    }

    @Override
    public Entity getDragonBukkitEntity() {
        return this.getBukkitEntity();
    }

    @Override
    public float getDragonHealth() {
        return this.getHealth();
    }

    @Override
    public void setDragonHealth(float value) {
        this.setHealth(value);
    }

    @Override
    public float getDragonMaxHealth() {
        return this.getMaxHealth();
    }

    @Override
    public void setDragonMaxHealth(float value) {
        this.getAttributeInstance(GenericAttributes.maxHealth).setValue(value);
    }

    protected void b(int i, int j) { }

    @Override
    public boolean dealDamage(DamageSource damagesource, float amount) {
        if(damagesource.getEntity() instanceof EntityPlayer) {
            Player player = (Player) damagesource.getEntity().getBukkitEntity();
            this.damagers.put(player.getName(), this.damagers.getOrDefault(player.getName(), 0F) + amount);
        }

        return super.dealDamage(damagesource, amount);
    }

    @Override
    public void die(DamageSource damageSource) {
        super.die(damageSource);

        AtomicReference<String> winner = new AtomicReference<>();
        Map<String, String> topDamagers = new HashMap<>();

        AtomicInteger counter = new AtomicInteger(1);
        Comparator<Map.Entry<String, Float>> comparator = Map.Entry.<String, Float>comparingByValue().reversed();

        this.damagers.entrySet().stream().sorted(comparator).limit(3).forEach(entry -> {
            if(winner.get() == null) {
                winner.set(entry.getKey());
            }

            String damagerFormat = Lang.ENDER_DRAGON_DAMAGER_FORMAT
                .replace("<player>", entry.getKey())
                .replace("<damage>", String.valueOf(entry.getValue().intValue()));

            topDamagers.put("<damager" + counter.getAndIncrement() + ">", damagerFormat);
        });

        Lang.ENDER_DRAGON_ENDED.forEach(line -> Messages.sendMessage(line
            .replace("<killer>", winner.get())
            .replace("<damager1>", topDamagers.getOrDefault("<damager1>", ""))
            .replace("<damager2>", topDamagers.getOrDefault("<damager2>", ""))
            .replace("<damager3>", topDamagers.getOrDefault("<damager3>", ""))));

        if(winner.get() != null) {
            this.loot.handleRewards(Bukkit.getPlayer(winner.get()));
        }

        Lazarus.getInstance().getEnderDragonManager().stopEnderDragon(false);
    }
}
