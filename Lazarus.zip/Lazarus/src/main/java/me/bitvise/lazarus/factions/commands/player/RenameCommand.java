package me.bitvise.lazarus.factions.commands.player;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.enums.Role;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.StringUtils;

import me.bitvise.lazarus.utils.provider.Config;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class RenameCommand extends SubCommand {

    public RenameCommand() {
        super("rename", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_RENAME_USAGE);
            return;
        }

        Player player = (Player) sender;

        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);

        if(faction == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
            return;
        }

        if(faction.getMember(player).getRole() != Role.LEADER) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_MUST_BE_LEADER);
            return;
        }

        if(faction.getName().equalsIgnoreCase(args[0])) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_RENAME_SAME_NAME.replace("<name>", args[0]));
            return;
        }

        if(Config.FACTION_NAME_DISALLOWED_NAMES.contains(args[0].toLowerCase())) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_BLOCKED_FACTION_NAME);
            return;
        }

        if(args[0].length() < Config.FACTION_NAME_MINIMUM_LENGTH) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NAME_TOO_SHORT);
            return;
        }

        if(args[0].length() > Config.FACTION_NAME_MAXIMUM_LENGTH) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NAME_TOO_BIG);
            return;
        }

        if(!StringUtils.isAlphaNumeric(args[0])) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NAME_NOT_ALPHANUMERIC);
            return;
        }

        if(FactionsManager.getInstance().getFactionByName(args[0]) != null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FACTION_ALREADY_EXISTS.replace("<name>", args[0]));
            return;
        }

        String prefix;
        if (sender instanceof Player) {
            Player p = (Player) sender;
            prefix = Color.translate(ChatHandler.getInstance().getPrefix(p));
        } else {
            prefix = Color.translate("&4");
        }

        String oldName = faction.getName();
        if(!faction.setName(sender, args[0], false)) return;

        faction.sendMessage(Lang.NAME_UPDATED.replace("<newName>", args[0]));
        if (!Lazarus.getInstance().getSotwHandler().isActive()) {
            Messages.sendMessage(Lang.FACTIONS_RENAMED.replace("<player>", sender.getName()).replace("<prefix", prefix).replace("<name>", oldName).replace("<newName>", args[0]));
        }
    }
}
