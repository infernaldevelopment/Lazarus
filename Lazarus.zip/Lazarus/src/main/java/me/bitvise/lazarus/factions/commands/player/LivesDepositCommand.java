package me.bitvise.lazarus.factions.commands.player;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.profile.Profile;

import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class LivesDepositCommand extends SubCommand {

    public LivesDepositCommand() {
        super("livesdeposit", Collections.singletonList("depositlives"), true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_LIVES_DEPOSIT_USAGE);
            return;
        }

        Player player = (Player) sender;

        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);

        if(faction == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
            return;
        }

        if(!this.checkNumber(sender, args[0])) return;

        Profile data = Lazarus.getInstance().getProfileManager().getUserdata(player);

        int amount = Math.abs(Integer.parseInt(args[0]));

        if(data.getLives() < amount) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_LIVES_DEPOSIT_NOT_ENOUGH_LIVES
            .replace("<amount>", String.valueOf(data.getLives())));
            return;
        }

        data.setLives(data.getLives() - amount);
        faction.setLives(faction.getLives() + amount);

        faction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_LIVES_DEPOSITED.replace("<player>",
        player.getName()).replace("<amount>", String.valueOf(amount)));
    }
}
