package me.bitvise.lazarus.animation;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.Tasks;
import me.bitvise.lazarus.utils.provider.Config;

import java.util.List;

public class AnimateString {

    public static String footer;
    public static String PLACEHOLDER_DOT;

    public static void setup() {
        if (Lazarus.getInstance().getScoreboardFile().getBoolean("SCOREBOARD.PLACEHOLDER.SERVER_INFO.ENABLED")) {
            List<String> footers = Lazarus.getInstance().getScoreboardFile().getStringList("SCOREBOARD.PLACEHOLDER.SERVER_INFO.MESSAGES");
            final int[] b = {0};
            Tasks.Other.runTimer(() -> {
                if (b[0] == footers.size()) b[0] = 0;
                footer = footers.get(b[0]++);
            }, 0L, (long) (Lazarus.getInstance().getScoreboardFile().getDouble("SCOREBOARD.PLACEHOLDER.SERVER_INFO.INTERVAL")) * 20L);
        }

        if (Config.SCOREBOARD_DOT_PLACEHOLDER_ENABLED) {
            final int[] b = {0};
            Tasks.Other.runTimer(() -> {
                if (b[0] == Config.SCOREBOARD_DOT_PLACEHOLDER_MESSAGES.size()) b[0] = 0;
                PLACEHOLDER_DOT = Config.SCOREBOARD_DOT_PLACEHOLDER_MESSAGES.get(b[0]++);
            }, 0L, (long) (Lazarus.getInstance().getScoreboardFile().getDouble("SCOREBOARD.PLACEHOLDER.DOT.INTERVAL")));
        }


    }

    public static String get() {
        return footer;
    }

    public static String getPlaceholderDot() {
        return PLACEHOLDER_DOT;
    }

}



