package me.bitvise.lazarus.commands.staff;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.profile.Profile;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class LastDeathsCommand extends BaseCommand {

	public LastDeathsCommand() {
		super("lastdeaths", "lazarus.lastdeaths");
	}

	@Override
	public void execute(CommandSender sender, String[] args) {
		if(args.length == 0) {
            sender.sendMessage(Lang.PREFIX + Lang.LAST_DEATHS_USAGE);
            return;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if(!this.checkPlayer(sender, target, args[0])) return;

        Profile data = Lazarus.getInstance().getProfileManager().getUserdata(target);
				
        if(data.getLastDeaths().isEmpty()) {
            sender.sendMessage(Lang.PREFIX + Lang.LAST_DEATHS_NO_DEATHS_YET.replace("<player>", target.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target))));
            return;
        }
				
        sender.sendMessage("");

        sender.sendMessage(Lang.LAST_DEATHS_HEADER_FORMAT.replace("<player>", target.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target))));

        data.getLastDeaths().forEach(death -> sender.sendMessage(Lang.LAST_DEATHS_DEATH_MESSAGE_FORMAT
        .replace("<deathMessage>", Color.translate(death))));

        sender.sendMessage("");
	}
}
