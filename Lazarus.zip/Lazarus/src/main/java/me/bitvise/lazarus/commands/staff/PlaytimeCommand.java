package me.bitvise.lazarus.commands.staff;

import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.utils.Color;
import org.apache.commons.lang.time.DurationFormatUtils;
import org.bukkit.Bukkit;
import org.bukkit.Statistic;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PlaytimeCommand extends BaseCommand {

    public PlaytimeCommand() {
        super("playtime", "lazarus.playtime");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.PREFIX + Lang.PLAYTIME_COMMAND_USAGE);
            return;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if(!this.checkPlayer(sender, target, args[0])) return;

        long playTime = target.getStatistic(Statistic.PLAY_ONE_TICK);

        sender.sendMessage(Lang.PREFIX + Lang.PLAYTIME_COMMAND_MESSAGE
            .replace("<time>", DurationFormatUtils.formatDurationWords(playTime * 50, true, true))
            .replace("<player>", target.getName())
            .replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target))));
    }
}
