package me.bitvise.lazarus.factions.commands.player;

import me.bitvise.lazarus.claim.Claim;
import me.bitvise.lazarus.claim.ClaimManager;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.enums.Role;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.utils.StringUtils;

import me.bitvise.lazarus.utils.provider.Config;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class UnclaimCommand extends SubCommand {

    public UnclaimCommand() {
        super("unclaim", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);

        if(faction == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
            return;
        }

        if(faction.getMember(player).getRole() != Role.LEADER) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NO_PERMISSION.replace("<role>", Role.getName(Role.LEADER)));
            return;
        }

        if(faction.getClaims().size() == 0) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_UNCLAIM_NO_CLAIMS);
            return;
        }

        Claim claim = ClaimManager.getInstance().getClaimAt(player);

        if(claim == null || claim.getOwner() != faction) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_UNCLAIM_NOT_OWNER);
            return;
        }

        if(!Config.FACTION_UNCLAIM_WHILE_FROZEN && faction.isRegenerating()) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CANNOT_UNCLAIM_WHILE_REGENERATING);
            return;
        }

        if(!ClaimManager.getInstance().removeClaim(claim)) return;

        if(faction.getHome() != null && claim.contains(faction.getHome())) {
            faction.setHome(null);
            FactionsManager.getInstance().checkHomeTeleports(faction, Lang.FACTIONS_UNCLAIM_HOME_TELEPORT_CANCELLED);
        }

        faction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_UNCLAIMED.replace("<player>",
        player.getName()).replace("<location>", StringUtils.getLocationNameWithoutY(claim.getCenter())));
    }
}
