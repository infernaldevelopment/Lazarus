package me.bitvise.lazarus.handlers.kitmap;

import me.bitvise.lazarus.handlers.manager.Handler;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.util.Vector;

public class LaunchpadHandler extends Handler implements Listener {

    @EventHandler
    public void onMove(PlayerMoveEvent event)  {
        Player player = event.getPlayer();

        Location from = event.getFrom();
        Location to = event.getTo();

        if (Config.LAUNCHPAD_ENABLED) {

            if (from.getBlockX() == to.getBlockX() && from.getBlockY() == to.getBlockY() && from.getBlockZ() == to.getBlockZ()) {
                return;
            }

            boolean carpet = player.getLocation().add(0, 0, 0).getBlock().getType().equals(Material.valueOf(Config.LAUNCHPAD_MATERIAL_ABOVE));
            boolean sponge = player.getLocation().add(0, -1.0, 0).getBlock().getType().equals(Material.valueOf(Config.LAUNCHPAD_MATERIAL_DOWN));

            if (sponge && carpet) {

                //player.sendMessage(Lang.PREFIX + Lang.LAUNCHPAD_MESSAGE);

                player.setVelocity(player.getLocation().getDirection().multiply(Config.LAUNCHPAD_VELOCITY));
                player.setVelocity(new Vector(player.getVelocity().getX(), 1.7, player.getVelocity().getZ()));

                player.playSound(player.getLocation(), Sound.valueOf(Config.LAUNCHPAD_SOUND), 2, 2);

            }
        }
    }
}
