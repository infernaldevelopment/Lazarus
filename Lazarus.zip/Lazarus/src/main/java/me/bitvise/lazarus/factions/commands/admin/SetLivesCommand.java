package me.bitvise.lazarus.factions.commands.admin;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;

import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SetLivesCommand extends SubCommand {

    public SetLivesCommand() {
        super("setlives", "lazarus.factions.setlives");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length < 2) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_SET_LIVES_USAGE);
            return;
        }

        PlayerFaction faction = FactionsManager.getInstance().searchForFaction(args[0]);

        if(faction == null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FACTION_DOESNT_EXIST.replace("<argument>", args[0]));
            return;
        }

        String prefix;
        if (sender instanceof Player) {
            Player p = (Player) sender;
            prefix = Color.translate(ChatHandler.getInstance().getPrefix(p));
        } else {
            prefix = Color.translate("&4");
        }

        if(!this.checkNumber(sender, args[1])) return;
        int amount = Math.abs(Integer.parseInt(args[1]));

        faction.setLives(amount);

        sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_SET_LIVES_CHANGED_SENDER.replace("<faction>", faction.getName()).replace("<amount>", String.valueOf(amount)));

        faction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_SET_LIVES_CHANGED_FACTION.replace("<prefix>", prefix).replace("<player>", sender.getName()).replace("<amount>", String.valueOf(amount)));
    }
}
