package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.utils.Tasks;
import org.bukkit.command.CommandSender;

public class HidePlayersCommand extends BaseCommand {

    public HidePlayersCommand() {
        super("hideplayers", "lazarus.hideplayers", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (args.length == 0) {
            Tasks.async(() -> Lazarus.getInstance().getSotwHandler().toggleSotwInvisibility(sender, null));
        }
    }
}
