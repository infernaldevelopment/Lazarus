package me.bitvise.lazarus.abilities.type;

import me.bitvise.lazarus.abilities.AbilityItem;
import me.bitvise.lazarus.abilities.AbilityType;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.creator.ConfigCreator;
import org.apache.commons.lang.time.DurationFormatUtils;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class SwitchStickAbility extends AbilityItem {

    private int degrees;

    public SwitchStickAbility(ConfigCreator config) {
        super(AbilityType.SWITCH_STICK, "SWITCH_STICK", config);

        this.overrideActivationMessage();
    }

    @Override
    protected void loadAdditionalData(ConfigurationSection abilitySection) {
        this.degrees = abilitySection.getInt("DEGREES");
    }

    public void sendActivationMessage(Player player, Player target, int amount) {
        this.activationMessage.forEach(line -> player.sendMessage(line
            .replace("<abilityName>", this.displayName)
            .replace("<player>", target.getName())
            .replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target)))
            .replace("<amount>", String.valueOf(amount))
            .replace("<cooldown>", DurationFormatUtils.formatDurationWords(this.cooldown * 1000, true, true))));
    }

    @Override
    protected boolean onPlayerItemHit(Player damager, Player target, EntityDamageByEntityEvent event) {
        Location location = target.getLocation().clone();
        location.setYaw(location.getYaw() + this.degrees);

        target.teleport(location);

        this.sendActivationMessage(damager, target, this.degrees);
        return true;
    }
}
