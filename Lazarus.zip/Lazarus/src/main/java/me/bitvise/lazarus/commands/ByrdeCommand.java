package me.bitvise.lazarus.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.timer.scoreboard.ByrdeTimer;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.command.CommandSender;

public class ByrdeCommand extends BaseCommand {

    public ByrdeCommand() {
        super("byrde");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            (sender.hasPermission("lazarus.byrde")
                    ? Lang.BYRDE_ADMIN_COMMAND_USAGE
                    : Lang.BYRDE_PLAYER_COMMAND_USAGE).forEach(sender::sendMessage);
            return;
        }

        if(args.length == 1) {
            switch(args[0].toLowerCase()) {
                case "start": {
                    if(!checkPermission(sender, "lazarus.byrde")) return;
                    Lazarus.getInstance().getByrdeHandler().startByrdeTimer(sender, Config.BYRDE_DEFAULT_TIME * 60);
                    return;
                }
                case "stop": {
                    if(!checkPermission(sender, "lazarus.byrde")) return;
                    Lazarus.getInstance().getByrdeHandler().stopByrdeTimer(sender);
                    return;
                }
                case "time": {
                    ByrdeTimer byrdeTimer = TimerManager.getInstance().getByrdeTimer();

                    if(!byrdeTimer.isActive()) {
                        sender.sendMessage(Lang.PREFIX + Lang.BYRDE_NOT_RUNNING);
                        return;
                    }

                    sender.sendMessage(Lang.PREFIX + Lang.BYRDE_TIME_STATUS
                            .replace("<time>", byrdeTimer.getDynamicTimeLeft()));
                    return;
                }
                default: {
                    (sender.hasPermission("lazarus.byrde")
                            ? Lang.BYRDE_ADMIN_COMMAND_USAGE
                            : Lang.BYRDE_PLAYER_COMMAND_USAGE).forEach(sender::sendMessage);
                }
            }
        } else {
            if(!checkPermission(sender, "lazarus.byrde")) return;

            if(args[0].equalsIgnoreCase("start")) {
                int time = StringUtils.parseSeconds(args[1]);

                if(time == -1) {
                    sender.sendMessage(Lang.KIT_PREFIX + Lang.COMMANDS_INVALID_DURATION);
                    return;
                }

                Lazarus.getInstance().getByrdeHandler().startByrdeTimer(sender, time);
            } else {
                Lang.BYRDE_ADMIN_COMMAND_USAGE.forEach(sender::sendMessage);
            }
        }
    }
}

