package me.bitvise.lazarus.factions.commands.admin;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.claim.ClaimManager;
import me.bitvise.lazarus.claim.selection.Selection;
import me.bitvise.lazarus.claim.selection.SelectionType;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.Faction;
import me.bitvise.lazarus.factions.type.SystemFaction;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.factions.FactionsManager;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;

public class ClaimForCommand extends SubCommand {

    public ClaimForCommand() {
        super("claimfor", Arrays.asList("opclaim", "opc", "createclaim"),"lazarus.factions.claimfor", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_FOR_USAGE);
            return;
        }

        Faction faction = FactionsManager.getInstance().getAnyFaction(args[0]);

        if(faction == null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FACTION_DOESNT_EXIST.replace("<argument>", args[0]));
            return;
        }

        if(!(faction instanceof SystemFaction)) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_FOR_NOT_SYSTEM_FACTION);
            return;
        }

        Player player = (Player) sender;
        Selection selection = Lazarus.getInstance().getSelectionManager().getSelection(player);

        if(selection == null || selection.getType() != SelectionType.SYSTEM_CLAIM) {
            Lazarus.getInstance().getSelectionManager().toggleSelectionProcess(player, SelectionType.SYSTEM_CLAIM, null);
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_FOR_MAKE_A_SELECTION);
            return;
        }

        if(!selection.areBothPositionsSet()) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_FOR_SET_BOTH_POSITIONS);
            return;
        }

        if(!ClaimManager.getInstance().getClaimsInSelection(selection.getPosOne(), selection.getPosTwo()).isEmpty()) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_FOR_CLAIM_OVERLAPPING);
            return;
        }

        if(!ClaimManager.getInstance().addClaim(selection.toClaim(faction))) return;
        Lazarus.getInstance().getSelectionManager().removeSelectionProcess(player);

        Messages.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_FOR_CLAIM_CLAIMED
            .replace("<player>", player.getName())
            .replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(player)))
            .replace("<faction>", faction.getDisplayName(sender)), "lazarus.staff");
    }

    public static class SetClaimCommand extends BaseCommand {

        public SetClaimCommand() {
            super("setclaim", "lazarus.setclaim", true);
        }

        @Override
        public void execute(CommandSender sender, String[] args) {
            if(args.length == 0) {
                sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_FOR_USAGE);
                return;
            }

            Faction faction = FactionsManager.getInstance().getAnyFaction(args[0]);

            if(faction == null) {
                sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FACTION_DOESNT_EXIST.replace("<argument>", args[0]));
                return;
            }

            if(!(faction instanceof SystemFaction)) {
                sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_FOR_NOT_SYSTEM_FACTION);
                return;
            }

            Player player = (Player) sender;
            Selection selection = Lazarus.getInstance().getSelectionManager().getSelection(player);

            if(selection == null || selection.getType() != SelectionType.SYSTEM_CLAIM) {
                Lazarus.getInstance().getSelectionManager().toggleSelectionProcess(player, SelectionType.SYSTEM_CLAIM, null);
                player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_FOR_MAKE_A_SELECTION);
                return;
            }

            if(!selection.areBothPositionsSet()) {
                player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_FOR_SET_BOTH_POSITIONS);
                return;
            }

            if(!ClaimManager.getInstance().getClaimsInSelection(selection.getPosOne(), selection.getPosTwo()).isEmpty()) {
                player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_FOR_CLAIM_OVERLAPPING);
                return;
            }

            if(!ClaimManager.getInstance().addClaim(selection.toClaim(faction))) return;
            Lazarus.getInstance().getSelectionManager().removeSelectionProcess(player);

            Messages.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CLAIM_FOR_CLAIM_CLAIMED
                    .replace("<player>", player.getName())
                    .replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(player)))
                    .replace("<faction>", faction.getDisplayName(sender)), "lazarus.staff");
        }
    }
}
