package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class FlyCommand extends BaseCommand {

    public FlyCommand() {
        super("fly", "lazarus.fly");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            if(!this.checkConsoleSender(sender)) return;

            Player player = (Player) sender;
            player.setAllowFlight(!player.getAllowFlight());
            player.sendMessage(Lang.PREFIX + (player.getAllowFlight() ? Lang.FLY_SELF_ENABLED : Lang.FLY_SELF_DISABLED));
            return;
        }

        if(!this.checkPermission(sender, "lazarus.fly.others")) return;

        Player target = Bukkit.getPlayer(args[0]);
        if(!this.checkPlayer(sender, target, args[0])) return;

        target.setAllowFlight(!target.getAllowFlight());
        target.sendMessage(Lang.PREFIX + (target.getAllowFlight() ? Lang.FLY_SELF_ENABLED : Lang.FLY_SELF_DISABLED));

        sender.sendMessage(Lang.PREFIX + (target.getAllowFlight() ? Lang.FLY_OTHERS_ENABLED
        : Lang.FLY_OTHERS_DISABLED).replace("<player>", target.getName()).replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target))));
    }
}
