package me.bitvise.lazarus.factions.type;

public enum SystemType {
    DEFAULT, KOTH
}
