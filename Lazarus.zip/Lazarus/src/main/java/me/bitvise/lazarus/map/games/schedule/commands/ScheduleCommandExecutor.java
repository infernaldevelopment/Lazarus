package me.bitvise.lazarus.map.games.schedule.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.commands.manager.SubCommandExecutor;
import me.bitvise.lazarus.utils.Tasks;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;

import java.util.Arrays;

public class ScheduleCommandExecutor extends SubCommandExecutor {

    public ScheduleCommandExecutor() {
        super("schedule", null);

        this.addSubCommand(new ScheduleClearCommand());
        this.addSubCommand(new ScheduleCreateCommand());
        this.addSubCommand(new ScheduleDeleteCommand());
        this.addSubCommand(new ScheduleListCommand());
        this.addSubCommand(new ScheduleNextCommand());
    }

    @Override
    public boolean execute(CommandSender sender, String label, String[] args) {
        if(args.length == 0) {
            if(sender.hasPermission("lazarus.schedule.admin")) {
                Lang.SCHEDULE_COMMAND_USAGE_ADMIN.forEach(sender::sendMessage);
            } else {
                Tasks.async(() -> Lazarus.getInstance().getScheduleManager().listNextSchedules(sender));
            }
            return true;
        }

        SubCommand sub = this.getSubCommand(args[0]);

        if(sub == null) {
            sender.sendMessage(Lang.SCHEDULE_PREFIX + Lang.COMMANDS_COMMAND_NOT_FOUND
            .replace("<command>", args[0]));
            return true;
        }

        if(sub.isForPlayersOnly() && sender instanceof ConsoleCommandSender) {
            sender.sendMessage(Lang.SCHEDULE_PREFIX + Lang.COMMANDS_FOR_PLAYERS_ONLY);
            return true;
        }

        if(sub.getPermission() != null && !sender.hasPermission(sub.getPermission())) {
            sender.sendMessage(Lang.SCHEDULE_PREFIX + Lang.COMMANDS_NO_PERMISSION);
            return true;
        }

        if(sub.isExecuteAsync()) {
            Tasks.async(() -> sub.execute(sender, Arrays.copyOfRange(args, 1, args.length)));
        } else {
            sub.execute(sender, Arrays.copyOfRange(args, 1, args.length));
        }
        return true;
    }
}
