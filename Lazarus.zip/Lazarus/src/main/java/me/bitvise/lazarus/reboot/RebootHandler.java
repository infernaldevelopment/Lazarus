package me.bitvise.lazarus.reboot;

import com.lunarclient.bukkitapi.LunarClientAPI;
import com.lunarclient.bukkitapi.nethandler.client.LCPacketTitle;
import lombok.Getter;
import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.handlers.event.PluginKickEvent;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.Tasks;
import me.bitvise.lazarus.utils.provider.Config;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.handlers.manager.Handler;
import org.apache.commons.lang.time.DurationFormatUtils;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitRunnable;
import org.spigotmc.SpigotConfig;

import java.io.File;
import java.util.concurrent.TimeUnit;

public class RebootHandler extends Handler {

    private RebootTask rebootTask;

    public boolean isRebooting() {
        return this.rebootTask != null;
    }

    public void startReboot(int time) {
        this.rebootTask = new RebootTask(time);

        if (Config.LUNAR_CLIENT_API_ENABLED && Bukkit.getPluginManager().isPluginEnabled("LunarClient-API")) {
            Bukkit.getOnlinePlayers().forEach(online -> {

                LunarClientAPI.getInstance().sendPacket(online, new LCPacketTitle("TITLE", Lang.REBOOT_BROADCAST_TITLE.replace("<placeholder:warning>", StringUtils.WARNING), TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5)));
                LunarClientAPI.getInstance().sendPacket(online, new LCPacketTitle("SUBTITLE", Lang.REBOOT_BROADCAST_SUBTITLE.replace("<left>", DurationFormatUtils.formatDurationWords(time * 1000L, true, true)), TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5), TimeUnit.MILLISECONDS.toSeconds(5)));
            });
        }
    }

    public void cancelReboot() {
        this.rebootTask.cancel();
        this.rebootTask = null;

        Lang.REBOOT_CANCELED.forEach(Messages::sendMessage);
    }

    public String getScoreboardEntry() {
        return StringUtils.formatTime(this.rebootTask.getSeconds(), StringUtils.FormatType.SECONDS_TO_MINUTES);
    }

    private static class RebootTask extends BukkitRunnable {

        @Getter private int seconds;

        RebootTask(int seconds) {
            this.seconds = seconds;
            this.broadcast();

            this.runTaskTimerAsynchronously(Lazarus.getInstance(), 0L, 20L);
        }

        @Override
        public void run() {
            if(--this.seconds <= 0) {
                this.cancel();

                Tasks.sync(() -> {
                    this.kickOnlinePlayers();
                    this.setupRestartScript();
                });

                Tasks.syncLater(() -> Bukkit.getServer().shutdown(), 20L);
                return;
            }

            if(this.seconds <= 10 || this.seconds == 15 || this.seconds == 30 || this.seconds == 45 || this.seconds % 60 == 0) {
                this.broadcast();
            }
        }

        private void broadcast() {
            Lang.REBOOT_BROADCAST.forEach(line -> {
                line = line.replace("<time>", DurationFormatUtils.formatDurationWords(this.seconds * 1000L, true, true));
                line = line.replace("<placeholder:warning>", StringUtils.WARNING);

                Messages.sendMessage(Lang.PREFIX + line);
            });
        }

        private void kickOnlinePlayers() {
            String kickReason = Lang.REBOOT_PLAYER_KICK_MESSAGE;

            Bukkit.getOnlinePlayers().forEach(player -> {
                PluginKickEvent event = new PluginKickEvent(player, PluginKickEvent.KickType.REBOOT, kickReason);

                if(!event.isCancelled()) {
                    player.kickPlayer(kickReason);
                }
            });
        }

        private void setupRestartScript() {
            File restartScript = new File(SpigotConfig.restartScript);

            Thread shutdownHook = new Thread(() -> {
                try {
                    String os = System.getProperty("os.name").toLowerCase();

                    if (os.contains("win")) {
                        Runtime.getRuntime().exec("cmd /c start " + restartScript.getPath());
                    } else {
                        Runtime.getRuntime().exec(new String[] { "sh", restartScript.getPath() });
                    }
                } catch(Exception e) {
                    e.printStackTrace();
                }
            });

            shutdownHook.setDaemon(true);
            Runtime.getRuntime().addShutdownHook(shutdownHook);
        }
    }
}
