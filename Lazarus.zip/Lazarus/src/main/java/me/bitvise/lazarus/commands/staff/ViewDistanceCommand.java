package me.bitvise.lazarus.commands.staff;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.nms.NmsUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class ViewDistanceCommand extends BaseCommand {

    private boolean running;

    public ViewDistanceCommand() {
        super("viewdistance", Collections.singletonList("vd"), "lazarus.viewdistance");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            Lang.VIEW_DISTANCE_USAGE.forEach(line -> sender.sendMessage(line.replace("<chunks>", String.valueOf(Bukkit.getViewDistance()))));
            return;
        }

        if(!StringUtils.isInteger(args[0])) {
            sender.sendMessage(Lang.PREFIX + Lang.COMMANDS_INVALID_NUMBER);
            return;
        }

        if(this.running) {
            sender.sendMessage(Lang.PREFIX + Lang.VIEW_DISTANCE_ALREADY_RUNNING);
            return;
        }

        new ChangeDistanceTask(Math.abs(Integer.parseInt(args[0])), sender);

        Lang.VIEW_DISTANCE_STARTED.forEach(line -> sender.sendMessage(line.replace("<seconds>",
        String.valueOf(Bukkit.getOnlinePlayers().size() / 20))));
    }

    class ChangeDistanceTask extends BukkitRunnable {

        private final List<UUID> players;
        private final int viewDistance;
        private final CommandSender sender;

        private ChangeDistanceTask(int viewDistance, CommandSender sender) {
            this.viewDistance = viewDistance;
            this.sender = sender;

            NmsUtils.getInstance().setViewDistance(viewDistance);
            this.players = Bukkit.getOnlinePlayers().stream().map(Player::getUniqueId).collect(Collectors.toList());

            running = true;

            this.runTaskTimer(Lazarus.getInstance(), 0L, 1L);
        }

        @Override
        public void run() {
            if(this.players.isEmpty()) {
                this.cancel();
                this.sender.sendMessage(Lang.PREFIX + Lang.VIEW_DISTANCE_FINISHED);
                running = false;
                return;
            }

            Player player = Bukkit.getPlayer(players.get(0));
            if(player != null) player.spigot().setViewDistance(this.viewDistance);

            this.players.remove(0);
        }
    }
}
