package me.bitvise.lazarus.factions.commands.admin;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.factions.FactionsManager;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class AddDtrCommand extends SubCommand {

    public AddDtrCommand() {
        super("adddtr", Collections.singletonList("dtradd"), "lazarus.factions.dtr");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length < 2) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_ADD_DTR_USAGE);
            return;
        }

        PlayerFaction faction = FactionsManager.getInstance().searchForFaction(args[0]);

        if(faction == null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FACTION_DOESNT_EXIST.replace("<argument>", args[0]));
            return;
        }

        if(!StringUtils.isDouble(args[1])) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.COMMANDS_INVALID_NUMBER);
            return;
        }

        String prefix;
        if (sender instanceof Player) {
            Player p = (Player) sender;
            prefix = Color.translate(ChatHandler.getInstance().getPrefix(p));
        } else {
            prefix = Color.translate("&4");
        }

        faction.setDtr(faction.getDtr() + Double.parseDouble(args[1]));

        sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_ADD_DTR_CHANGED_SENDER
        .replace("<faction>", faction.getName()).replace("<value>", faction.getDtrString()));

        faction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_ADD_DTR_CHANGED_FACTION
        .replace("<player>", sender.getName()).replace("<dtr>", faction.getDtrString()).replace("<prefix>", prefix));
    }
}
