package me.bitvise.lazarus.classes.manager;

import lombok.Getter;
import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.classes.Miner;
import me.bitvise.lazarus.classes.event.PvpClassEquipEvent;
import me.bitvise.lazarus.classes.event.PvpClassUnequipEvent;
import me.bitvise.lazarus.classes.items.ClickableItem;
import me.bitvise.lazarus.classes.utils.PvpClassUtils;
import me.bitvise.lazarus.timer.TimerManager;
import me.bitvise.lazarus.timer.scoreboard.PvpClassWarmupTimer;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.item.ItemUtils;
import me.bitvise.lazarus.utils.nms.NmsUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Statistic;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;

import java.util.*;

@Getter
public abstract class PvpClass implements Listener {

    private final PvpClassManager manager;

    private final String name;

    private final Material helmet;
    private final Material chestplate;
    private final Material leggings;
    private final Material boots;

    private final Set<UUID> players;
    private final List<PotionEffect> effects;

    private final Map<UUID, Integer> factionLimit;

    protected PvpClass(PvpClassManager manager, String name, Material helmet, Material chestplate, Material leggings, Material boots) {
        this.manager = manager;

        this.name = name;

        this.helmet = helmet;
        this.chestplate = chestplate;
        this.leggings = leggings;
        this.boots = boots;

        this.players = new HashSet<>();
        this.effects = PvpClassUtils.loadPassiveEffects(this, "PASSIVE_EFFECTS");

        this.factionLimit = new HashMap<>();

        Bukkit.getPluginManager().registerEvents(this, Lazarus.getInstance());
    }

    public void disable() {
        this.players.forEach(uuid -> this.deactivateClass(Bukkit.getPlayer(uuid), true));

        this.players.clear();
        this.effects.clear();

        this.factionLimit.clear();
    }

    public String getDisplayName() {
        return this.name;
    }

    public void activateClass(UUID uuid) {
        Player player = Bukkit.getPlayer(uuid);
        if(player == null) return;

        PvpClassEquipEvent event = new PvpClassEquipEvent(uuid, this);
        if(event.isCancelled()) return;

        this.players.add(uuid);

        this.effects.forEach(effect -> NmsUtils.getInstance().addPotionEffect(player, effect));

        player.sendMessage(Lang.PVP_CLASSES_ACTIVATED.replace("<name>", this.getDisplayName()));

        if(this instanceof Miner) {
            Miner miner = (Miner) this;
            int diamondsMined = player.getStatistic(Statistic.MINE_BLOCK, Material.DIAMOND_ORE);

            miner.getDiamondData(diamondsMined).forEach(data -> data.getEffects()
                .forEach(effect -> NmsUtils.getInstance().addPotionEffect(player, effect)));
        }
    }

    void deactivateClass(Player player, boolean disable) {
        this.getEffects().forEach(effect -> NmsUtils.getInstance().removePotionEffect(player, effect));

        if(this instanceof Miner) {
			Miner miner = (Miner) this;
            int diamondsMined = player.getStatistic(Statistic.MINE_BLOCK, Material.DIAMOND_ORE);

			miner.getDiamondData(diamondsMined).forEach(data ->
			    data.getEffects().forEach(effect -> NmsUtils.getInstance().removePotionEffect(player, effect)));
		}

        if(!disable) {
            this.players.remove(player.getUniqueId());
        }

        new PvpClassUnequipEvent(player.getUniqueId(), this);
    }

    protected void applyClickableEffect(Player player, ClickableItem clickable, boolean archer) {
        String effect = StringUtils.getPotionEffectName(clickable.getPotionEffect());

        this.getManager().addPotionEffect(player, clickable.getPotionEffect());
        ItemUtils.removeOneItem(player);

        String message = archer ? Lang.ARCHER_CLICKABLE_ACTIVATED : Lang.ROGUE_CLICKABLE_ACTIVATED;

        player.sendMessage(Lang.PREFIX + message.replace("<effect>", effect).replace("<seconds>",
        String.valueOf(clickable.getPotionEffect().getDuration() / 20)));
    }

    public boolean isActive(Player player) {
        return this.players.contains(player.getUniqueId());
    }

    boolean isWarmupOrActive(Player player) {
        PvpClassWarmupTimer warmupTimer = TimerManager.getInstance().getPvpClassWarmupTimer();
        return warmupTimer.isActive(player, this.name) || this.isActive(player);
    }

    private boolean isWearingFull(Player player) {
        for(ItemStack armor : player.getInventory().getArmorContents()) {
            if(armor == null) return false;
        }

        ItemStack[] armor = player.getInventory().getArmorContents();

        return armor[3].getType() == helmet && armor[2].getType() == chestplate &&
               armor[1].getType() == leggings && armor[0].getType() == boots;
    }

    boolean isAtFactionLimit(PlayerFaction faction) {
        int limit = Config.FACTION_PVP_CLASS_LIMIT.get(this.getName());
        return limit != -1 && this.factionLimit.getOrDefault(faction.getId(), -1) >= limit;
    }

    public void checkEquipmentChange(Player player) {
        if(this.isWearingFull(player)) {
            if(this.isWarmupOrActive(player)) return;

            if(PvpClassUtils.getWarmup(this.name) <= 0) {
                this.activateClass(player.getUniqueId());
                return;
            }

            int warmup = PvpClassUtils.getWarmup(this.name);
            TimerManager.getInstance().getPvpClassWarmupTimer().activate(player, warmup, this);

            player.sendMessage(Lang.PVP_CLASSES_WARMING_UP.replace("<name>", this.getDisplayName()));
            return;
        }

        PvpClassWarmupTimer warmupTimer = TimerManager.getInstance().getPvpClassWarmupTimer();

        if(warmupTimer.isActive(player, this.name)) {
            warmupTimer.cancel(player, this.name);
            player.sendMessage(Lang.PVP_CLASSES_WARMUP_CANCELLED.replace("<name>", this.getDisplayName()));
            return;
        }

        if(this.isActive(player)) {
            this.deactivateClass(player, false);
            player.sendMessage(Lang.PVP_CLASSES_DEACTIVATED.replace("<name>", this.getDisplayName()));
        }
    }
}
