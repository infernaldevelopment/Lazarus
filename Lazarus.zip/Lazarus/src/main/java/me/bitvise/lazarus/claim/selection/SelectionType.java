package me.bitvise.lazarus.claim.selection;

public enum SelectionType {
    CLAIM, SELECTION, SYSTEM_CLAIM, EVENT_CLAIM
}
