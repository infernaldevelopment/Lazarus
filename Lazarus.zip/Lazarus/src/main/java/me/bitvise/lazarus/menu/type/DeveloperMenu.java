package me.bitvise.lazarus.menu.type;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.menu.Button;
import me.bitvise.lazarus.menu.Menu;
import me.bitvise.lazarus.menu.buttons.CloseButton;
import me.bitvise.lazarus.utils.item.ItemBuilder;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Map;

public class DeveloperMenu extends Menu {


    @Override
    public String getTitle(Player player) {
        return "&8About Plugin";
    }

    @Override
    public int getSize() {
        return 9*3;
    }

    @Override
    public Map<Integer, Button> getButtons(Player player) {
        Map<Integer, Button> buttons = Maps.newHashMap();

        buttons.put(0, new CloseButton());
        buttons.put(12, new PerformanceInformationButton());
        buttons.put(13, new PluginInformationButton());
        buttons.put(14, new ContactInformation());

        return buttons;
    }

    private static class PerformanceInformationButton extends Button {

        @Override
        public ItemStack getButtonItem(Player player) {
            List<String> lore = Lists.newArrayList();

            lore.add(ChatColor.GRAY + "Unique Players: " + ChatColor.DARK_GREEN + Lazarus.getInstance().getProfileManager().getUniquePlayers());
            lore.add(ChatColor.GRAY + "Total Factions: " + ChatColor.DARK_AQUA + FactionsManager.getInstance().getFactions().size());
            lore.add(ChatColor.GRAY + "");
            lore.add(ChatColor.GRAY + "Latest Version: " + ChatColor.DARK_RED + Lazarus.getInstance().getDescription().getVersion());
            lore.add(ChatColor.GRAY + "Author: " + ChatColor.DARK_GRAY + Lazarus.getInstance().getDescription().getAuthors());

            return new ItemBuilder(Material.ITEM_FRAME).setName("&aPerformance Information").setLore(lore).build();
        }
    }

    private static class PluginInformationButton extends Button {

        @Override
        public ItemStack getButtonItem(Player player) {
            List<String> lore = Lists.newArrayList();

            lore.add(ChatColor.GRAY + "Handlers: " + ChatColor.LIGHT_PURPLE + Lazarus.getInstance().getHandlerManager().getHandlerList());
            lore.add(ChatColor.GRAY + "Commands: " + ChatColor.YELLOW + Lazarus.getInstance().getCommandManager().getCommandList());
            lore.add(ChatColor.GRAY + "");
            lore.add(ChatColor.GRAY + "If you find any bug please");
            lore.add(ChatColor.GRAY + "report them in contact information.");

            return new ItemBuilder(Material.ANVIL).setName("&aPlugin Information").setLore(lore).build();
        }
    }

    private static class ContactInformation extends Button {

        @Override
        public ItemStack getButtonItem(Player player) {
            List<String> lore = Lists.newArrayList();

            lore.add(ChatColor.GRAY + "Discord: " + ChatColor.BLUE + "bitvise#2500");
            lore.add(ChatColor.GRAY + "Twitter: " + ChatColor.AQUA + "@bitvise");
            lore.add(ChatColor.GRAY + "Website: " + ChatColor.GOLD + "www.bitvise.com");

            return new ItemBuilder(Material.FLOWER_POT_ITEM).setName("&aContact Information").setLore(lore).build();
        }
    }
}
