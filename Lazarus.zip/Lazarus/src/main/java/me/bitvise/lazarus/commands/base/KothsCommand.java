package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.menu.type.KothsMenu;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class KothsCommand extends BaseCommand {

    public KothsCommand() {
        super("koths", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        new KothsMenu().openMenu(player);
    }
}
