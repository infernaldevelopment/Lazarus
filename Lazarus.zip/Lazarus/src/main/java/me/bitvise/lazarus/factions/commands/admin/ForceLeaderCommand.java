package me.bitvise.lazarus.factions.commands.admin;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionPlayer;
import me.bitvise.lazarus.factions.enums.Role;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;

public class ForceLeaderCommand extends SubCommand {

    public ForceLeaderCommand() {
        super("forceleader", "lazarus.factions.forceleader");

        this.setExecuteAsync(true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FORCE_LEADER_USAGE);
            return;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        if(!this.checkOfflinePlayer(sender, target, args[0])) return;

        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(target.getUniqueId());

        if(faction == null) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION.replace("<player>", target.getName()));
            return;
        }

        FactionPlayer targetPlayer = faction.getMember(target);

        if(targetPlayer.getRole() == Role.LEADER) {
            sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FORCE_LEADER_ALREADY_LEADER.replace("<player>", target.getName()));
            return;
        }

        faction.getLeader().setRole(Role.CO_LEADER);
        targetPlayer.setRole(Role.LEADER);

        if(Config.TAB_ENABLED) {
            Lazarus.getInstance().getTabManager().updateFactionPlayerList(faction);
        }

        sender.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FORCE_LEADER_CHANGED_SENDER
        .replace("<player>", target.getName()).replace("<faction>", faction.getName()));

        faction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_FORCE_LEADER_CHANGED_FACTION
        .replace("<sender>", sender.getName()).replace("<player>", target.getName()));
    }
}
