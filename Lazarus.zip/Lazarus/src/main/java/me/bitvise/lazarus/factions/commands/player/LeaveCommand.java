package me.bitvise.lazarus.factions.commands.player;

import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.enums.Role;
import me.bitvise.lazarus.factions.type.PlayerFaction;
import me.bitvise.lazarus.claim.Claim;
import me.bitvise.lazarus.claim.ClaimManager;

import me.bitvise.lazarus.utils.provider.Config;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class LeaveCommand extends SubCommand {

    public LeaveCommand() {
        super("leave", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);

        if(faction == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
            return;
        }

        if(faction.getMember(player).getRole() == Role.LEADER) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_LEADER_LEAVE);
            return;
        }

        if(!Config.FACTION_LEAVE_WHILE_FROZEN && faction.isRegenerating()) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CANNOT_LEAVE_WHILE_REGENERATING);
            return;
        }

        Claim claim = ClaimManager.getInstance().getClaimAt(player);

        if(claim != null && !Config.FACTION_LEAVE_WHILE_IN_OWN_CLAIM && claim.getOwner() == faction) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_CANNOT_LEAVE_WHILE_IN_OWN_CLAIM);
            return;
        }

        if(!FactionsManager.getInstance().leaveFaction(player, faction)) return;

        player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_LEFT_SELF.replace("<name>", faction.getName()));
        faction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_LEFT_OTHERS.replace("<player>", player.getName()));
    }
}
