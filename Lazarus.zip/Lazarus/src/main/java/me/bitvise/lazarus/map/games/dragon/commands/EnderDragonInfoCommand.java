package me.bitvise.lazarus.map.games.dragon.commands;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.utils.StringUtils;

import me.bitvise.lazarus.utils.provider.Config;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;

public class EnderDragonInfoCommand extends SubCommand {

    public EnderDragonInfoCommand() {
        super("info");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Location dragonSpawn = Lazarus.getInstance().getEnderDragonManager().getSpawnLocation();

        Lang.ENDER_DRAGON_INFO_MESSAGE.forEach(line -> sender.sendMessage(line
        .replace("<health>", String.valueOf(Config.ENDER_DRAGON_HEALTH))
        .replace("<location>", dragonSpawn == null ? Lang.ENDER_DRAGON_SPAWN_NOT_SET
        : StringUtils.getLocationNameWithWorld(dragonSpawn))));
    }
}
