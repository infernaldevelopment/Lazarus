package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.Messages;
import me.bitvise.lazarus.utils.StringUtils;
import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;

public class SayCommand extends BaseCommand {

    public SayCommand() {
        super("say", Collections.singletonList("me"), "lazarus.say");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.PREFIX + Lang.SAY_COMMAND_USAGE);
            return;
        }

        String color;
        if (sender instanceof Player) {
            Player p = (Player) sender;
            color = Color.translate(ChatHandler.getInstance().getSuffix(p));
        } else {
            color = Color.translate("&4");
        }

        String message = Color.translate(StringUtils.joinArray(args, " ", 1));
        Messages.sendMessage(Lang.SAY_COMMAND_MESSAGE.replace("<player>", sender.getName()).replace("<color>", color).replace("<message>", message));
    }
}

