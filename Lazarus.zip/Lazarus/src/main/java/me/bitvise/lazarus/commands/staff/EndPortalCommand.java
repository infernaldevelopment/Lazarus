package me.bitvise.lazarus.commands.staff;

import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.claim.selection.SelectionType;
import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class EndPortalCommand extends BaseCommand {

    public EndPortalCommand() {
        super("endportal", "lazarus.endportal", true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        Lazarus.getInstance().getSelectionManager().toggleSelectionProcess(player, SelectionType.SELECTION,
        Lazarus.getInstance().getEndPortalHandler().createSelectionCheck());

        player.sendMessage(Lang.PREFIX + Lang.ENDPORTAL_SELECTOR_ADDED_TO_INVENTORY);
    }
}
