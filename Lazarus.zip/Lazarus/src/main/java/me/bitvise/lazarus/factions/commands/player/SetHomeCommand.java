package me.bitvise.lazarus.factions.commands.player;

import me.bitvise.lazarus.claim.ClaimManager;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import me.bitvise.lazarus.commands.manager.SubCommand;
import me.bitvise.lazarus.factions.FactionsManager;
import me.bitvise.lazarus.factions.enums.Role;
import me.bitvise.lazarus.factions.event.FactionSetHomeEvent;
import me.bitvise.lazarus.factions.type.PlayerFaction;

import me.bitvise.lazarus.utils.provider.Lang;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;

public class SetHomeCommand extends SubCommand {

    public SetHomeCommand() {
        super("sethome", Arrays.asList("sethq"), true);
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Player player = (Player) sender;

        PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);

        if(faction == null) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
            return;
        }

        if(!faction.getMember(player).getRole().isAtLeast(Role.CO_LEADER)) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NO_PERMISSION.replace("<role>", Role.getName(Role.CO_LEADER)));
            return;
        }

        Location location = player.getLocation();

        if(ClaimManager.getInstance().getFactionAt(location) != faction) {
            player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_SET_HOME_NOT_IN_OWN_CLAIM);
            return;
        }

        faction.setHome(location);

        faction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_SET_HOME_HOME_SET
            .replace("<x>", String.valueOf(location.getBlockX()))
            .replace("<z>", String.valueOf(location.getBlockZ()))
            .replace("<player>", player.getName()));

        new FactionSetHomeEvent(faction, sender, location);
    }

    public static class SetHQCommand extends BaseCommand {

        public SetHQCommand() {
            super("sethq", Arrays.asList("sethome"), true);
        }

        @Override
        public void execute(CommandSender sender, String[] args) {
            Player player = (Player) sender;

            PlayerFaction faction = FactionsManager.getInstance().getPlayerFaction(player);

            if(faction == null) {
                player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NOT_IN_FACTION_SELF);
                return;
            }

            if(!faction.getMember(player).getRole().isAtLeast(Role.CO_LEADER)) {
                player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_NO_PERMISSION.replace("<role>", Role.getName(Role.CO_LEADER)));
                return;
            }

            Location location = player.getLocation();

            if(ClaimManager.getInstance().getFactionAt(location) != faction) {
                player.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_SET_HOME_NOT_IN_OWN_CLAIM);
                return;
            }

            faction.setHome(location);

            faction.sendMessage(Lang.FACTION_PREFIX + Lang.FACTIONS_SET_HOME_HOME_SET
                    .replace("<x>", String.valueOf(location.getBlockX()))
                    .replace("<z>", String.valueOf(location.getBlockZ()))
                    .replace("<player>", player.getName()));

            new FactionSetHomeEvent(faction, sender, location);
        }
    }
}
