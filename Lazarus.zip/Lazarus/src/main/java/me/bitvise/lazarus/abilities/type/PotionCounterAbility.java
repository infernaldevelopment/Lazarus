package me.bitvise.lazarus.abilities.type;

import me.bitvise.lazarus.abilities.AbilityItem;
import me.bitvise.lazarus.abilities.AbilityType;
import me.bitvise.lazarus.handlers.chat.ChatHandler;
import me.bitvise.lazarus.utils.Color;
import me.bitvise.lazarus.utils.creator.ConfigCreator;
import me.bitvise.lazarus.utils.item.ItemBuilder;
import me.bitvise.lazarus.utils.item.ItemUtils;
import org.apache.commons.lang.time.DurationFormatUtils;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;

public class PotionCounterAbility extends AbilityItem {

    private final ItemStack splashPotion;

    public PotionCounterAbility(ConfigCreator config) {
        super(AbilityType.POTION_COUNTER, "POTION_COUNTER", config);

        this.splashPotion = new ItemBuilder(Material.POTION).setDurability(16421).build();
        this.overrideActivationMessage();
    }

    public void sendActivationMessage(Player player, Player target, int potionAmount) {
        this.activationMessage.forEach(line -> player.sendMessage(line
            .replace("<abilityName>", this.displayName)
            .replace("<player>", target.getName())
            .replace("<prefix>", Color.translate(ChatHandler.getInstance().getPrefix(target)))
            .replace("<amount>", String.valueOf(potionAmount))
            .replace("<cooldown>", DurationFormatUtils.formatDurationWords(this.cooldown * 1000, true, true))));
    }

    @Override
    protected boolean onPlayerItemHit(Player damager, Player target, EntityDamageByEntityEvent event) {
        int potionAmount = ItemUtils.getItemAmount(target, this.splashPotion.getData());
        this.sendActivationMessage(damager, target, potionAmount);
        return true;
    }
}
