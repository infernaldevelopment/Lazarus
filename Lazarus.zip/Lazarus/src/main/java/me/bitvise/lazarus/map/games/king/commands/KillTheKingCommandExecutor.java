package me.bitvise.lazarus.map.games.king.commands;

import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.commands.manager.SubCommandExecutor;
import org.bukkit.command.CommandSender;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class KillTheKingCommandExecutor extends SubCommandExecutor {

    public KillTheKingCommandExecutor() {
        super("killtheking", Arrays.asList("ktk", "king"), null);

        this.setPrefix(Lang.KING_PREFIX);

        this.addSubCommand(new KillTheKingStartCommand());
        this.addSubCommand(new KillTheKingStopCommand());
    }

    @Override
    protected List<String> getUsageMessage(CommandSender sender) {
        return sender.hasPermission("lazarus.killtheking.admin") ? Lang.KING_COMMAND_USAGE_ADMIN
        : Collections.singletonList(Lazarus.getInstance().getKillTheKingManager().getKingLocationString());
    }
}
