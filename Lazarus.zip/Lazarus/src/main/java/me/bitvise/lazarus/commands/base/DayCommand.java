package me.bitvise.lazarus.commands.base;

import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.commands.manager.BaseCommand;
import org.bukkit.Bukkit;
import org.bukkit.World.Environment;
import org.bukkit.command.CommandSender;

public class DayCommand extends BaseCommand {

    public DayCommand() {
        super("day", "lazarus.day");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Bukkit.getWorlds().stream().filter(world -> world.getEnvironment() == Environment.NORMAL).forEach(world -> world.setTime(0));
        sender.sendMessage(Lang.PREFIX + Lang.TIME_MESSAGE_DAY);
    }
}
