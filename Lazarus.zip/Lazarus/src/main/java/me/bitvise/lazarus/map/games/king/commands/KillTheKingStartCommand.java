package me.bitvise.lazarus.map.games.king.commands;

import me.bitvise.lazarus.utils.provider.Lang;
import me.bitvise.lazarus.Lazarus;
import me.bitvise.lazarus.commands.manager.SubCommand;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class KillTheKingStartCommand extends SubCommand {

    public KillTheKingStartCommand() {
        super("start", "lazarus.killtheking.start");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if(args.length == 0) {
            sender.sendMessage(Lang.KING_START_USAGE);
            return;
        }

        if(Lazarus.getInstance().getKillTheKingManager().isActive()) {
            sender.sendMessage(Lang.KING_EXCEPTION_ALREADY_RUNNING);
            return;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if(!this.checkPlayer(sender, target, args[0])) return;

        Lazarus.getInstance().getKillTheKingManager().startKillTheKing(target);
    }
}
